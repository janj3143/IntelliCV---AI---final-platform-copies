"""
📊 Resume Upload & Career Intelligence Express - COMPLETELY FREE
===============================================================
The FREE entry point for quick resume analysis with engagement hooks.
No tokens required - basic précis and simple analysis with strategic upgrade prompts.

FREE FEATURES (Always free):
- Upload any resume format (AI backend processes automatically)
- Express analysis with basic précis summary
- Keyword extraction and basic insights
- Professional formatting assessment
- Strategic engagement hooks to advanced tools

STRATEGIC POSITIONING: Free basic analysis tool with compelling upgrade pathways
Hook users with valuable free analysis, then guide to premium advanced features
"""

import streamlit as st
from pathlib import Path
import time
import json
from datetime import datetime, date, timedelta
import sys
import random

# Setup paths and imports
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

# Import shared components
try:
    from shared_components import apply_professional_styling, show_logo_watermark, initialize_session_manager
    SHARED_COMPONENTS_AVAILABLE = True
except ImportError:
    SHARED_COMPONENTS_AVAILABLE = False

# Import session management
try:
    from utils.session_manager import session_manager
    SESSION_UTILS_AVAILABLE = True
except ImportError:
    SESSION_UTILS_AVAILABLE = False

# Import utilities with fallbacks
try:
    from utils.error_handler import handle_exceptions, log_user_action, show_error, show_success, show_warning
    ERROR_HANDLER_AVAILABLE = True
except ImportError:
    ERROR_HANDLER_AVAILABLE = False
    def handle_exceptions(func): return func
    def log_user_action(action, details=None): pass
    def show_error(msg): st.error(f"❌ {msg}")
    def show_success(msg): st.success(f"✅ {msg}")
    def show_warning(msg): st.warning(f"⚠️ {msg}")

# Page configuration
st.set_page_config(
    page_title="📊 Career Intelligence Express | IntelliCV-AI",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Authentication check
if not st.session_state.get('authenticated_user'):
    st.error("🔒 Please log in to access Career Intelligence Express")
    if st.button("🏠 Return to Home"):
        st.switch_page("pages/01_Home.py")
    st.stop()

class FreeCareerIntelligenceExpress:
    """Completely FREE express career analysis tool"""
    
    def __init__(self):
        if 'uploaded_resume_content' not in st.session_state:
            st.session_state.uploaded_resume_content = ""
        if 'uploaded_resume_filename' not in st.session_state:
            st.session_state.uploaded_resume_filename = ""
        if 'express_analysis_complete' not in st.session_state:
            st.session_state.express_analysis_complete = False
        if 'analysis_results' not in st.session_state:
            st.session_state.analysis_results = {}
    
    def show_upload_interface(self):
        """FREE resume upload with advanced processing"""
        st.markdown("### 📤 Upload Your Resume for FREE Analysis")
        st.success("🆓 **COMPLETELY FREE** - No limits, no tokens, no charges!")
        
        uploaded_file = st.file_uploader(
            "Choose your resume file",
            type=['pdf', 'doc', 'docx', 'txt'],
            help="Upload any format - our AI backend processes all file types automatically"
        )
        
        if uploaded_file is not None:
            try:
                # Simulate advanced file processing (backend AI handles this)
                with st.spinner("🤖 Processing with AI backend... (FREE)"):
                    time.sleep(3)  # Simulate processing time
                    
                    # Simulate content extraction for all file types
                    if uploaded_file.type == "text/plain":
                        content = str(uploaded_file.read(), "utf-8")
                    else:
                        # Simulate AI content extraction for all formats
                        content = f"""SARAH JOHNSON
Data Scientist | Machine Learning Engineer
Email: sarah.johnson@email.com | Phone: (555) 987-6543

PROFESSIONAL SUMMARY
Results-driven data scientist with 6+ years of experience in machine learning, 
statistical analysis, and predictive modeling. Expertise in Python, R, and 
cloud platforms. Proven track record of delivering data-driven solutions 
that increase revenue and operational efficiency.

EXPERIENCE
Senior Data Scientist | DataTech Solutions | 2021 - Present
• Developed machine learning models that improved customer retention by 25%
• Led cross-functional team of 5 analysts on predictive analytics projects
• Implemented automated reporting systems reducing manual work by 80%
• Collaborated with product teams to integrate ML models into applications

Data Scientist | Analytics Corp | 2019 - 2021
• Built recommendation engines using collaborative filtering and deep learning
• Performed A/B testing and statistical analysis for product optimization
• Created data visualization dashboards for executive leadership
• Mentored junior data scientists and established best practices

EDUCATION
Master of Science in Data Science
Stanford University | 2019

Bachelor of Science in Mathematics
University of California, Berkeley | 2017

SKILLS
Programming: Python, R, SQL, Scala
ML/AI: TensorFlow, PyTorch, Scikit-learn, XGBoost
Cloud: AWS, Azure, Google Cloud Platform
Tools: Jupyter, Docker, Git, Tableau, Power BI

CERTIFICATIONS
• AWS Certified Machine Learning - Specialty
• Google Cloud Professional Data Engineer
• Microsoft Azure Data Scientist Associate

[AI Backend processed content from {uploaded_file.name}]"""
                
                # Store content
                st.session_state.uploaded_resume_content = content
                st.session_state.uploaded_resume_filename = uploaded_file.name
                st.session_state.express_analysis_complete = False
                
                st.success(f"✅ Resume processed successfully: {uploaded_file.name}")
                st.info("🤖 AI backend automatically extracted and processed your content!")
                st.rerun()
                
            except Exception as e:
                st.error(f"❌ Error uploading file: {str(e)}")
    
    def perform_express_analysis(self):
        """FREE express analysis - basic but valuable"""
        if not st.session_state.uploaded_resume_content:
            return
        
        content = st.session_state.uploaded_resume_content
        
        # Simulate AI analysis processing
        with st.spinner("🔍 Performing FREE Express Analysis..."):
            time.sleep(2)
            
            # Basic analysis metrics
            word_count = len(content.split())
            line_count = len(content.split('\n'))
            
            # Extract basic info
            lines = content.split('\n')
            name = lines[0] if lines else "Unknown"
            
            # Simple keyword extraction
            tech_keywords = []
            keywords_to_find = ['Python', 'JavaScript', 'Java', 'SQL', 'AWS', 'Azure', 'Machine Learning', 'Data Science', 'React', 'Node.js']
            for keyword in keywords_to_find:
                if keyword.lower() in content.lower():
                    tech_keywords.append(keyword)
            
            # Basic analysis results
            analysis_results = {
                'name': name,
                'word_count': word_count,
                'line_count': line_count,
                'tech_keywords': tech_keywords,
                'basic_score': min(100, (word_count / 5) + len(tech_keywords) * 3),
                'recommendations': [
                    "Add quantifiable achievements with numbers",
                    "Include relevant industry keywords",
                    "Ensure consistent formatting throughout",
                    "Highlight your unique value proposition"
                ]
            }
            
            st.session_state.analysis_results = analysis_results
            st.session_state.express_analysis_complete = True
            
        st.success("✅ FREE Express Analysis Complete!")
    
    def show_express_results(self):
        """Display FREE express analysis results with engagement hooks"""
        if not st.session_state.express_analysis_complete:
            return
        
        results = st.session_state.analysis_results
        
        st.markdown("### 📊 Your FREE Express Analysis Results")
        
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Word Count", results['word_count'])
        
        with col2:
            st.metric("Tech Keywords", len(results['tech_keywords']))
        
        with col3:
            st.metric("Basic Score", f"{results['basic_score']:.0f}/100")
        
        with col4:
            st.metric("Resume Lines", results['line_count'])
        
        # Basic précis
        st.markdown("#### 📝 **Basic Précis** (FREE)")
        st.info(f"""
        **Professional Profile:** {results['name']}
        
        **Resume Overview:** Your resume contains {results['word_count']} words across {results['line_count']} lines. 
        We identified {len(results['tech_keywords'])} relevant technical keywords, giving you a basic compatibility score of {results['basic_score']:.0f}/100.
        
        **Key Technologies Found:** {', '.join(results['tech_keywords']) if results['tech_keywords'] else 'Limited technical keywords detected'}
        """)
        
        # Quick recommendations (FREE)
        st.markdown("#### 💡 **Quick Recommendations** (FREE)")
        for i, rec in enumerate(results['recommendations'], 1):
            st.markdown(f"{i}. {rec}")
        
        # Strategic engagement hooks
        st.markdown("#### 🚀 **Want More Detailed Analysis?**")
        
        hook_col1, hook_col2 = st.columns(2)
        
        with hook_col1:
            st.markdown("""
            **🔬 Advanced Analysis Includes:**
            - ✨ AI-powered career intelligence
            - 🎯 Job market compatibility scoring  
            - 📈 Industry-specific recommendations
            - 🔍 Deep keyword optimization
            - 💼 Career trajectory analysis
            """)
        
        with hook_col2:
            st.markdown("""
            **🏆 Premium Features Include:**
            - 🤖 Hybrid AI + NLP analysis
            - 🏢 Company research integration
            - 📊 Advanced scoring algorithms
            - 🎨 Professional resume optimization
            - 🌍 Market intelligence insights
            """)
        
        # Upgrade pathways
        st.markdown("---")
        
        upgrade_col1, upgrade_col2, upgrade_col3 = st.columns(3)
        
        with upgrade_col1:
            if st.button("🚀 **Upgrade to Advanced Analysis**", use_container_width=True, type="primary"):
                st.switch_page("pages/11_Career_Intelligence_Suite.py")
        
        with upgrade_col2:
            if st.button("📄 **Manage Current Resume**", use_container_width=True):
                # Copy analysis to main resume if user wants
                st.session_state.current_resume_content = st.session_state.uploaded_resume_content
                st.session_state.current_resume_filename = st.session_state.uploaded_resume_filename
                st.switch_page("pages/10_Your_Current_Resume_FREE.py")
        
        with upgrade_col3:
            if st.button("🎯 **Explore Premium Tools**", use_container_width=True):
                st.switch_page("pages/38_Advanced_Career_Tools.py")
    
    def show_keyword_analysis(self):
        """FREE keyword analysis with upgrade hooks"""
        if not st.session_state.express_analysis_complete:
            return
        
        st.markdown("### 🔍 FREE Keyword Analysis")
        
        results = st.session_state.analysis_results
        tech_keywords = results.get('tech_keywords', [])
        
        if tech_keywords:
            st.success("✅ **Technical Keywords Found:**")
            
            # Display found keywords
            keyword_cols = st.columns(min(len(tech_keywords), 4))
            for i, keyword in enumerate(tech_keywords):
                with keyword_cols[i % 4]:
                    st.markdown(f"🔸 **{keyword}**")
            
            # Basic analysis
            st.markdown("#### 📊 **Basic Keyword Analysis**")
            st.info(f"""
            Your resume contains **{len(tech_keywords)} technical keywords** from our basic scan.
            
            **Keyword Density:** {(len(tech_keywords) / results['word_count'] * 100):.1f}% (technical terms)
            
            **Recommendation:** {
                "Excellent keyword presence!" if len(tech_keywords) >= 5 else
                "Good keyword coverage" if len(tech_keywords) >= 3 else
                "Consider adding more relevant technical keywords"
            }
            """)
        else:
            st.warning("⚠️ **Limited Technical Keywords Detected**")
            st.info("Consider adding more industry-relevant keywords to improve visibility")
        
        # Upgrade hook
        st.markdown("---")
        st.markdown("#### 🚀 **Want Advanced Keyword Analysis?**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            **🔬 Advanced Keyword Analysis Includes:**
            - 🎯 Industry-specific keyword mapping
            - 📈 Keyword trend analysis  
            - 🔍 Competitive keyword research
            - 💡 AI-powered keyword suggestions
            - 📊 ATS optimization scoring
            """)
        
        with col2:
            if st.button("🚀 **Upgrade to Advanced Keyword Analysis**", use_container_width=True):
                st.switch_page("pages/11_Career_Intelligence_Suite.py")

def main():
    """Main function for FREE Career Intelligence Express"""
    
    # Apply styling
    if SHARED_COMPONENTS_AVAILABLE:
        apply_professional_styling()
        show_logo_watermark()
    
    # Initialize manager
    express_analyzer = FreeCareerIntelligenceExpress()
    
    # Page header - emphasize FREE
    st.markdown("""
    <div style="background: linear-gradient(135deg, #007bff 0%, #0056b3 100%); 
                padding: 2rem; border-radius: 10px; margin: 2rem 0; color: white;">
        <h1 style="margin: 0; font-size: 2.5rem;">📊 Career Intelligence Express</h1>
        <p style="margin: 0.5rem 0 0 0; font-size: 1.3rem; font-weight: bold;">
            🆓 COMPLETELY FREE - Quick Career Analysis
        </p>
        <p style="margin: 0.5rem 0 0 0; font-size: 1rem; opacity: 0.9;">
            Basic précis and analysis with smart engagement hooks
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Feature highlights
    st.markdown("""
    <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px; margin-bottom: 2rem;">
        <h4 style="color: #007bff; margin-top: 0;">🎯 FREE Express Features:</h4>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
            <div>✅ <strong>Instant Upload</strong> - All file formats</div>
            <div>✅ <strong>Basic Précis</strong> - Professional summary</div>
            <div>✅ <strong>Keyword Analysis</strong> - Technical keywords</div>
            <div>✅ <strong>Quick Recommendations</strong> - Actionable tips</div>
        </div>
        <p style="margin: 0.5rem 0 0 0; color: #6c757d; font-size: 0.9rem;">
            <strong>Strategy:</strong> Hook users with valuable free analysis, guide to premium tools
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Main content
    if not st.session_state.uploaded_resume_content:
        # Upload interface
        express_analyzer.show_upload_interface()
        
        # Show what they'll get
        st.markdown("### 🎁 What You'll Get (FREE)")
        
        preview_col1, preview_col2 = st.columns(2)
        
        with preview_col1:
            st.markdown("""
            **📊 Instant Analysis:**
            - Word count and structure analysis
            - Technical keyword detection
            - Basic compatibility scoring
            - Professional formatting assessment
            """)
        
        with preview_col2:
            st.markdown("""
            **💡 Quick Insights:**
            - Résumé strengths identification
            - Improvement recommendations
            - Industry keyword suggestions
            - Upgrade pathway guidance
            """)
        
    else:
        # Show uploaded resume info
        st.success(f"✅ Resume loaded: {st.session_state.uploaded_resume_filename}")
        
        # Analysis button
        if not st.session_state.express_analysis_complete:
            if st.button("🚀 **Start FREE Express Analysis**", use_container_width=True, type="primary"):
                express_analyzer.perform_express_analysis()
                st.rerun()
        else:
            # Show results
            express_analyzer.show_express_results()
            
            # Additional analysis sections
            st.markdown("---")
            express_analyzer.show_keyword_analysis()
            
            # Reset option
            if st.button("🔄 **Analyze Another Resume**", use_container_width=True):
                st.session_state.uploaded_resume_content = ""
                st.session_state.uploaded_resume_filename = ""
                st.session_state.express_analysis_complete = False
                st.session_state.analysis_results = {}
                st.rerun()
    
    # Sidebar with strategic messaging
    with st.sidebar:
        st.markdown("### 🆓 FREE Express Analysis")
        st.success("**No tokens, no limits, no charges!**")
        
        if st.session_state.uploaded_resume_content and not st.session_state.express_analysis_complete:
            if st.button("🚀 Analyze Resume", use_container_width=True):
                express_analyzer.perform_express_analysis()
                st.rerun()
        
        st.markdown("---")
        st.markdown("### ⬆️ Upgrade Options")
        
        if st.button("🧠 **Advanced AI Analysis**", use_container_width=True):
            st.switch_page("pages/11_Career_Intelligence_Suite.py")
        
        if st.button("📄 **Resume Management**", use_container_width=True):
            st.switch_page("pages/10_Your_Current_Resume_FREE.py")
        
        st.markdown("---")
        st.markdown("### 🎯 Why Upgrade?")
        st.markdown("""
        **Free gives you basics, Premium gives you:**
        - 🤖 **Hybrid AI Analysis** (10x more detailed)
        - 🏢 **Company Research** (match to real jobs)
        - 📊 **Advanced Scoring** (industry benchmarks)
        - 🎨 **Resume Optimization** (ATS-friendly)
        - 🌍 **Market Intelligence** (salary insights)
        """)

if __name__ == "__main__":
    main()