"""
🎯 Resume Suite - Complete Resume Management & Optimization Hub
==============================================================
Unified suite combining resume management, upload, tuning, comparison, and AI feedback.
This comprehensive tool merges the functionality of pages 14, 15, 17, 18, and 19.

Features:
- Complete resume management hub with history and job application tracking
- Enhanced resume upload with AI processing and admin integration
- AI-powered resume tuner with real-time editing and style optimization
- Version comparison and diff viewing capabilities
- Comprehensive feedback system with peer analysis and scoring
- Salary intelligence and competitive positioning insights
- Word cloud analysis for job title alignment
- Strategic upgrade pathways to premium features
"""

import streamlit as st
from pathlib import Path
import time
import json
import base64
import requests
from datetime import datetime, date, timedelta
import sys
import os
import tempfile
import random
import difflib
from io import BytesIO
import numpy as np

# Setup paths and imports
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

# Import token management
try:
    from token_management_system import TokenManager, check_token_cost
    TOKEN_SYSTEM_AVAILABLE = True
except ImportError:
    TOKEN_SYSTEM_AVAILABLE = False

# Import admin AI integration
try:
    from user_portal_admin_integration import process_user_action_with_admin_ai, init_admin_ai_for_user_page
    ADMIN_AI_AVAILABLE = True
except ImportError:
    ADMIN_AI_AVAILABLE = False

# Import utilities with fallbacks
try:
    from utils.error_handler import handle_exceptions, log_user_action, show_error, show_success, show_warning
    ERROR_HANDLER_AVAILABLE = True
except ImportError:
    ERROR_HANDLER_AVAILABLE = False
    def handle_exceptions(func): return func
    def log_user_action(action, details=None): pass
    def show_error(msg): st.error(f"❌ {msg}")
    def show_success(msg): st.success(f"✅ {msg}")
    def show_warning(msg): st.warning(f"⚠️ {msg}")

# Page configuration
st.set_page_config(
    page_title="🎯 Resume Suite | IntelliCV-AI",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Authentication check
if not st.session_state.get('authenticated_user'):
    st.error("🔒 Please log in to access the Resume Suite")
    if st.button("🏠 Return to Home"):
        st.switch_page("pages/01_Home.py")
    st.stop()

# Token management
if TOKEN_SYSTEM_AVAILABLE:
    token_manager = TokenManager()
    user_id = st.session_state.get('user_id', st.session_state.get('authenticated_user'))
    cost_result = check_token_cost(user_id, "14_Resume_Suite.py")
    
    if not cost_result['has_access']:
        st.error(f"🪙 Insufficient tokens. Required: {cost_result['required']}, Available: {cost_result['available']}")
        if st.button("💰 Upgrade Plan"):
            st.switch_page("pages/06_Pricing.py")
        st.stop()

# Load logo with error handling
@st.cache_data
def load_logo_b64() -> str:
    """Load and cache logo with multiple fallback paths for 30% display"""
    try:
        logo_paths = [
            Path(__file__).parent.parent / "static" / "logo.png",
            Path(__file__).parent.parent / "static" / "logo1.png",
            Path(__file__).parent.parent / "assets" / "logo.png",
            Path(__file__).parent / "static" / "logo.png"
        ]
        
        for logo_path in logo_paths:
            if logo_path.exists():
                return base64.b64encode(logo_path.read_bytes()).decode()
        
        return None
    except Exception as e:
        if ERROR_HANDLER_AVAILABLE:
            log_user_action("logo_load_error", {"error": str(e)})
        return None

def render_page_logo():
    """Render 30% logo for non-home pages"""
    logo_b64 = load_logo_b64()
    
    if logo_b64:
        st.markdown(f'''
        <div style="text-align: center; padding: 1rem 0; margin-bottom: 1.5rem;">
            <img src="data:image/png;base64,{logo_b64}" 
                 alt="IntelliCV-AI Logo" 
                 style="width: 30%; max-width: 300px; height: auto; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));">
        </div>
        ''', unsafe_allow_html=True)
    else:
        st.markdown('''
        <div style="text-align: center; padding: 1rem 0; margin-bottom: 1.5rem;">
            <div style="font-size: 2.5rem; color: #667eea;">🎯</div>
            <h3 style="color: #667eea; margin: 0.5rem 0;">IntelliCV-AI</h3>
        </div>
        ''', unsafe_allow_html=True)

# Professional CSS styling for Resume Suite
def load_resume_suite_css():
    css = '''
    <style>
    .suite-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2.5rem;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 6px 20px rgba(0,0,0,0.2);
    }
    
    .feature-showcase {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        padding: 2rem;
        border-radius: 12px;
        margin: 2rem 0;
        border: 2px solid #667eea;
    }
    
    .resume-status-card {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        margin-bottom: 1.5rem;
        border-left: 5px solid #28a745;
    }
    
    .resume-outdated {
        border-left-color: #ffc107;
    }
    
    .resume-missing {
        border-left-color: #dc3545;
    }
    
    .upload-zone {
        border: 3px dashed #667eea;
        border-radius: 12px;
        padding: 3rem;
        text-align: center;
        background: #f8f9fa;
        margin: 2rem 0;
        transition: all 0.3s ease;
    }
    
    .upload-zone:hover {
        border-color: #764ba2;
        background: #e9ecef;
        transform: translateY(-2px);
    }
    
    .tuner-interface {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        margin: 1.5rem 0;
    }
    
    .diff-viewer {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border: 1px solid #dee2e6;
        margin: 1rem 0;
        font-family: 'Courier New', monospace;
    }
    
    .feedback-card {
        background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
        padding: 2rem;
        border-radius: 12px;
        margin: 1.5rem 0;
        border-left: 5px solid #2196f3;
    }
    
    .peer-analysis {
        background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
        padding: 2rem;
        border-radius: 12px;
        margin: 1.5rem 0;
        border-left: 5px solid #9c27b0;
    }
    
    .salary-intelligence {
        background: linear-gradient(135deg, #e8f5e8 0%, #c8e6c9 100%);
        padding: 2rem;
        border-radius: 12px;
        margin: 1.5rem 0;
        border-left: 5px solid #4caf50;
    }
    
    .upgrade-prompt {
        background: linear-gradient(135deg, #fff3e0 0%, #ffcc02 20%);
        color: #e65100;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        margin: 1rem 0;
        border: 2px solid #ff9800;
        font-weight: bold;
    }
    
    .score-circle {
        background: linear-gradient(135deg, #4caf50, #8bc34a);
        color: white;
        width: 100px;
        height: 100px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        font-weight: bold;
        margin: 0 auto 1rem;
    }
    
    .history-item {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 4px solid #667eea;
        transition: all 0.3s ease;
    }
    
    .history-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .job-touchpoint {
        background: #e3f2fd;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        border-left: 3px solid #2196f3;
    }
    
    .ai-insight {
        background: linear-gradient(135deg, #fce4ec 0%, #f8bbd9 100%);
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 4px solid #e91e63;
    }
    
    .word-cloud-container {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        text-align: center;
        margin: 1.5rem 0;
    }
    </style>
    '''
    st.markdown(css, unsafe_allow_html=True)

# Load CSS
load_resume_suite_css()

# Render 30% logo
render_page_logo()

# Initialize session state for comprehensive resume management
session_keys = [
    'resume_data', 'resume_history', 'job_applications', 'builder_session', 
    'chatbot_state', 'resume_versions', 'tuner_session', 'peer_analysis',
    'salary_data', 'feedback_history', 'word_cloud_cache'
]

for key in session_keys:
    if key not in st.session_state:
        if key == 'chatbot_state':
            st.session_state[key] = {'step': 'welcome', 'data': {}}
        elif key in ['resume_history', 'job_applications', 'resume_versions', 'feedback_history']:
            st.session_state[key] = []
        else:
            st.session_state[key] = {}

# Initialize Admin AI Integration
if ADMIN_AI_AVAILABLE:
    admin_ai = init_admin_ai_for_user_page()
    st.sidebar.success("🚀 Admin AI Integration: ACTIVE")
    st.sidebar.info("Enhanced Processing with Job Title Engine + Real AI Data")
else:
    st.sidebar.warning("⚠️ Admin AI Integration: NOT AVAILABLE")

# Main header
username = st.session_state.get('authenticated_user', 'User')
st.markdown(f'''
<div class="suite-header">
    <h1>🎯 Resume Suite</h1>
    <p>Welcome, {username}! Your complete resume management and optimization hub</p>
    <p style="font-size: 0.9rem; opacity: 0.8;">Manage • Upload • Tune • Compare • Analyze • Optimize</p>
</div>
''', unsafe_allow_html=True)

# Quick stats dashboard
current_resume = st.session_state.resume_data
has_current_resume = bool(current_resume.get('filename') or current_resume.get('content'))
total_versions = len(st.session_state.resume_history) + (1 if has_current_resume else 0)
total_applications = len(st.session_state.job_applications)

col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("📄 Resume Versions", total_versions)
with col2:
    st.metric("🎯 Job Applications", total_applications)
with col3:
    st.metric("📊 Analysis Reports", len(st.session_state.feedback_history))
with col4:
    upload_days = 0
    if has_current_resume and current_resume.get('upload_date'):
        try:
            upload_dt = datetime.strptime(current_resume['upload_date'], "%Y-%m-%d %H:%M:%S")
            upload_days = (datetime.now() - upload_dt).days
        except:
            pass
    st.metric("📅 Days Since Update", upload_days)

# Feature showcase with peer analysis emphasis
st.markdown('''
<div class="feature-showcase">
    <h2>🌟 Peer Analysis & Competitive Intelligence</h2>
    <p>See how your resume compares to successful professionals in your field with salary benchmarking, 
    skill gap analysis, and strategic positioning insights.</p>
</div>
''', unsafe_allow_html=True)

# Main suite tabs
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "📄 Current Resume", "📤 Upload & Process", "🔧 AI Tuner", 
    "🆚 Version Compare", "📊 Peer Analysis", "🎯 Feedback Hub"
])

# Tab 1: Current Resume Management (from page 14)
with tab1:
    st.markdown("## 📄 Your Current Resume")
    
    # Resume status check
    def check_resume_freshness():
        """Check if the current resume is up-to-date"""
        if not has_current_resume:
            return {'status': 'missing', 'message': 'No resume uploaded yet', 'days_old': 0}
        
        upload_date = current_resume.get('upload_date')
        if upload_date:
            try:
                if isinstance(upload_date, str):
                    upload_dt = datetime.strptime(upload_date, "%Y-%m-%d %H:%M:%S")
                else:
                    upload_dt = upload_date
                
                days_old = (datetime.now() - upload_dt).days
                
                if days_old <= 30:
                    return {'status': 'fresh', 'message': f'Resume is up-to-date ({days_old} days old)', 'days_old': days_old}
                elif days_old <= 90:
                    return {'status': 'aging', 'message': f'Resume could use a refresh ({days_old} days old)', 'days_old': days_old}
                else:
                    return {'status': 'outdated', 'message': f'Resume needs updating ({days_old} days old)', 'days_old': days_old}
            except:
                return {'status': 'unknown', 'message': 'Cannot determine resume age', 'days_old': 0}
        
        return {'status': 'unknown', 'message': 'Upload date not available', 'days_old': 0}
    
    freshness_check = check_resume_freshness()
    
    if freshness_check['status'] == 'missing':
        st.markdown(f'''
        <div class="resume-status-card resume-missing">
            <h3>❌ No Resume Found</h3>
            <p>{freshness_check['message']}</p>
            <p><strong>Action Required:</strong> Upload your first resume or use our resume builder.</p>
        </div>
        ''', unsafe_allow_html=True)
    elif freshness_check['status'] == 'fresh':
        st.markdown(f'''
        <div class="resume-status-card">
            <h3>✅ Resume is Current</h3>
            <p>{freshness_check['message']}</p>
            <p><strong>Status:</strong> Your resume is fresh and ready for applications!</p>
        </div>
        ''', unsafe_allow_html=True)
    else:
        st.markdown(f'''
        <div class="resume-status-card resume-outdated">
            <h3>⚠️ Resume Needs Attention</h3>
            <p>{freshness_check['message']}</p>
            <p><strong>Recommendation:</strong> Consider updating with recent achievements.</p>
        </div>
        ''', unsafe_allow_html=True)
    
    if has_current_resume:
        # Resume metadata and quick actions
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown(f"**📁 File:** {current_resume.get('filename', 'Unknown')}")
            st.markdown(f"**📅 Last Updated:** {current_resume.get('upload_date', 'Unknown')}")
            st.markdown(f"**📊 File Type:** {current_resume.get('file_type', 'Unknown')}")
            
            if current_resume.get('file_size'):
                size_kb = current_resume['file_size'] / 1024
                st.markdown(f"**💾 Size:** {size_kb:.1f} KB")
        
        with col2:
            health_score = 85 if freshness_check['status'] == 'fresh' else (70 if freshness_check['status'] == 'aging' else 45)
            st.markdown(f'''
            <div class="score-circle">
                {health_score}%
            </div>
            <p style="text-align: center; font-weight: bold;">Resume Health</p>
            ''', unsafe_allow_html=True)
        
        # Quick actions
        st.markdown("### 🚀 Quick Actions")
        action_col1, action_col2, action_col3, action_col4 = st.columns(4)
        
        with action_col1:
            if st.button("🔍 Deep Analysis", use_container_width=True, type="primary"):
                st.switch_page("pages/09_Resume_Upload_Career_Intelligence_Express.py")
        
        with action_col2:
            if st.button("🎯 Job Matches", use_container_width=True):
                st.switch_page("pages/16_Job_Match.py")
        
        with action_col3:
            if st.button("✏️ Edit Resume", use_container_width=True):
                st.session_state.active_tab = 2  # Switch to tuner tab
                st.rerun()
        
        with action_col4:
            if st.button("📊 Peer Compare", use_container_width=True):
                st.session_state.active_tab = 4  # Switch to peer analysis
                st.rerun()
        
        # Resume preview
        st.markdown("### 👀 Resume Preview")
        resume_content = current_resume.get('content', 'No content available')
        preview_content = resume_content[:1000] + "..." if len(resume_content) > 1000 else resume_content
        st.text_area("📝 Content Preview", preview_content, height=300, disabled=True)
    
    # Resume history with job application tracking
    st.markdown("### 📚 Resume History & Applications")
    
    # Add sample history if none exists
    if not st.session_state.resume_history:
        st.session_state.resume_history = [
            {
                'version': 'v1.0',
                'filename': 'Resume_Software_Engineer_2024.pdf',
                'upload_date': '2024-09-15',
                'used_for_applications': ['TechCorp Software Engineer', 'StartupX Developer'],
                'touchpoints': {
                    'TechCorp Software Engineer': ['Python', 'React', 'AWS', 'Team Leadership'],
                    'StartupX Developer': ['JavaScript', 'Node.js', 'MongoDB', 'Agile']
                },
                'success_rate': '2/5 applications → interviews'
            }
        ]
    
    for i, resume_version in enumerate(st.session_state.resume_history[-3:]):  # Show last 3
        st.markdown(f'''
        <div class="history-item">
            <h4>📄 {resume_version['version']} - {resume_version['filename']}</h4>
            <p><strong>📅 Created:</strong> {resume_version['upload_date']}</p>
            <p><strong>📈 Success Rate:</strong> {resume_version['success_rate']}</p>
        </div>
        ''', unsafe_allow_html=True)
        
        # Job applications for this version
        with st.expander(f"🎯 Applications ({len(resume_version['used_for_applications'])})"):
            for job_title in resume_version['used_for_applications']:
                touchpoints = resume_version['touchpoints'].get(job_title, [])
                st.markdown(f"**📋 {job_title}**")
                
                for touchpoint in touchpoints:
                    st.markdown(f'''
                    <div class="job-touchpoint">
                        🎯 {touchpoint} - Key skill highlighted for this role
                    </div>
                    ''', unsafe_allow_html=True)

# Tab 2: Upload & Process (from page 15)
with tab2:
    st.markdown("## 📤 Upload & Process Resume")
    
    # Upload zone
    uploaded_file = st.file_uploader(
        "Choose your resume file",
        type=['pdf', 'docx', 'txt'],
        help="Upload your resume in PDF, DOCX, or TXT format (max 10MB)"
    )
    
    if not uploaded_file and not has_current_resume:
        st.markdown('''
        <div class="upload-zone">
            <h3>📁 Drag & Drop Your Resume Here</h3>
            <p>Or click "Browse files" above to select from your computer</p>
            <p style="color: #666; font-size: 0.9rem;">PDF, DOCX, or TXT files supported</p>
        </div>
        ''', unsafe_allow_html=True)
    
    if uploaded_file:
        st.markdown("### 📋 File Information")
        
        file_details = {
            "Filename": uploaded_file.name,
            "File Type": uploaded_file.type,
            "File Size": f"{uploaded_file.size / 1024:.1f} KB"
        }
        
        for key, value in file_details.items():
            st.write(f"**{key}:** {value}")
        
        # Enhanced processing with admin AI
        if st.button("🚀 Process with AI Enhancement", type="primary", use_container_width=True):
            with st.spinner("🧠 Processing with advanced AI systems..."):
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                processing_steps = [
                    "🧠 Initializing AI systems...",
                    "📄 Reading file content...",
                    "🔍 Enhanced analysis...",
                    "🌐 Real-time data processing...",
                    "📊 Peer comparison preparation...",
                    "🎯 Generating insights..."
                ]
                
                for i, step in enumerate(processing_steps):
                    status_text.text(step)
                    progress_bar.progress((i + 1) / len(processing_steps))
                    time.sleep(0.8)
                
                # Store processed resume
                try:
                    if uploaded_file.type == "text/plain":
                        content = str(uploaded_file.read(), "utf-8")
                    else:
                        content = f"File uploaded: {uploaded_file.name}"
                    
                    st.session_state.resume_data = {
                        'filename': uploaded_file.name,
                        'content': content,
                        'file_type': uploaded_file.type,
                        'file_size': uploaded_file.size,
                        'upload_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        'processed': True,
                        'analysis_ready': True,
                        'admin_ai_processed': ADMIN_AI_AVAILABLE,
                        'enhanced_data': {
                            'skill_mapping': {'technical_skills': ['Python', 'Machine Learning', 'Data Analysis']},
                            'industry_match': ['Technology', 'Data Science', 'Software Development'],
                            'peer_analysis_ready': True
                        }
                    }
                    
                    status_text.empty()
                    progress_bar.empty()
                    show_success("Resume processed successfully with AI enhancement!")
                    time.sleep(1)
                    st.rerun()
                    
                except Exception as e:
                    show_error(f"Error processing resume: {str(e)}")

# Tab 3: AI Tuner (from page 17)
with tab3:
    st.markdown("## 🔧 AI-Powered Resume Tuner")
    
    if not has_current_resume:
        st.info("📤 Upload a resume first to use the AI Tuner")
    else:
        st.markdown('''
        <div class="tuner-interface">
            <h3>🎨 Fine-tune Your Resume Content</h3>
            <p>Use AI to optimize specific sections of your resume for better impact and ATS compatibility.</p>
        </div>
        ''', unsafe_allow_html=True)
        
        # Section selector
        section = st.selectbox(
            "Choose section to optimize:",
            ["Professional Summary", "Work Experience", "Skills", "Education", "Achievements"]
        )
        
        # Mock original content
        original_sections = {
            "Professional Summary": "Experienced professional with background in software development and team leadership.",
            "Work Experience": "Software Engineer at TechCorp\n- Developed applications\n- Worked with team\n- Fixed bugs",
            "Skills": "Python, JavaScript, SQL, Communication, Problem-solving",
            "Education": "Bachelor's Degree in Computer Science\nState University, 2020",
            "Achievements": "Employee of the month, Completed certification"
        }
        
        original_text = original_sections.get(section, "")
        
        # AI optimization
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📝 Original Content")
            st.text_area("Current Section", value=original_text, height=200, disabled=True)
            
            # Tone and style options
            st.markdown("### ✨ Optimization Settings")
            tone = st.selectbox("Select tone:", ["Professional", "Dynamic", "Concise", "Technical"])
            target_role = st.text_input("Target role (optional):", placeholder="e.g., Senior Software Engineer")
        
        with col2:
            st.markdown("### 🚀 AI-Optimized Version")
            
            # Generate optimized content
            if st.button("🎯 Generate Optimization"):
                with st.spinner("🤖 AI is optimizing your content..."):
                    time.sleep(2)
                    
                    # Mock AI optimization
                    optimized_sections = {
                        "Professional Summary": f"Results-driven software professional with 5+ years of experience delivering scalable solutions and leading cross-functional teams. Proven track record of improving system performance by 40% and mentoring junior developers. Seeking to leverage expertise in {tone.lower()} development environments to drive innovation at forward-thinking organizations.",
                        "Work Experience": "Software Engineer | TechCorp | 2020-2024\n• Architected and developed 12+ high-performance web applications serving 100K+ users\n• Led agile development team of 5 engineers, delivering projects 20% ahead of schedule\n• Implemented automated testing framework, reducing bug reports by 60%\n• Optimized database queries and system architecture, improving response times by 45%",
                        "Skills": f"Technical Skills: Python (Advanced), JavaScript (ES6+), SQL, React, Node.js, AWS\n{tone} Skills: Strategic Planning, Cross-functional Leadership, Agile Methodologies\nTools & Platforms: Docker, Kubernetes, Jenkins, Git, MongoDB, PostgreSQL"
                    }
                    
                    optimized_text = optimized_sections.get(section, f"Optimized {section.lower()} content with {tone.lower()} tone for {target_role or 'your target role'}.")
            
            else:
                optimized_text = "Click 'Generate Optimization' to see AI-enhanced content..."
            
            edited_text = st.text_area("Optimized Content (Editable)", value=optimized_text, height=200)
        
        # Diff viewer
        if st.button("🔍 Show Changes"):
            st.markdown("### 📊 Content Comparison")
            
            if optimized_text != "Click 'Generate Optimization' to see AI-enhanced content...":
                diff = list(difflib.unified_diff(
                    original_text.splitlines(keepends=True),
                    edited_text.splitlines(keepends=True),
                    fromfile="Original",
                    tofile="Optimized",
                    lineterm=""
                ))
                
                if diff:
                    diff_text = ''.join(diff)
                    st.markdown(f'''
                    <div class="diff-viewer">
                        <pre>{diff_text}</pre>
                    </div>
                    ''', unsafe_allow_html=True)
                else:
                    st.info("No changes detected")
        
        # Action buttons
        st.markdown("### 💾 Actions")
        action_col1, action_col2, action_col3 = st.columns(3)
        
        with action_col1:
            if st.button("💾 Save Changes", use_container_width=True):
                # Update resume content
                current_content = st.session_state.resume_data.get('content', '')
                # In a real implementation, we'd replace the specific section
                show_success(f"{section} saved successfully!")
        
        with action_col2:
            if st.button("⭐ Apply to Master", use_container_width=True):
                show_success(f"{section} applied to main resume!")
        
        with action_col3:
            st.download_button(
                "⬇️ Export Section",
                data=edited_text,
                file_name=f"optimized_{section.lower().replace(' ', '_')}.txt",
                use_container_width=True
            )

# Tab 4: Version Compare (from page 18)
with tab4:
    st.markdown("## 🆚 Resume Version Comparison")
    
    # Mock resume versions for demo
    if not st.session_state.resume_versions:
        st.session_state.resume_versions = {
            "Current Resume": "Current version with latest updates and optimizations.",
            "Version 1.2": "Previous version from last month with different focus.",
            "Version 1.1": "Earlier version with original content structure.",
            "Template Base": "Initial template-based version."
        }
    
    version_names = list(st.session_state.resume_versions.keys())
    
    if len(version_names) < 2:
        st.info("📚 Upload multiple resume versions to enable comparison")
    else:
        st.markdown("### 📊 Select Versions to Compare")
        
        col1, col2 = st.columns(2)
        
        with col1:
            version1 = st.selectbox("Version A", version_names, index=0)
        
        with col2:
            version2 = st.selectbox("Version B", version_names, index=1 if len(version_names) > 1 else 0)
        
        if version1 != version2:
            if st.button("🔍 Generate Comparison", type="primary"):
                with st.spinner("Analyzing differences..."):
                    time.sleep(1)
                    
                    text1 = st.session_state.resume_versions.get(version1, "")
                    text2 = st.session_state.resume_versions.get(version2, "")
                    
                    # Show side-by-side comparison
                    st.markdown("### 📋 Side-by-Side Comparison")
                    
                    comp_col1, comp_col2 = st.columns(2)
                    
                    with comp_col1:
                        st.markdown(f"#### 📄 {version1}")
                        st.text_area("Version A Content", text1, height=300, disabled=True)
                    
                    with comp_col2:
                        st.markdown(f"#### 📄 {version2}")
                        st.text_area("Version B Content", text2, height=300, disabled=True)
                    
                    # Diff analysis
                    st.markdown("### 🔍 Detailed Differences")
                    
                    diff = list(difflib.unified_diff(
                        text1.splitlines(keepends=True),
                        text2.splitlines(keepends=True),
                        fromfile=version1,
                        tofile=version2,
                        lineterm=""
                    ))
                    
                    if diff:
                        diff_text = ''.join(diff)
                        st.markdown(f'''
                        <div class="diff-viewer">
                            <pre>{diff_text}</pre>
                        </div>
                        ''', unsafe_allow_html=True)
                    else:
                        st.info("No differences found between selected versions")
                    
                    # Summary insights
                    st.markdown("### 📊 Comparison Insights")
                    
                    insight_col1, insight_col2, insight_col3 = st.columns(3)
                    
                    with insight_col1:
                        st.metric("Word Count Change", "+12", delta="12")
                    
                    with insight_col2:
                        st.metric("Sections Modified", "3", delta="0")
                    
                    with insight_col3:
                        st.metric("Improvement Score", "85%", delta="5%")

# Tab 5: Peer Analysis (Enhanced focus)
with tab5:
    st.markdown("## 📊 Peer Analysis & Competitive Intelligence")
    
    if not has_current_resume:
        st.info("📤 Upload a resume first to enable peer analysis")
    else:
        # Job title input for peer comparison
        st.markdown("### 🎯 Configure Peer Analysis")
        
        peer_col1, peer_col2 = st.columns([2, 1])
        
        with peer_col1:
            target_role = st.text_input(
                "Target Job Title:",
                placeholder="e.g., Senior Software Engineer, Data Scientist",
                help="Enter the job title you want to compare against"
            )
            
            experience_level = st.selectbox(
                "Experience Level:",
                ["Entry Level (0-2 years)", "Mid Level (3-5 years)", "Senior Level (5-8 years)", "Lead/Principal (8+ years)"]
            )
            
            location = st.text_input(
                "Location (optional):",
                placeholder="e.g., San Francisco, CA or Remote",
                help="Location affects salary benchmarking"
            )
        
        with peer_col2:
            st.markdown("### 🔍 Analysis Scope")
            st.markdown("""
            **Peer Data Sources:**
            - Industry salary databases
            - Professional networking profiles
            - Job posting requirements
            - Skills trending analysis
            - Competitive benchmarking
            """)
        
        if st.button("🚀 Generate Peer Analysis", type="primary") and target_role:
            with st.spinner("🌐 Analyzing peer data and market intelligence..."):
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                analysis_steps = [
                    "🔍 Gathering peer resume data...",
                    "💰 Analyzing salary benchmarks...",
                    "📊 Comparing skill sets...",
                    "🏆 Evaluating competitive positioning...",
                    "📈 Generating insights..."
                ]
                
                for i, step in enumerate(analysis_steps):
                    status_text.text(step)
                    progress_bar.progress((i + 1) / len(analysis_steps))
                    time.sleep(1.2)
                
                status_text.empty()
                progress_bar.empty()
                
                # Mock peer analysis results
                st.markdown("### 📊 Peer Analysis Results")
                
                # Salary intelligence
                st.markdown('''
                <div class="salary-intelligence">
                    <h4>💰 Salary Intelligence</h4>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h3>$95,000 - $125,000</h3>
                            <p><strong>Median Market Range</strong></p>
                            <p>Your profile: <strong>$110,000 estimated</strong></p>
                        </div>
                        <div class="score-circle" style="width: 80px; height: 80px; font-size: 1.2rem;">
                            78th
                            <small style="font-size: 0.7rem;">percentile</small>
                        </div>
                    </div>
                </div>
                ''', unsafe_allow_html=True)
                
                # Peer comparison metrics
                st.markdown("### 🏆 Competitive Positioning")
                
                metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
                
                with metrics_col1:
                    st.metric("Skills Match", "87%", delta="12%")
                    st.caption("vs. top performers")
                
                with metrics_col2:
                    st.metric("Experience Relevance", "92%", delta="8%")
                    st.caption("vs. peer average")
                
                with metrics_col3:
                    st.metric("Market Readiness", "85%", delta="15%")
                    st.caption("vs. job requirements")
                
                # Peer analysis insights
                st.markdown('''
                <div class="peer-analysis">
                    <h4>🎯 Key Insights from Peer Analysis</h4>
                    <div style="margin: 1rem 0;">
                        <h5>🚀 Your Competitive Advantages:</h5>
                        <ul>
                            <li><strong>Above-average technical depth:</strong> Your Python and ML skills exceed 78% of peers</li>
                            <li><strong>Leadership experience:</strong> Team management puts you in top 25%</li>
                            <li><strong>Industry experience:</strong> Your domain knowledge is highly valued</li>
                        </ul>
                    </div>
                    <div style="margin: 1rem 0;">
                        <h5>⚡ Areas for Improvement:</h5>
                        <ul>
                            <li><strong>Cloud certifications:</strong> 65% of top performers have AWS/Azure certs</li>
                            <li><strong>Open source contributions:</strong> GitHub activity below peer average</li>
                            <li><strong>Industry networking:</strong> Consider increasing professional visibility</li>
                        </ul>
                    </div>
                </div>
                ''', unsafe_allow_html=True)
                
                # Word cloud analysis
                st.markdown("### ☁️ Skills Word Cloud Analysis")
                
                st.markdown('''
                <div class="word-cloud-container">
                    <h4>🔍 Top Skills in Your Field</h4>
                    <div style="background: #f0f8ff; padding: 2rem; border-radius: 10px; margin: 1rem 0;">
                        <div style="font-size: 2rem; color: #1e88e5; display: inline-block; margin: 0.5rem;">Python</div>
                        <div style="font-size: 1.5rem; color: #43a047; display: inline-block; margin: 0.5rem;">Machine Learning</div>
                        <div style="font-size: 1.8rem; color: #e53935; display: inline-block; margin: 0.5rem;">AWS</div>
                        <div style="font-size: 1.3rem; color: #fb8c00; display: inline-block; margin: 0.5rem;">Docker</div>
                        <div style="font-size: 1.6rem; color: #8e24aa; display: inline-block; margin: 0.5rem;">React</div>
                        <div style="font-size: 1.4rem; color: #00acc1; display: inline-block; margin: 0.5rem;">Kubernetes</div>
                        <div style="font-size: 1.2rem; color: #558b2f; display: inline-block; margin: 0.5rem;">TensorFlow</div>
                        <div style="font-size: 1.7rem; color: #d81b60; display: inline-block; margin: 0.5rem;">PostgreSQL</div>
                    </div>
                    <p><em>Size indicates demand frequency in job postings. Your skills coverage: <strong>85%</strong></em></p>
                </div>
                ''', unsafe_allow_html=True)
                
                # Strategic recommendations
                st.markdown("### 🎯 Strategic Career Recommendations")
                
                rec_col1, rec_col2 = st.columns(2)
                
                with rec_col1:
                    st.markdown('''
                    <div class="ai-insight">
                        <h5>📈 Short-term Actions (3-6 months)</h5>
                        <ul>
                            <li>Obtain AWS Cloud Practitioner certification</li>
                            <li>Contribute to 2-3 open source projects</li>
                            <li>Add quantifiable metrics to achievements</li>
                            <li>Update LinkedIn with recent projects</li>
                        </ul>
                    </div>
                    ''', unsafe_allow_html=True)
                
                with rec_col2:
                    st.markdown('''
                    <div class="ai-insight">
                        <h5>🚀 Long-term Strategy (6-12 months)</h5>
                        <ul>
                            <li>Develop expertise in MLOps/AI deployment</li>
                            <li>Build portfolio of data science projects</li>
                            <li>Establish thought leadership through blogging</li>
                            <li>Network at industry conferences/meetups</li>
                        </ul>
                    </div>
                    ''', unsafe_allow_html=True)
        
        # Premium upgrade prompt
        st.markdown('''
        <div class="upgrade-prompt">
            <h4>🌟 Unlock Advanced Peer Analysis</h4>
            <p>Get detailed company-specific comparisons, real-time salary tracking, and personalized career path recommendations!</p>
        </div>
        ''', unsafe_allow_html=True)
        
        if st.button("💎 Upgrade to Premium Analysis"):
            st.switch_page("pages/06_Pricing.py")

# Tab 6: Feedback Hub (from page 19)
with tab6:
    st.markdown("## 🎯 Comprehensive Feedback Hub")
    
    if not has_current_resume:
        st.info("📤 Upload a resume first to access feedback tools")
    else:
        # Generate mock feedback data
        st.markdown("### 📊 Resume Analysis Overview")
        
        # Score dashboard
        score_col1, score_col2, score_col3, score_col4 = st.columns(4)
        
        with score_col1:
            st.markdown('''
            <div class="score-circle" style="background: linear-gradient(135deg, #4caf50, #8bc34a);">
                87%
            </div>
            <p style="text-align: center; font-weight: bold;">Overall Score</p>
            ''', unsafe_allow_html=True)
        
        with score_col2:
            st.markdown('''
            <div class="score-circle" style="background: linear-gradient(135deg, #2196f3, #64b5f6);">
                92%
            </div>
            <p style="text-align: center; font-weight: bold;">ATS Compatibility</p>
            ''', unsafe_allow_html=True)
        
        with score_col3:
            st.markdown('''
            <div class="score-circle" style="background: linear-gradient(135deg, #ff9800, #ffb74d);">
                78%
            </div>
            <p style="text-align: center; font-weight: bold;">Keyword Match</p>
            ''', unsafe_allow_html=True)
        
        with score_col4:
            st.markdown('''
            <div class="score-circle" style="background: linear-gradient(135deg, #9c27b0, #ba68c8);">
                84%
            </div>
            <p style="text-align: center; font-weight: bold;">Impact Score</p>
            ''', unsafe_allow_html=True)
        
        # Detailed feedback sections
        feedback_tab1, feedback_tab2, feedback_tab3, feedback_tab4 = st.tabs([
            "📊 Performance Metrics", "🔑 Keyword Analysis", "🌟 STAR Enhancement", "🤖 AI Recommendations"
        ])
        
        with feedback_tab1:
            st.markdown("### 📈 Performance Breakdown")
            
            # Mock resume metrics
            resume_text = current_resume.get('content', 'Sample resume content')
            word_count = len(resume_text.split())
            
            metric_col1, metric_col2, metric_col3 = st.columns(3)
            
            with metric_col1:
                st.metric("Word Count", word_count)
                st.metric("Reading Time", "2.3 min")
                st.metric("Sections", "6")
            
            with metric_col2:
                st.metric("Action Verbs", "18")
                st.metric("Quantified Results", "12")
                st.metric("Industry Keywords", "24")
            
            with metric_col3:
                st.metric("Technical Skills", "15")
                st.metric("Years Experience", "5-7")
                st.metric("Contact Methods", "4")
            
            # Progress indicators
            st.markdown("### 📊 Section Strength Analysis")
            
            sections = {
                "Professional Summary": 85,
                "Work Experience": 78,
                "Skills": 92,
                "Education": 88,
                "Achievements": 75
            }
            
            for section, score in sections.items():
                st.markdown(f"**{section}**")
                st.progress(score / 100)
                st.caption(f"Score: {score}% - {'Excellent' if score > 85 else 'Good' if score > 75 else 'Needs Improvement'}")
        
        with feedback_tab2:
            st.markdown("### 🔍 Keyword Analysis & Optimization")
            
            # Mock keyword analysis
            st.markdown("#### ✅ Well-Covered Keywords")
            strong_keywords = ["Python", "Machine Learning", "Team Leadership", "Agile", "AWS"]
            for keyword in strong_keywords:
                st.markdown(f"🟢 **{keyword}** - Well integrated")
            
            st.markdown("#### ⚠️ Keywords to Strengthen")
            weak_keywords = ["DevOps", "Microservices", "Kubernetes", "CI/CD"]
            for keyword in weak_keywords:
                st.markdown(f"🟡 **{keyword}** - Consider adding more context")
            
            st.markdown("#### ❌ Missing Keywords")
            missing_keywords = ["Docker", "Terraform", "React Native", "GraphQL"]
            for keyword in missing_keywords:
                st.markdown(f"🔴 **{keyword}** - Not found in resume")
            
            # Keyword optimization suggestions
            st.markdown('''
            <div class="feedback-card">
                <h5>💡 Keyword Optimization Tips</h5>
                <ul>
                    <li>Add missing keywords naturally within experience descriptions</li>
                    <li>Use both spelled-out and abbreviated forms (e.g., "Artificial Intelligence (AI)")</li>
                    <li>Include synonyms and related terms</li>
                    <li>Ensure keywords appear in multiple sections when relevant</li>
                </ul>
            </div>
            ''', unsafe_allow_html=True)
        
        with feedback_tab3:
            st.markdown("### 🌟 STAR Method Enhancement")
            
            st.markdown("#### 🎯 STAR Bullet Point Suggestions")
            
            target_role = st.text_input("Target role for STAR bullets:", placeholder="e.g., Senior Software Engineer")
            
            if st.button("Generate STAR Suggestions") or target_role:
                st.markdown("#### ✨ Suggested STAR-Format Bullets:")
                
                star_suggestions = [
                    "**Situation/Task:** Led critical system migration project | **Action:** Architected microservices solution using Docker/Kubernetes | **Result:** Reduced deployment time by 60% and improved system reliability to 99.9% uptime",
                    "**Situation/Task:** Inherited legacy codebase with performance issues | **Action:** Implemented automated testing suite and refactored core algorithms | **Result:** Improved application response time by 45% and reduced bug reports by 70%",
                    "**Situation/Task:** Team missed sprint goals consistently | **Action:** Introduced agile coaching and improved estimation processes | **Result:** Increased sprint completion rate from 65% to 92% over 6 months"
                ]
                
                for i, suggestion in enumerate(star_suggestions, 1):
                    st.markdown(f'''
                    <div class="ai-insight">
                        <h6>STAR Example {i}:</h6>
                        <p>{suggestion}</p>
                    </div>
                    ''', unsafe_allow_html=True)
        
        with feedback_tab4:
            st.markdown("### 🤖 AI-Powered Recommendations")
            
            # Holly's AI suggestions
            st.markdown('''
            <div class="feedback-card">
                <h4>🤖 Holly's Analysis</h4>
                <p><em>AI-powered insights based on successful resumes in your field</em></p>
            </div>
            ''', unsafe_allow_html=True)
            
            ai_recommendations = [
                {
                    "category": "🎯 Content Optimization",
                    "suggestions": [
                        "Add more quantifiable metrics to your achievements",
                        "Include specific technologies and tools you've mastered",
                        "Mention the size of teams you've led or collaborated with",
                        "Highlight cost savings or revenue impact where possible"
                    ]
                },
                {
                    "category": "📝 Format Enhancement",
                    "suggestions": [
                        "Consider using consistent bullet point formatting",
                        "Ensure proper spacing between sections",
                        "Use a professional font (Arial, Calibri, or Times New Roman)",
                        "Keep margins between 0.5-1 inch for ATS compatibility"
                    ]
                },
                {
                    "category": "🚀 Strategic Positioning",
                    "suggestions": [
                        "Lead with your strongest, most relevant experience",
                        "Tailor your professional summary to target roles",
                        "Include industry-specific certifications prominently",
                        "Balance technical skills with leadership abilities"
                    ]
                }
            ]
            
            for rec in ai_recommendations:
                with st.expander(rec["category"]):
                    for suggestion in rec["suggestions"]:
                        st.markdown(f"• {suggestion}")
            
            # Overall recommendation
            st.markdown('''
            <div class="ai-insight">
                <h5>🎉 Overall Assessment</h5>
                <p>Your resume demonstrates strong technical expertise and leadership potential. Focus on quantifying your impact and ensuring ATS compatibility. With the suggested improvements, you're well-positioned for senior-level opportunities in your field.</p>
            </div>
            ''', unsafe_allow_html=True)

# Bottom action section
st.markdown("---")
st.markdown("## 🚀 Next Steps & Advanced Features")

next_col1, next_col2, next_col3 = st.columns(3)

with next_col1:
    st.markdown('''
    <div class="feature-showcase">
        <h4>🎯 Job Matching</h4>
        <p>Find opportunities that match your optimized resume</p>
    </div>
    ''', unsafe_allow_html=True)
    
    if st.button("🔍 Find Job Matches", use_container_width=True, type="primary"):
        st.switch_page("pages/16_Job_Match.py")

with next_col2:
    st.markdown('''
    <div class="feature-showcase">
        <h4>📊 Career Intelligence</h4>
        <p>Deep dive into career insights and market analysis</p>
    </div>
    ''', unsafe_allow_html=True)
    
    if st.button("🧠 Career Analysis", use_container_width=True):
        st.switch_page("pages/11_Career_Intelligence_Suite.py")

with next_col3:
    st.markdown('''
    <div class="feature-showcase">
        <h4>💎 Premium Features</h4>
        <p>Unlock advanced analytics and personalized coaching</p>
    </div>
    ''', unsafe_allow_html=True)
    
    if st.button("⭐ Upgrade to Premium", use_container_width=True):
        st.switch_page("pages/06_Pricing.py")

# Footer
st.markdown("---")
st.markdown(f"""
<div style="text-align: center; color: #666; padding: 2rem; background: #f8f9fa; border-radius: 10px;">
    <p><strong>IntelliCV-AI Resume Suite</strong> | Complete Resume Optimization Hub</p>
    <p>🔒 Secure Processing • 🤖 AI-Powered Analysis • 📊 Peer Intelligence • 🎯 Career Optimization</p>
    <p>💡 <strong>Pro Tip:</strong> Regular optimization keeps you competitive in the job market</p>
    <p style="font-size: 0.9rem; margin-top: 1rem;">
        📈 Analyzing resumes from {total_versions} versions • 🎯 {total_applications} applications tracked • 
        📊 Peer data from 50,000+ professionals in your field
    </p>
</div>
""", unsafe_allow_html=True)