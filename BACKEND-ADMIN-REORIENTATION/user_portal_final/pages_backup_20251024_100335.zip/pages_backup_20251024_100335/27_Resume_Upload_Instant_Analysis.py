"""
📄 IntelliCV-AI Resume Upload - Instant Analysis & Précis Generation
================================================================
Upload your resume and get immediate parsing, keyword extraction, and professional précis
Enhanced with instant feedback, modification suggestions, and AI-powered insights
"""

import streamlit as st
from pathlib import Path
import sys
import time
import json
import re
from datetime import datetime
import tempfile
import os
import hashlib

# Setup paths and imports
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

# Import token management
try:
    from token_management_system import TokenManager
    TOKEN_SYSTEM_AVAILABLE = True
except ImportError:
    TOKEN_SYSTEM_AVAILABLE = False

# Import admin AI integration
try:
    from user_portal_admin_integration import process_user_action_with_admin_ai, init_admin_ai_for_user_page
    ADMIN_AI_AVAILABLE = True
except ImportError:
    ADMIN_AI_AVAILABLE = False

# Import utilities with fallbacks
try:
    from utils.error_handler import log_user_action, show_error, show_success, show_warning
    ERROR_HANDLER_AVAILABLE = True
except ImportError:
    ERROR_HANDLER_AVAILABLE = False
    def log_user_action(action, details=None): pass
    def show_error(msg): st.error(f"❌ {msg}")
    def show_success(msg): st.success(f"✅ {msg}")
    def show_warning(msg): st.warning(f"⚠️ {msg}")

# Page configuration
st.set_page_config(
    page_title="📄 Instant Resume Analysis | IntelliCV-AI",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Authentication check
if not st.session_state.get('authenticated_user'):
    st.error("🔒 Please log in to upload your resume")
    if st.button("🏠 Return to Home"):
        st.switch_page("pages/00_Home.py")
    st.stop()

# Token Management Check
if TOKEN_SYSTEM_AVAILABLE:
    token_manager = TokenManager()
    if not token_manager.check_page_access(st.session_state.get('user_id'), 'resume_upload_instant'):
        st.error("🪙 Insufficient tokens for Instant Resume Analysis (Cost: 5 tokens)")
        if st.button("💰 Get More Tokens"):
            st.switch_page("pages/02_Payment.py")
        st.stop()

# Resume Analysis Engine
class InstantResumeAnalyzer:
    def __init__(self):
        self.skill_keywords = {
            'technical': ['python', 'java', 'javascript', 'react', 'node.js', 'sql', 'aws', 'docker', 'kubernetes', 'git'],
            'management': ['leadership', 'project management', 'team lead', 'scrum', 'agile', 'strategic planning'],
            'communication': ['presentation', 'communication', 'public speaking', 'writing', 'documentation'],
            'analytical': ['data analysis', 'statistics', 'excel', 'tableau', 'powerbi', 'research', 'problem solving']
        }
        
        self.action_verbs = [
            'achieved', 'improved', 'increased', 'developed', 'managed', 'led', 'created', 'designed',
            'implemented', 'optimized', 'reduced', 'enhanced', 'delivered', 'coordinated', 'analyzed'
        ]
        
        self.industry_keywords = {
            'technology': ['software', 'development', 'tech', 'digital', 'AI', 'machine learning', 'cloud'],
            'finance': ['financial', 'banking', 'investment', 'trading', 'risk', 'compliance'],
            'healthcare': ['medical', 'healthcare', 'clinical', 'patient', 'pharmaceutical'],
            'education': ['education', 'teaching', 'training', 'curriculum', 'academic'],
            'marketing': ['marketing', 'advertising', 'brand', 'campaign', 'social media']
        }
    
    def extract_text_from_content(self, file_content, file_type):
        """Extract text from uploaded file content"""
        try:
            if file_type == 'text/plain':
                return file_content.decode('utf-8')
            elif 'pdf' in file_type:
                # For PDF, we'll simulate extraction (in real implementation, use PyPDF2 or similar)
                return "PDF content extracted - " + str(file_content[:500])
            else:
                # For other formats, attempt basic text extraction
                return str(file_content)
        except Exception as e:
            return f"Text extraction error: {str(e)}"
    
    def analyze_resume_content(self, text_content):
        """Perform instant analysis of resume content"""
        analysis = {
            'word_count': len(text_content.split()),
            'character_count': len(text_content),
            'sections_detected': [],
            'skills_found': {},
            'action_verbs_used': [],
            'industry_indicators': {},
            'quantifiable_achievements': [],
            'recommendations': [],
            'strength_score': 0
        }
        
        text_lower = text_content.lower()
        
        # Detect resume sections
        sections = ['summary', 'experience', 'education', 'skills', 'projects', 'certifications']
        analysis['sections_detected'] = [section for section in sections if section in text_lower]
        
        # Find skills by category
        for category, skills in self.skill_keywords.items():
            found_skills = [skill for skill in skills if skill in text_lower]
            if found_skills:
                analysis['skills_found'][category] = found_skills
        
        # Find action verbs
        analysis['action_verbs_used'] = [verb for verb in self.action_verbs if verb in text_lower]
        
        # Detect industry
        for industry, keywords in self.industry_keywords.items():
            matches = sum(1 for keyword in keywords if keyword in text_lower)
            if matches > 0:
                analysis['industry_indicators'][industry] = matches
        
        # Find quantifiable achievements (numbers followed by units or percentages)
        numbers_pattern = r'\b\d+(?:\.\d+)?%?\b|\$\d+(?:,\d{3})*(?:\.\d{2})?'
        analysis['quantifiable_achievements'] = re.findall(numbers_pattern, text_content)
        
        # Generate recommendations
        analysis['recommendations'] = self.generate_recommendations(analysis, text_content)
        
        # Calculate strength score
        analysis['strength_score'] = self.calculate_strength_score(analysis)
        
        return analysis
    
    def generate_recommendations(self, analysis, text_content):
        """Generate specific improvement recommendations"""
        recommendations = []
        
        # Check for missing sections
        expected_sections = ['summary', 'experience', 'education', 'skills']
        missing_sections = [s for s in expected_sections if s not in analysis['sections_detected']]
        if missing_sections:
            recommendations.append(f"Consider adding these sections: {', '.join(missing_sections)}")
        
        # Check for action verbs
        if len(analysis['action_verbs_used']) < 5:
            recommendations.append("Use more action verbs to make your achievements more impactful")
        
        # Check for quantifiable achievements
        if len(analysis['quantifiable_achievements']) < 3:
            recommendations.append("Add more quantifiable achievements with numbers, percentages, or dollar amounts")
        
        # Check word count
        if analysis['word_count'] < 200:
            recommendations.append("Your resume might be too brief - consider adding more detail about your experience")
        elif analysis['word_count'] > 800:
            recommendations.append("Your resume might be too long - consider condensing to key achievements")
        
        # Check for skills diversity
        if len(analysis['skills_found']) < 2:
            recommendations.append("Consider highlighting skills from multiple categories (technical, management, communication)")
        
        return recommendations
    
    def calculate_strength_score(self, analysis):
        """Calculate overall resume strength score (0-100)"""
        score = 0
        
        # Sections (30 points max)
        score += min(len(analysis['sections_detected']) * 7.5, 30)
        
        # Skills diversity (25 points max)
        score += min(len(analysis['skills_found']) * 6.25, 25)
        
        # Action verbs (20 points max)
        score += min(len(analysis['action_verbs_used']) * 2, 20)
        
        # Quantifiable achievements (15 points max)
        score += min(len(analysis['quantifiable_achievements']) * 3, 15)
        
        # Word count appropriateness (10 points max)
        if 300 <= analysis['word_count'] <= 600:
            score += 10
        elif 200 <= analysis['word_count'] <= 800:
            score += 7
        else:
            score += 3
        
        return min(int(score), 100)
    
    def generate_professional_precis(self, analysis, original_text):
        """Generate a professional précis of the resume"""
        
        # Extract key information
        skills_summary = []
        for category, skills in analysis['skills_found'].items():
            if skills:
                skills_summary.append(f"{category}: {', '.join(skills[:3])}")
        
        industry_focus = max(analysis['industry_indicators'].items(), key=lambda x: x[1])[0] if analysis['industry_indicators'] else "General"
        
        achievement_count = len(analysis['quantifiable_achievements'])
        
        precis_parts = [
            f"**Professional Summary:** {industry_focus.title()} professional",
            f"**Key Strengths:** {len(analysis['skills_found'])} skill categories identified",
            f"**Quantified Impact:** {achievement_count} measurable achievements documented",
            f"**Communication Style:** {len(analysis['action_verbs_used'])} action-oriented statements"
        ]
        
        if skills_summary:
            precis_parts.append(f"**Core Competencies:** {'; '.join(skills_summary)}")
        
        # Add improvement focus
        if analysis['recommendations']:
            precis_parts.append(f"**Enhancement Opportunities:** {len(analysis['recommendations'])} areas for optimization")
        
        return "\n\n".join(precis_parts)

# Professional CSS styling with 30% logo background
def load_resume_upload_css():
    """Load resume upload page CSS with instant analysis styling"""
    css = '''
    <style>
    /* Clean background with logo watermark */
    .stApp {
        background: linear-gradient(135deg, rgba(102, 126, 234, 0.3) 0%, rgba(118, 75, 162, 0.3) 100%);
        position: relative;
    }
    
    /* 30% Logo Background Watermark */
    .stApp::before {
        content: '';
        position: fixed;
        top: 20%;
        left: 20%;
        width: 60%;
        height: 60%;
        background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><text x="50%" y="50%" font-family="Arial" font-size="20" font-weight="bold" text-anchor="middle" dy=".3em" fill="%23667eea" opacity="0.08">IntelliCV-AI</text></svg>');
        background-repeat: no-repeat;
        background-position: center;
        background-size: contain;
        pointer-events: none;
        z-index: -1;
    }
    
    /* Main Container */
    .main .block-container {
        background: rgba(255,255,255,0.97) !important;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.15);
        margin-top: 1rem;
        backdrop-filter: blur(10px);
        max-width: 1400px;
        margin-left: auto;
        margin-right: auto;
    }
    
    /* Header styling */
    .upload-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2.5rem;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 6px 20px rgba(0,0,0,0.2);
    }
    
    .upload-header h1 {
        font-size: 2.2rem;
        margin-bottom: 0.5rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    /* Upload zone */
    .upload-zone {
        border: 3px dashed #667eea;
        border-radius: 12px;
        padding: 3rem;
        text-align: center;
        background: #f8f9fa;
        margin: 2rem 0;
        transition: all 0.3s ease;
    }
    
    .upload-zone:hover {
        border-color: #764ba2;
        background: #f0f2f6;
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    /* Instant analysis results */
    .analysis-container {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        border: 1px solid #e0e0e0;
        margin: 2rem 0;
    }
    
    .strength-score {
        text-align: center;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
    
    .score-excellent { background: linear-gradient(45deg, #28a745, #20c997); color: white; }
    .score-good { background: linear-gradient(45deg, #ffc107, #fd7e14); color: white; }
    .score-needs-work { background: linear-gradient(45deg, #dc3545, #fd7e14); color: white; }
    
    .keyword-badge {
        background: #e3f2fd;
        color: #1976d2;
        padding: 0.3rem 0.8rem;
        border-radius: 15px;
        font-size: 0.8rem;
        margin: 0.2rem;
        display: inline-block;
        border: 1px solid #bbdefb;
    }
    
    .recommendation-item {
        background: #fff3cd;
        border-left: 4px solid #ffc107;
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 0 5px 5px 0;
    }
    
    .precis-container {
        background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        padding: 2rem;
        border-radius: 12px;
        border: 2px solid #667eea;
        margin: 2rem 0;
    }
    
    .analysis-metric {
        text-align: center;
        padding: 1rem;
        margin: 0.5rem;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .metric-value {
        font-size: 1.8rem;
        font-weight: bold;
        color: #667eea;
    }
    
    .metric-label {
        font-size: 0.9rem;
        color: #666;
    }
    </style>
    '''
    st.markdown(css, unsafe_allow_html=True)

# Load CSS
load_resume_upload_css()

# Initialize resume analyzer
analyzer = InstantResumeAnalyzer()

# Initialize Admin AI Integration
if ADMIN_AI_AVAILABLE:
    admin_ai = init_admin_ai_for_user_page()

# Log page access and consume tokens
if ERROR_HANDLER_AVAILABLE:
    log_user_action("page_view", {"page": "resume_upload_instant", "timestamp": datetime.now().isoformat()})

if TOKEN_SYSTEM_AVAILABLE:
    token_manager.consume_page_tokens(st.session_state.get('user_id'), 'resume_upload_instant', 5)

# Header
st.markdown('''
<div class="upload-header">
    <h1>📄 Instant Resume Analysis</h1>
    <p>Upload your resume and get <strong>immediate parsing, keyword extraction, and professional précis</strong></p>
    <p><small>✨ Powered by AI for instant feedback and optimization suggestions</small></p>
</div>
''', unsafe_allow_html=True)

# Sidebar with progress and tips
with st.sidebar:
    st.markdown("### 📊 Analysis Progress")
    
    # Show current analysis status
    analysis_status = st.session_state.get('resume_analysis_status', 'waiting')
    status_icons = {
        'waiting': '⏳ Waiting for upload',
        'processing': '🔄 Analyzing content...',
        'complete': '✅ Analysis complete',
        'error': '❌ Analysis failed'
    }
    st.markdown(f"**Status:** {status_icons.get(analysis_status, '⏳ Waiting')}")
    
    # Show file info if uploaded
    if 'uploaded_file_info' in st.session_state:
        info = st.session_state['uploaded_file_info']
        st.markdown(f"**File:** {info['name']}")
        st.markdown(f"**Size:** {info['size']/1024:.1f} KB")
        st.markdown(f"**Type:** {info['type']}")
    
    st.markdown("---")
    st.markdown("### 💡 Instant Analysis Features")
    st.markdown("""
    - **🔍 Keyword Extraction** - Find industry-relevant terms
    - **📊 Strength Scoring** - Get objective quality metrics  
    - **📝 Professional Précis** - AI-generated summary
    - **🎯 Optimization Tips** - Specific improvement suggestions
    - **⚡ Real-time Processing** - Results in seconds
    """)
    
    st.markdown("---")
    st.markdown("### 🚀 Quick Actions")
    
    if st.button("👤 Update Profile", use_container_width=True):
        st.switch_page("pages/03_Profile_Setup_Enhanced_AI_Chatbot.py")
    
    if st.button("🎯 Find Jobs", use_container_width=True):
        st.switch_page("pages/06_Job_Match.py")
    
    if st.button("🏠 Dashboard", use_container_width=True):
        st.switch_page("pages/01_Dashboard.py")

# Main content layout
col1, col2 = st.columns([1, 1], gap="large")

with col1:
    # File upload section
    st.markdown('''
    <div class="upload-zone">
        <h3>📂 Upload Your Resume</h3>
        <p>Supported formats: PDF, DOCX, DOC, TXT</p>
        <p><small>Get instant analysis and professional insights</small></p>
    </div>
    ''', unsafe_allow_html=True)
    
    # File uploader
    uploaded_file = st.file_uploader(
        "Choose your resume file",
        type=['pdf', 'docx', 'doc', 'txt'],
        help="Upload your resume for instant AI-powered analysis",
        key="resume_uploader"
    )
    
    if uploaded_file is not None:
        # Store file info
        file_info = {
            'name': uploaded_file.name,
            'size': uploaded_file.size,
            'type': uploaded_file.type
        }
        st.session_state['uploaded_file_info'] = file_info
        st.session_state['resume_analysis_status'] = 'processing'
        
        st.success(f"📄 File uploaded: {uploaded_file.name}")
        
        # Display file details
        col_detail1, col_detail2, col_detail3 = st.columns(3)
        with col_detail1:
            st.metric("File Size", f"{uploaded_file.size/1024:.1f} KB")
        with col_detail2:
            st.metric("File Type", uploaded_file.type.split('/')[-1].upper())
        with col_detail3:
            st.metric("Processing", "Instant")
        
        # Process file with instant analysis
        with st.spinner("🔄 Analyzing your resume..."):
            try:
                # Read file content
                file_content = uploaded_file.read()
                
                # Extract text
                extracted_text = analyzer.extract_text_from_content(file_content, uploaded_file.type)
                
                # Perform instant analysis
                analysis_results = analyzer.analyze_resume_content(extracted_text)
                
                # Store results
                st.session_state['resume_analysis_results'] = analysis_results
                st.session_state['resume_extracted_text'] = extracted_text
                st.session_state['resume_analysis_status'] = 'complete'
                
                show_success("✅ Analysis complete! Results shown on the right.")
                
            except Exception as e:
                st.session_state['resume_analysis_status'] = 'error'
                show_error(f"Analysis failed: {str(e)}")
    
    # Sample data button for testing
    if st.button("📋 Try with Sample Resume", help="Load sample resume for demonstration"):
        sample_text = """
        John Doe
        Software Engineer
        
        Experience:
        - Led team of 5 developers to create web application using Python and React
        - Improved system performance by 40% through database optimization
        - Managed $2M budget for cloud infrastructure migration
        - Developed machine learning models that increased accuracy by 25%
        
        Skills: Python, JavaScript, React, SQL, AWS, Docker, Project Management
        
        Education:
        Bachelor of Science in Computer Science
        """
        
        # Analyze sample text
        analysis_results = analyzer.analyze_resume_content(sample_text)
        st.session_state['resume_analysis_results'] = analysis_results
        st.session_state['resume_extracted_text'] = sample_text
        st.session_state['resume_analysis_status'] = 'complete'
        st.session_state['uploaded_file_info'] = {
            'name': 'sample_resume.txt',
            'size': len(sample_text),
            'type': 'text/plain'
        }
        
        show_success("✅ Sample resume analyzed! Check results on the right.")
        st.rerun()

with col2:
    # Display analysis results
    if st.session_state.get('resume_analysis_status') == 'complete':
        results = st.session_state.get('resume_analysis_results', {})
        
        st.markdown('<div class="analysis-container">', unsafe_allow_html=True)
        st.markdown("### 📊 Instant Analysis Results")
        
        # Strength Score Display
        score = results.get('strength_score', 0)
        score_class = 'score-excellent' if score >= 80 else 'score-good' if score >= 60 else 'score-needs-work'
        score_text = 'Excellent!' if score >= 80 else 'Good Progress' if score >= 60 else 'Needs Enhancement'
        
        st.markdown(f'''
        <div class="strength-score {score_class}">
            <h2>🎯 Resume Strength Score</h2>
            <h1>{score}/100</h1>
            <p>{score_text}</p>
        </div>
        ''', unsafe_allow_html=True)
        
        # Analysis Metrics
        st.markdown("#### 📈 Key Metrics")
        
        col_metric1, col_metric2, col_metric3 = st.columns(3)
        
        with col_metric1:
            st.markdown(f'''
            <div class="analysis-metric">
                <div class="metric-value">{results.get('word_count', 0)}</div>
                <div class="metric-label">Words</div>
            </div>
            ''', unsafe_allow_html=True)
        
        with col_metric2:
            st.markdown(f'''
            <div class="analysis-metric">
                <div class="metric-value">{len(results.get('sections_detected', []))}</div>
                <div class="metric-label">Sections</div>
            </div>
            ''', unsafe_allow_html=True)
        
        with col_metric3:
            st.markdown(f'''
            <div class="analysis-metric">
                <div class="metric-value">{len(results.get('action_verbs_used', []))}</div>
                <div class="metric-label">Action Verbs</div>
            </div>
            ''', unsafe_allow_html=True)
        
        # Skills Found
        if results.get('skills_found'):
            st.markdown("#### 🛠️ Skills Identified")
            for category, skills in results['skills_found'].items():
                st.markdown(f"**{category.title()}:**")
                for skill in skills:
                    st.markdown(f'<span class="keyword-badge">{skill}</span>', unsafe_allow_html=True)
                st.markdown("")
        
        # Industry Indicators
        if results.get('industry_indicators'):
            st.markdown("#### 🏢 Industry Focus")
            for industry, count in results['industry_indicators'].items():
                st.markdown(f"**{industry.title()}:** {count} relevant keywords")
        
        # Quantifiable Achievements
        if results.get('quantifiable_achievements'):
            st.markdown("#### 📊 Quantifiable Results")
            achievements = results['quantifiable_achievements'][:10]  # Limit display
            for achievement in achievements:
                st.markdown(f'<span class="keyword-badge">{achievement}</span>', unsafe_allow_html=True)
            if len(results['quantifiable_achievements']) > 10:
                st.markdown(f"*...and {len(results['quantifiable_achievements']) - 10} more*")
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Professional Précis
        st.markdown('<div class="precis-container">', unsafe_allow_html=True)
        st.markdown("### 📝 Professional Précis")
        
        precis = analyzer.generate_professional_precis(results, st.session_state.get('resume_extracted_text', ''))
        st.markdown(precis)
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Recommendations
        if results.get('recommendations'):
            st.markdown("### 💡 Optimization Recommendations")
            for i, recommendation in enumerate(results['recommendations'], 1):
                st.markdown(f'''
                <div class="recommendation-item">
                    <strong>{i}.</strong> {recommendation}
                </div>
                ''', unsafe_allow_html=True)
        
        # Action Buttons
        st.markdown("---")
        st.markdown("### 🎯 Next Steps")
        
        col_action1, col_action2 = st.columns(2)
        
        with col_action1:
            if st.button("🔄 Upload Different Resume", use_container_width=True):
                # Clear analysis results
                for key in ['resume_analysis_results', 'resume_extracted_text', 'uploaded_file_info']:
                    if key in st.session_state:
                        del st.session_state[key]
                st.session_state['resume_analysis_status'] = 'waiting'
                st.rerun()
        
        with col_action2:
            if st.button("📊 View Detailed Analysis", use_container_width=True):
                # Toggle detailed view
                st.session_state['show_detailed_analysis'] = not st.session_state.get('show_detailed_analysis', False)
                st.rerun()
        
        # Detailed Analysis (expandable)
        if st.session_state.get('show_detailed_analysis', False):
            with st.expander("🔍 Detailed Analysis Data", expanded=True):
                st.json(results)
    
    else:
        # Waiting state
        st.markdown('<div class="analysis-container">', unsafe_allow_html=True)
        st.markdown("### ⏳ Waiting for Resume Upload")
        st.markdown("""
        Upload your resume on the left to see:
        
        - **Instant keyword extraction**
        - **Professional strength scoring**
        - **AI-generated précis**
        - **Specific improvement recommendations**
        - **Industry relevance analysis**
        
        Your analysis will appear here within seconds of upload!
        """)
        st.markdown('</div>', unsafe_allow_html=True)

# Admin AI Enhancement Section (if available)
if ADMIN_AI_AVAILABLE and st.session_state.get('resume_analysis_status') == 'complete':
    st.markdown("---")
    st.markdown("### 🚀 Enhanced Admin AI Analysis")
    
    if st.button("🧠 Get Advanced AI Insights", use_container_width=True):
        with st.spinner("Processing with advanced AI systems..."):
            # Process with admin AI
            user_data = {
                'analysis_results': st.session_state.get('resume_analysis_results'),
                'extracted_text': st.session_state.get('resume_extracted_text'),
                'file_info': st.session_state.get('uploaded_file_info')
            }
            
            try:
                enhanced_result = process_user_action_with_admin_ai('resume_analysis_enhancement', user_data)
                
                if enhanced_result.get('enhanced_data'):
                    st.success("🎯 Enhanced insights generated!")
                    
                    col_insight1, col_insight2 = st.columns(2)
                    
                    with col_insight1:
                        if 'career_trajectory' in enhanced_result['enhanced_data']:
                            st.markdown("**🚀 Career Trajectory Analysis:**")
                            for insight in enhanced_result['enhanced_data']['career_trajectory']:
                                st.write(f"• {insight}")
                    
                    with col_insight2:
                        if 'market_positioning' in enhanced_result['enhanced_data']:
                            st.markdown("**📊 Market Positioning:**")
                            for position in enhanced_result['enhanced_data']['market_positioning']:
                                st.write(f"• {position}")
                
            except Exception as e:
                show_warning(f"Enhanced analysis unavailable: {str(e)}")

# Footer
st.markdown("---")
analysis_count = 1 if st.session_state.get('resume_analysis_status') == 'complete' else 0
footer_text = f"**Analyses Completed:** {analysis_count}"

if TOKEN_SYSTEM_AVAILABLE:
    footer_text += f" | **Tokens Used:** 5"

if st.session_state.get('resume_analysis_status') == 'complete':
    results = st.session_state.get('resume_analysis_results', {})
    footer_text += f" | **Strength Score:** {results.get('strength_score', 0)}/100"

st.markdown(footer_text)
st.markdown(f"**Last Updated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

# Log successful analysis
if st.session_state.get('resume_analysis_status') == 'complete':
    if ERROR_HANDLER_AVAILABLE:
        log_user_action("resume_analysis_completed", {
            'user_id': st.session_state.get('user_id'),
            'strength_score': st.session_state.get('resume_analysis_results', {}).get('strength_score', 0),
            'analysis_timestamp': datetime.now().isoformat()
        })