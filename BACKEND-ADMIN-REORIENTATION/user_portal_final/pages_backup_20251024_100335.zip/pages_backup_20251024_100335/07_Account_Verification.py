import streamlit as st

st.set_page_config(page_title="Verify Your Account", page_icon="✅")
st.title("✅ Account Verification")

user_email = st.session_state.get("user_email", "Unknown User")
st.caption(f"👤 Logged in as: **{user_email}**")

if st.session_state.get("email_verified"):
    st.success("📧 Your email has been successfully verified!")
else:
    st.warning("⚠️ Please verify your email via the link sent to your inbox.")

st.markdown("### 🔐 Two-Factor Authentication (2FA)")
enable_2fa = st.checkbox("Enable Two-Factor Authentication", value=st.session_state.get("enable_2fa", False))
st.session_state["enable_2fa"] = enable_2fa

if enable_2fa:
    st.success("2FA is enabled for your account.")
else:
    st.info("2FA is currently disabled.")

st.markdown("---")
st.markdown("### 🛠️ Admin/Developer Section (Visible in Dev Mode Only)")

st.info("This section will be shown only to admin/super users later.")

if st.checkbox("🔐 Show Debug Token"):
    st.code("DEBUG-TOKEN-PLACEHOLDER-123456")

if st.checkbox("🧪 View Session State"):
    st.json(dict(st.session_state))

if st.checkbox("📁 Simulate Admin Panel"):
    st.warning("Admin Panel coming soon... access restricted in production.")
