"""
📄 IntelliCV-AI Resume Upload - Career Intelligence Express
==========================================================
Quick resume upload with instant career intelligence analysis:
- Instant parsing and keyword extraction  
- Professional précis generation
- Real-time peer comparison and job matching
- Express career optimization recommendations
- Backend admin AI integration for enhanced insights

Merged features from Enhanced Career Intelligence + Instant Analysis
"""

import streamlit as st
from pathlib import Path
import sys
import time
import json
import re
from datetime import datetime
import tempfile
import os
import hashlib
import plotly.express as px
import plotly.graph_objects as go
from wordcloud import WordCloud
import pandas as pd
import numpy as np
import base64

# Setup paths and imports
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

# Import shared components
try:
    from shared_components import apply_professional_styling, show_logo_watermark, initialize_session_manager
    SHARED_COMPONENTS_AVAILABLE = True
except ImportError:
    SHARED_COMPONENTS_AVAILABLE = False

# Import token management
try:
    from token_management_system import TokenManager
    TOKEN_SYSTEM_AVAILABLE = True
except ImportError:
    TOKEN_SYSTEM_AVAILABLE = False

# Import admin AI integration
try:
    from user_portal_admin_integration import AdminAIIntegration
    ADMIN_AI_AVAILABLE = True
except ImportError:
    ADMIN_AI_AVAILABLE = False

class CareerIntelligenceExpress:
    """Express career intelligence engine combining instant analysis with deep insights"""
    
    def __init__(self):
        self.token_manager = TokenManager() if TOKEN_SYSTEM_AVAILABLE else None
        self.admin_ai = AdminAIIntegration() if ADMIN_AI_AVAILABLE else None
        self.initialize_session_state()
        
    def initialize_session_state(self):
        """Initialize session state variables"""
        if 'career_express_analysis' not in st.session_state:
            st.session_state.career_express_analysis = {}
        if 'instant_keywords' not in st.session_state:
            st.session_state.instant_keywords = []
        if 'express_precis' not in st.session_state:
            st.session_state.express_precis = ""
        if 'career_touchpoints' not in st.session_state:
            st.session_state.career_touchpoints = []
            
    def parse_resume_instant(self, file_content: str) -> dict:
        """Instant resume parsing for quick analysis"""
        try:
            # Basic text processing
            lines = file_content.split('\n')
            text_clean = re.sub(r'\s+', ' ', file_content).strip()
            
            # Instant keyword extraction
            keywords = self.extract_keywords_instant(text_clean)
            
            # Quick metrics
            word_count = len(text_clean.split())
            line_count = len([l for l in lines if l.strip()])
            
            # Technical skills detection
            tech_skills = self.detect_technical_skills(text_clean)
            
            # Experience level detection
            experience_level = self.detect_experience_level(text_clean)
            
            # Industry classification
            industry = self.classify_industry_instant(text_clean)
            
            analysis = {
                'keywords': keywords,
                'word_count': word_count,
                'line_count': line_count,
                'tech_skills': tech_skills,
                'experience_level': experience_level,
                'industry': industry,
                'processing_time': time.time(),
                'quality_score': self.calculate_quality_score(text_clean)
            }
            
            # Store in session
            st.session_state.career_express_analysis = analysis
            st.session_state.instant_keywords = keywords
            
            return analysis
            
        except Exception as e:
            st.error(f"Error in instant parsing: {str(e)}")
            return {}
    
    def extract_keywords_instant(self, text: str) -> list:
        """Instant keyword extraction with categorization"""
        # Technical keywords
        tech_keywords = [
            'python', 'java', 'javascript', 'sql', 'aws', 'azure', 'docker', 'kubernetes',
            'machine learning', 'ai', 'data science', 'analytics', 'cloud', 'agile',
            'project management', 'leadership', 'strategy', 'business development'
        ]
        
        # Management keywords
        mgmt_keywords = [
            'manager', 'director', 'lead', 'senior', 'head', 'chief', 'vp', 'president',
            'team', 'leadership', 'strategy', 'planning', 'budget', 'p&l'
        ]
        
        # Industry keywords
        industry_keywords = [
            'finance', 'healthcare', 'technology', 'education', 'manufacturing',
            'retail', 'consulting', 'marketing', 'sales', 'operations'
        ]
        
        text_lower = text.lower()
        found_keywords = []
        
        # Check technical skills
        for keyword in tech_keywords:
            if keyword in text_lower:
                found_keywords.append({
                    'keyword': keyword,
                    'category': 'Technical',
                    'frequency': text_lower.count(keyword)
                })
        
        # Check management skills
        for keyword in mgmt_keywords:
            if keyword in text_lower:
                found_keywords.append({
                    'keyword': keyword,
                    'category': 'Management',
                    'frequency': text_lower.count(keyword)
                })
        
        # Check industry keywords
        for keyword in industry_keywords:
            if keyword in text_lower:
                found_keywords.append({
                    'keyword': keyword,
                    'category': 'Industry',
                    'frequency': text_lower.count(keyword)
                })
        
        # Sort by frequency
        found_keywords.sort(key=lambda x: x['frequency'], reverse=True)
        
        return found_keywords[:20]  # Return top 20
    
    def detect_technical_skills(self, text: str) -> list:
        """Detect technical skills from resume text"""
        tech_patterns = [
            r'\b(Python|Java|JavaScript|SQL|AWS|Azure|Docker|Kubernetes)\b',
            r'\b(Machine Learning|AI|Data Science|Analytics|Cloud)\b',
            r'\b(React|Angular|Vue|Node\.js|Express|Django|Flask)\b',
            r'\b(PostgreSQL|MySQL|MongoDB|Redis|Elasticsearch)\b'
        ]
        
        skills = []
        for pattern in tech_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            skills.extend(matches)
        
        return list(set(skills))
    
    def detect_experience_level(self, text: str) -> str:
        """Detect experience level from resume content"""
        text_lower = text.lower()
        
        # Senior level indicators
        senior_indicators = ['senior', 'lead', 'principal', 'architect', 'director', 'manager']
        senior_count = sum(1 for indicator in senior_indicators if indicator in text_lower)
        
        # Years of experience detection
        years_pattern = r'(\d+)\+?\s*years?\s*(of\s*)?experience'
        years_matches = re.findall(years_pattern, text_lower)
        max_years = max([int(match[0]) for match in years_matches], default=0)
        
        if senior_count >= 3 or max_years >= 10:
            return "Senior Level (10+ years)"
        elif senior_count >= 1 or max_years >= 5:
            return "Mid Level (5-10 years)"
        elif max_years >= 2:
            return "Junior Level (2-5 years)"
        else:
            return "Entry Level (0-2 years)"
    
    def classify_industry_instant(self, text: str) -> str:
        """Quick industry classification"""
        industry_mapping = {
            'Technology': ['software', 'technology', 'tech', 'it', 'computer', 'digital'],
            'Finance': ['finance', 'banking', 'investment', 'trading', 'fintech'],
            'Healthcare': ['healthcare', 'medical', 'hospital', 'clinical', 'pharma'],
            'Education': ['education', 'university', 'school', 'academic', 'research'],
            'Manufacturing': ['manufacturing', 'production', 'industrial', 'engineering'],
            'Consulting': ['consulting', 'consultant', 'advisory', 'strategy'],
            'Marketing': ['marketing', 'advertising', 'brand', 'digital marketing'],
            'Sales': ['sales', 'business development', 'account management']
        }
        
        text_lower = text.lower()
        industry_scores = {}
        
        for industry, keywords in industry_mapping.items():
            score = sum(text_lower.count(keyword) for keyword in keywords)
            if score > 0:
                industry_scores[industry] = score
        
        if industry_scores:
            return max(industry_scores, key=industry_scores.get)
        return "General"
    
    def calculate_quality_score(self, text: str) -> int:
        """Calculate resume quality score (0-100)"""
        score = 0
        
        # Length check (20 points)
        word_count = len(text.split())
        if word_count >= 300:
            score += 20
        elif word_count >= 150:
            score += 15
        elif word_count >= 100:
            score += 10
        
        # Contact information (15 points)
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        phone_pattern = r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
        
        if re.search(email_pattern, text):
            score += 10
        if re.search(phone_pattern, text):
            score += 5
        
        # Skills section (20 points)
        skills_indicators = ['skills', 'expertise', 'proficient', 'experienced']
        if any(indicator in text.lower() for indicator in skills_indicators):
            score += 20
        
        # Experience section (25 points)
        exp_indicators = ['experience', 'work history', 'employment', 'worked at']
        if any(indicator in text.lower() for indicator in exp_indicators):
            score += 25
        
        # Education section (10 points)
        edu_indicators = ['education', 'degree', 'university', 'college', 'graduated']
        if any(indicator in text.lower() for indicator in edu_indicators):
            score += 10
        
        # Action verbs (10 points)
        action_verbs = ['managed', 'developed', 'created', 'implemented', 'led', 'achieved']
        verb_count = sum(1 for verb in action_verbs if verb in text.lower())
        score += min(verb_count * 2, 10)
        
        return min(score, 100)
    
    def generate_express_precis(self, analysis: dict, text: str) -> str:
        """Generate professional précis from analysis"""
        try:
            experience_level = analysis.get('experience_level', 'Professional')
            industry = analysis.get('industry', 'General')
            tech_skills = analysis.get('tech_skills', [])
            keywords = analysis.get('keywords', [])
            
            # Top skills from keywords
            top_skills = [kw['keyword'] for kw in keywords[:5] if kw['category'] == 'Technical']
            mgmt_skills = [kw['keyword'] for kw in keywords if kw['category'] == 'Management']
            
            # Generate précis
            precis_parts = []
            
            # Experience level and industry
            precis_parts.append(f"{experience_level} professional in {industry}")
            
            # Technical expertise
            if top_skills:
                skills_text = ", ".join(top_skills[:3])
                precis_parts.append(f"with expertise in {skills_text}")
            
            # Management experience
            if mgmt_skills:
                precis_parts.append("and proven leadership capabilities")
            
            # Quality indicator
            quality_score = analysis.get('quality_score', 0)
            if quality_score >= 80:
                precis_parts.append("Comprehensive professional profile with strong qualifications")
            elif quality_score >= 60:
                precis_parts.append("Well-rounded professional background")
            
            precis = ". ".join(precis_parts) + "."
            
            # Store in session
            st.session_state.express_precis = precis
            
            return precis
            
        except Exception as e:
            return f"Professional with diverse experience in {analysis.get('industry', 'multiple sectors')}."
    
    def create_express_dashboard(self, analysis: dict, precis: str):
        """Create express analysis dashboard"""
        
        # Header with processing info
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            st.markdown("### 📊 Express Analysis Results")
        
        with col2:
            st.metric("Quality Score", f"{analysis.get('quality_score', 0)}/100")
        
        with col3:
            st.metric("Keywords Found", len(analysis.get('keywords', [])))
        
        # Professional Précis
        st.markdown("### 📝 Professional Précis")
        st.info(precis)
        
        # Quick metrics
        metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
        
        with metrics_col1:
            st.metric("Word Count", analysis.get('word_count', 0))
        
        with metrics_col2:
            st.metric("Experience Level", analysis.get('experience_level', 'N/A'))
        
        with metrics_col3:
            st.metric("Industry", analysis.get('industry', 'General'))
        
        # Keywords breakdown
        keywords = analysis.get('keywords', [])
        if keywords:
            st.markdown("### 🔍 Top Keywords by Category")
            
            # Categorize keywords
            tech_keywords = [k for k in keywords if k['category'] == 'Technical']
            mgmt_keywords = [k for k in keywords if k['category'] == 'Management']
            industry_keywords = [k for k in keywords if k['category'] == 'Industry']
            
            kw_col1, kw_col2, kw_col3 = st.columns(3)
            
            with kw_col1:
                if tech_keywords:
                    st.markdown("**🔧 Technical Skills**")
                    for kw in tech_keywords[:5]:
                        st.markdown(f"• {kw['keyword']} ({kw['frequency']})")
            
            with kw_col2:
                if mgmt_keywords:
                    st.markdown("**👥 Management Skills**")
                    for kw in mgmt_keywords[:5]:
                        st.markdown(f"• {kw['keyword']} ({kw['frequency']})")
            
            with kw_col3:
                if industry_keywords:
                    st.markdown("**🏢 Industry Experience**")
                    for kw in industry_keywords[:5]:
                        st.markdown(f"• {kw['keyword']} ({kw['frequency']})")
        
        # Technical skills visualization
        tech_skills = analysis.get('tech_skills', [])
        if tech_skills:
            st.markdown("### 💻 Technical Skills Detected")
            skills_text = " • ".join(tech_skills)
            st.markdown(f"**{skills_text}**")
        
        # Quick recommendations
        self.show_express_recommendations(analysis)
    
    def show_express_recommendations(self, analysis: dict):
        """Show quick optimization recommendations"""
        st.markdown("### 🎯 Express Optimization Tips")
        
        quality_score = analysis.get('quality_score', 0)
        recommendations = []
        
        if quality_score < 60:
            recommendations.append("📝 **Expand Content**: Add more detail to your experience and achievements")
        
        if not analysis.get('tech_skills'):
            recommendations.append("💻 **Technical Skills**: Include relevant technical skills and tools")
        
        if len(analysis.get('keywords', [])) < 10:
            recommendations.append("🔍 **Keywords**: Include more industry-relevant keywords")
        
        if analysis.get('experience_level') == 'Entry Level (0-2 years)':
            recommendations.append("🎓 **Education**: Highlight relevant coursework and projects")
        
        if recommendations:
            for rec in recommendations:
                st.markdown(rec)
        else:
            st.success("✅ **Great job!** Your resume shows strong professional presence")
    
    def create_peer_comparison_express(self, analysis: dict):
        """Create express peer comparison visualization"""
        st.markdown("### 👥 Quick Peer Comparison")
        
        # Simulated peer data based on analysis
        industry = analysis.get('industry', 'General')
        experience_level = analysis.get('experience_level', 'Mid Level')
        
        # Create comparison chart
        categories = ['Technical Skills', 'Management', 'Industry Knowledge', 'Communication', 'Leadership']
        
        # Generate scores based on analysis
        your_scores = []
        peer_scores = []
        
        for category in categories:
            if category == 'Technical Skills':
                score = min(len(analysis.get('tech_skills', [])) * 15, 100)
            elif category == 'Management':
                mgmt_kw = [k for k in analysis.get('keywords', []) if k['category'] == 'Management']
                score = min(len(mgmt_kw) * 20, 100)
            else:
                score = analysis.get('quality_score', 50) + np.random.randint(-20, 20)
            
            your_scores.append(max(0, min(100, score)))
            peer_scores.append(np.random.randint(60, 85))  # Simulated peer average
        
        # Create radar chart
        fig = go.Figure()
        
        fig.add_trace(go.Scatterpolar(
            r=your_scores,
            theta=categories,
            fill='toself',
            name='Your Profile',
            line_color='#1f77b4'
        ))
        
        fig.add_trace(go.Scatterpolar(
            r=peer_scores,
            theta=categories,
            fill='toself',
            name='Industry Average',
            line_color='#ff7f0e',
            opacity=0.6
        ))
        
        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 100]
                )),
            showlegend=True,
            title="Skills Comparison vs Industry Peers"
        )
        
        st.plotly_chart(fig, use_container_width=True)

def main():
    """Main function for Career Intelligence Express page"""
    
    # Apply styling
    if SHARED_COMPONENTS_AVAILABLE:
        apply_professional_styling()
        show_logo_watermark()
    
    # Initialize intelligence engine
    career_express = CareerIntelligenceExpress()
    
    # Page header with gradient
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                padding: 2rem; border-radius: 10px; margin-bottom: 2rem; color: white;">
        <h1 style="margin: 0; font-size: 2.5rem;">⚡ Career Intelligence Express</h1>
        <p style="margin: 0.5rem 0 0 0; font-size: 1.2rem; opacity: 0.9;">
            Quick resume upload with instant career intelligence analysis
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Backend integration status
    if ADMIN_AI_AVAILABLE:
        st.markdown("### 🔗 Backend Integration Status")
        
        status_col1, status_col2, status_col3 = st.columns(3)
        
        with status_col1:
            st.success("✅ Admin AI Connected")
        
        with status_col2:
            st.success("✅ Intelligence Engine Active")
        
        with status_col3:
            st.success("✅ Express Mode Ready")
    
    # File upload section
    st.markdown("### 📁 Upload Your Resume")
    
    uploaded_file = st.file_uploader(
        "Choose your resume file",
        type=['pdf', 'doc', 'docx', 'txt'],
        help="Upload your resume for instant career intelligence analysis"
    )
    
    if uploaded_file is not None:
        # Process file
        try:
            # Read file content (simplified for demo)
            file_content = "Sample resume content for demonstration purposes..."
            
            if uploaded_file.type == "text/plain":
                file_content = str(uploaded_file.read(), "utf-8")
            else:
                # For other file types, we'd use appropriate parsers
                file_content = f"Resume file: {uploaded_file.name}\nProcessing {uploaded_file.type} format..."
            
            # Show processing status
            with st.spinner("⚡ Processing resume with express intelligence..."):
                time.sleep(1)  # Simulate processing
                
                # Perform instant analysis
                analysis = career_express.parse_resume_instant(file_content)
                
                if analysis:
                    # Generate précis
                    precis = career_express.generate_express_precis(analysis, file_content)
                    
                    # Success message
                    st.success("✅ **Express analysis complete!** Your resume has been processed in seconds.")
                    
                    # Show results dashboard
                    career_express.create_express_dashboard(analysis, precis)
                    
                    # Peer comparison
                    career_express.create_peer_comparison_express(analysis)
                    
                    # Action buttons
                    st.markdown("### 🚀 Next Steps")
                    
                    action_col1, action_col2, action_col3 = st.columns(3)
                    
                    with action_col1:
                        if st.button("📊 Full Career Intelligence", use_container_width=True):
                            st.switch_page("pages/11_Career_Intelligence_Suite.py")
                    
                    with action_col2:
                        if st.button("📝 Your Current Resume", use_container_width=True):
                            st.switch_page("pages/10_Your_Current_Resume.py")
                    
                    with action_col3:
                        if st.button("🎯 Job Matching", use_container_width=True):
                            st.switch_page("pages/12_Job_Matching_AI.py")
                
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")
    
    # Information section
    st.markdown("### ℹ️ About Express Analysis")
    
    info_col1, info_col2 = st.columns(2)
    
    with info_col1:
        st.markdown("""
        **🚀 Express Features:**
        - Instant keyword extraction
        - Professional précis generation  
        - Quick quality scoring
        - Real-time recommendations
        - Express peer comparison
        """)
    
    with info_col2:
        st.markdown("""
        **📊 Intelligence Integration:**
        - Backend admin AI engines
        - Industry classification
        - Experience level detection
        - Skills gap analysis
        - Career optimization tips
        """)
    
    # Token usage display
    if TOKEN_SYSTEM_AVAILABLE and career_express.token_manager:
        st.markdown("### 💰 Token Usage")
        tokens_used = 5  # Express analysis cost
        st.info(f"Express analysis uses {tokens_used} tokens per upload")

if __name__ == "__main__":
    main()