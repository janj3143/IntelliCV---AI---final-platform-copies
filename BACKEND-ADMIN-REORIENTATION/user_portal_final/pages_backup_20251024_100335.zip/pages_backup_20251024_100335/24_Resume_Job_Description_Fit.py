﻿import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

st.set_page_config(page_title="Resume-JD Fit Analysis - IntelliCV", page_icon="", layout="wide")

# Header
st.title(" Resume-Job Description Fit Analyzer")
st.markdown("### AI-powered matching between your resume and job requirements")

# Token cost display
st.info(" **Cost: 8 tokens** | Advanced AI analysis of resume-job compatibility")

# Two columns for inputs
col1, col2 = st.columns(2)

with col1:
    st.markdown("### 📄 Your Resume")
    resume_text = st.text_area("Paste your resume text or key highlights:", height=200, placeholder="Enter your resume content, skills, experience...")

with col2:
    st.markdown("### 📋 Job Description")
    job_desc = st.text_area("Paste the job description:", height=200, placeholder="Enter the complete job description you want to analyze...")

if st.button("🔍 Analyze Fit", type="primary"):
    if resume_text and job_desc:
        # Create tabs for different analysis views
        tab1, tab2, tab3, tab4 = st.tabs(["🎯 Overall Fit", "📊 Skill Matching", "📈 Compatibility Score", "💡 Recommendations"])
        
        with tab1:
            st.markdown("### 🎯 Overall Compatibility Analysis")
            
            # Demo metrics (would be AI-generated)
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Overall Fit", "78%", "12%")
            with col2:
                st.metric("Skills Match", "85%", "5%")
            with col3:
                st.metric("Experience Level", "92%", "-3%")
            with col4:
                st.metric("Industry Relevance", "88%", "8%")
            
            st.markdown("####  Quick Summary")
            st.success(" **Strong Match** - Your profile aligns well with this position")
            
            st.markdown("**Key Strengths:**")
            st.markdown("- Technical skills match 85% of requirements")
            st.markdown("- Experience level exceeds minimum qualifications")
            st.markdown("- Industry background is highly relevant")
            
            st.markdown("**Areas to Address:**")
            st.markdown("- Consider highlighting cloud computing experience")
            st.markdown("- Emphasize leadership/management skills more prominently")
        
        with tab2:
            st.markdown("###  Detailed Skill Analysis")
            
            # Demo skill matching visualization
            skills_data = {
                'Required Skills': ['Python', 'Machine Learning', 'SQL', 'Cloud Computing', 'Leadership', 'Agile'],
                'Your Level': [90, 85, 95, 60, 70, 80],
                'Required Level': [80, 90, 70, 85, 80, 75],
                'Gap': [-10, 5, -25, 25, 10, -5]
            }
            
            df_skills = pd.DataFrame(skills_data)
            
            # Create skill gap chart
            fig = go.Figure()
            fig.add_trace(go.Bar(name='Your Level', x=df_skills['Required Skills'], y=df_skills['Your Level'], marker_color='lightblue'))
            fig.add_trace(go.Bar(name='Required Level', x=df_skills['Required Skills'], y=df_skills['Required Level'], marker_color='orange'))
            
            fig.update_layout(barmode='group', title='Skill Level Comparison', xaxis_title='Skills', yaxis_title='Proficiency Level (%)')
            st.plotly_chart(fig, use_container_width=True)
            
            st.dataframe(df_skills, use_container_width=True)
        
        with tab3:
            st.markdown("###  Compatibility Breakdown")
            
            # Radar chart for different aspects
            categories = ['Technical Skills', 'Soft Skills', 'Experience', 'Education', 'Industry Knowledge', 'Cultural Fit']
            values = [85, 78, 92, 88, 85, 80]
            
            fig = go.Figure()
            fig.add_trace(go.Scatterpolar(
                r=values,
                theta=categories,
                fill='toself',
                name='Your Profile Fit'
            ))
            
            fig.update_layout(
                polar=dict(
                    radialaxis=dict(
                        visible=True,
                        range=[0, 100]
                    )),
                showlegend=True,
                title="Multi-Dimensional Fit Analysis"
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with tab4:
            st.markdown("###  AI Recommendations")
            
            st.markdown("####  To Improve Your Application:")
            st.markdown("1. **Highlight Cloud Experience**: Mention any AWS, Azure, or GCP projects")
            st.markdown("2. **Quantify Achievements**: Add specific metrics to your accomplishments")
            st.markdown("3. **Leadership Examples**: Include team management or project leadership stories")
            st.markdown("4. **Industry Keywords**: Use more specific industry terminology from the job description")
            
            st.markdown("####  Suggested Resume Edits:")
            st.code("""
            Original: "Worked with machine learning models"
            Improved: "Developed and deployed 5+ ML models resulting in 23% accuracy improvement"
            
            Original: "Team collaboration experience"
            Improved: "Led cross-functional team of 8 engineers to deliver project 2 weeks ahead of schedule"
            """)
            
            st.markdown("####  Interview Preparation Tips:")
            st.markdown("- Prepare specific examples for cloud computing questions")
            st.markdown("- Practice explaining your ML projects in business terms")
            st.markdown("- Research the company's technology stack")
    else:
        st.warning(" Please provide both your resume and the job description for analysis")

st.markdown("---")
st.markdown(" **Note:** This analysis uses AI to compare your resume against job requirements and provides actionable insights.")
