import streamlit as st
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from collections import Counter

st.set_page_config(page_title="AI Insights Visualizer", layout="wide")

st.title("📊 IntelliCV-AI Insights")
st.markdown("Gain a deeper understanding of the keywords and phrases extracted from your resume by IntelliCV-AI.")

# Check for AI keywords in session
ai_data = st.session_state.get("ai_json_data", {})
ai_keywords = ai_data.get("ai_keywords", [])

if not ai_keywords:
    st.warning("No enriched AI keywords found. Please upload a resume and run enrichment first.")
    st.stop()

# Frequency analysis
freq_counter = Counter(ai_keywords)
top_keywords = freq_counter.most_common(20)

st.subheader("🔢 Top 20 AI Keywords by Frequency")
if top_keywords:
    keywords, counts = zip(*top_keywords)
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.barh(keywords[::-1], counts[::-1])
    ax.set_xlabel("Frequency")
    ax.set_title("Top AI Keywords from Resume")
    st.pyplot(fig)
else:
    st.info("No keyword frequency data available.")

# Word cloud
st.subheader("☁️ Word Cloud of All Keywords")
wordcloud = WordCloud(width=800, height=300, background_color="white").generate_from_frequencies(freq_counter)
fig_wc, ax_wc = plt.subplots(figsize=(10, 4))
ax_wc.imshow(wordcloud, interpolation="bilinear")
ax_wc.axis("off")
st.pyplot(fig_wc)

# Optional grouping or clustering view
st.subheader("🧠 Keyword Grouping")
phrase_length_buckets = {
    "1-word": [],
    "2-word": [],
    "3+ words": []
}
for term in ai_keywords:
    length = len(term.strip().split())
    if length == 1:
        phrase_length_buckets["1-word"].append(term)
    elif length == 2:
        phrase_length_buckets["2-word"].append(term)
    else:
        phrase_length_buckets["3+ words"].append(term)

for label, items in phrase_length_buckets.items():
    with st.expander(f"{label} phrases ({len(items)})"):
        st.write(sorted(set(items)))
