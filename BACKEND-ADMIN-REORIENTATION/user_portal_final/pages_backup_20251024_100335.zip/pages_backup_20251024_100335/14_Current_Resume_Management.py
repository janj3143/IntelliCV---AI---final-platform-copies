"""
📄 Your Current Resume - Comprehensive Management Hub
====================================================
The central hub for existing users to manage their current resume, check if it's up-to-date,
view resume history with job application tracking, and use the resume builder for updates.

Features:
- Current resume status and up-to-date verification
- Resume history with job application touchpoint highlights  
- AI-powered resume builder with chatbot guidance
- Company information web scraping and précis generation
- Job description options (manual or global glossary)
- All existing resume upload features integrated
"""

import streamlit as st
from pathlib import Path
import time
import json
import base64
import requests
from datetime import datetime, date, timedelta
import sys
import os
import tempfile
import random

# Setup paths and imports
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

# Import token management
try:
    from token_management_system import TokenManager, check_token_cost
    TOKEN_SYSTEM_AVAILABLE = True
except ImportError:
    TOKEN_SYSTEM_AVAILABLE = False

# Import admin AI integration
try:
    from user_portal_admin_integration import process_user_action_with_admin_ai, init_admin_ai_for_user_page
    ADMIN_AI_AVAILABLE = True
except ImportError:
    ADMIN_AI_AVAILABLE = False

# Import utilities with fallbacks
try:
    from utils.error_handler import handle_exceptions, log_user_action, show_error, show_success, show_warning
    ERROR_HANDLER_AVAILABLE = True
except ImportError:
    ERROR_HANDLER_AVAILABLE = False
    def handle_exceptions(func): return func
    def log_user_action(action, details=None): pass
    def show_error(msg): st.error(f"❌ {msg}")
    def show_success(msg): st.success(f"✅ {msg}")
    def show_warning(msg): st.warning(f"⚠️ {msg}")

# Page configuration
st.set_page_config(
    page_title="📄 Your Current Resume | IntelliCV-AI",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Authentication check
if not st.session_state.get('authenticated_user'):
    st.error("🔒 Please log in to access your resume management")
    if st.button("🏠 Return to Home"):
        st.switch_page("pages/01_Home.py")
    st.stop()

# Token management
if TOKEN_SYSTEM_AVAILABLE:
    token_manager = TokenManager()
    user_id = st.session_state.get('user_id', st.session_state.get('authenticated_user'))
    cost_result = check_token_cost(user_id, "15_Current_Resume_Management.py")
    
    if not cost_result['has_access']:
        st.error(f"🪙 Insufficient tokens. Required: {cost_result['required']}, Available: {cost_result['available']}")
        if st.button("💰 Upgrade Plan"):
            st.switch_page("pages/06_Pricing.py")
        st.stop()

# Load logo with error handling
@st.cache_data
def load_logo_b64() -> str:
    """Load and cache logo with multiple fallback paths for 30% display"""
    try:
        logo_paths = [
            Path(__file__).parent.parent / "static" / "logo.png",
            Path(__file__).parent.parent / "static" / "logo1.png",
            Path(__file__).parent.parent / "assets" / "logo.png",
            Path(__file__).parent / "static" / "logo.png"
        ]
        
        for logo_path in logo_paths:
            if logo_path.exists():
                return base64.b64encode(logo_path.read_bytes()).decode()
        
        return None
    except Exception as e:
        if ERROR_HANDLER_AVAILABLE:
            log_user_action("logo_load_error", {"error": str(e)})
        return None

def render_page_logo():
    """Render 30% logo for non-home pages"""
    logo_b64 = load_logo_b64()
    
    if logo_b64:
        st.markdown(f'''
        <div style="text-align: center; padding: 1rem 0; margin-bottom: 1.5rem;">
            <img src="data:image/png;base64,{logo_b64}" 
                 alt="IntelliCV-AI Logo" 
                 style="width: 30%; max-width: 300px; height: auto; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));">
        </div>
        ''', unsafe_allow_html=True)
    else:
        st.markdown('''
        <div style="text-align: center; padding: 1rem 0; margin-bottom: 1.5rem;">
            <div style="font-size: 2.5rem; color: #667eea;">📄</div>
            <h3 style="color: #667eea; margin: 0.5rem 0;">IntelliCV-AI</h3>
        </div>
        ''', unsafe_allow_html=True)

# Professional CSS styling
def load_resume_management_css():
    css = '''
    <style>
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2.5rem;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 6px 20px rgba(0,0,0,0.2);
    }
    
    .resume-status-card {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        margin-bottom: 1.5rem;
        border-left: 5px solid #28a745;
    }
    
    .resume-outdated {
        border-left-color: #ffc107;
    }
    
    .resume-missing {
        border-left-color: #dc3545;
    }
    
    .history-item {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 4px solid #667eea;
        transition: all 0.3s ease;
    }
    
    .history-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .job-touchpoint {
        background: #e3f2fd;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        border-left: 3px solid #2196f3;
    }
    
    .builder-section {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        padding: 2rem;
        border-radius: 12px;
        margin: 2rem 0;
        border: 2px dashed #667eea;
    }
    
    .chatbot-interface {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin: 1rem 0;
    }
    
    .company-precis {
        background: #fff3cd;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #ffc107;
        margin: 1rem 0;
    }
    
    .job-glossary-option {
        background: #d4edda;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #28a745;
        margin: 1rem 0;
    }
    
    .resume-template {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        margin: 1.5rem 0;
        font-family: 'Times New Roman', serif;
        line-height: 1.6;
    }
    
    .template-header {
        text-align: center;
        border-bottom: 2px solid #333;
        padding-bottom: 1rem;
        margin-bottom: 1.5rem;
    }
    
    .template-section {
        margin: 1.5rem 0;
    }
    
    .template-section h3 {
        color: #333;
        border-bottom: 1px solid #ccc;
        padding-bottom: 0.5rem;
        margin-bottom: 1rem;
    }
    
    .up-to-date-check {
        background: linear-gradient(135deg, #28a745, #20c997);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        margin: 1rem 0;
    }
    
    .warning-check {
        background: linear-gradient(135deg, #ffc107, #fd7e14);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        margin: 1rem 0;
    }
    
    .critical-check {
        background: linear-gradient(135deg, #dc3545, #c82333);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        margin: 1rem 0;
    }
    </style>
    '''
    st.markdown(css, unsafe_allow_html=True)

# Load CSS
load_resume_management_css()

# Render 30% logo
render_page_logo()

# Initialize session state for resume management
if 'resume_data' not in st.session_state:
    st.session_state.resume_data = {}

if 'resume_history' not in st.session_state:
    st.session_state.resume_history = []

if 'job_applications' not in st.session_state:
    st.session_state.job_applications = []

if 'builder_session' not in st.session_state:
    st.session_state.builder_session = {}

if 'chatbot_state' not in st.session_state:
    st.session_state.chatbot_state = {'step': 'welcome', 'data': {}}

# Main header
username = st.session_state.get('authenticated_user', 'User')
st.markdown(f'''
<div class="main-header">
    <h1>📄 Your Current Resume</h1>
    <p>Welcome back, {username}! Manage your resume, track your career journey, and optimize for your next opportunity</p>
</div>
''', unsafe_allow_html=True)

# Check if user has a current resume
current_resume = st.session_state.resume_data
has_current_resume = bool(current_resume.get('filename') or current_resume.get('content'))

# Function to check resume up-to-date status
def check_resume_freshness():
    """Check if the current resume is up-to-date"""
    if not has_current_resume:
        return {'status': 'missing', 'message': 'No resume uploaded yet', 'days_old': 0}
    
    upload_date = current_resume.get('upload_date')
    if upload_date:
        try:
            if isinstance(upload_date, str):
                upload_dt = datetime.strptime(upload_date, "%Y-%m-%d %H:%M:%S")
            else:
                upload_dt = upload_date
            
            days_old = (datetime.now() - upload_dt).days
            
            if days_old <= 30:
                return {'status': 'fresh', 'message': f'Resume is up-to-date ({days_old} days old)', 'days_old': days_old}
            elif days_old <= 90:
                return {'status': 'aging', 'message': f'Resume could use a refresh ({days_old} days old)', 'days_old': days_old}
            else:
                return {'status': 'outdated', 'message': f'Resume needs updating ({days_old} days old)', 'days_old': days_old}
        except:
            return {'status': 'unknown', 'message': 'Cannot determine resume age', 'days_old': 0}
    
    return {'status': 'unknown', 'message': 'Upload date not available', 'days_old': 0}

# Function to get resume template
def get_professional_resume_template():
    """Return a comprehensive professional resume template based on web research"""
    return {
        'header': {
            'full_name': '[Your Full Name]',
            'job_title': '[Your Professional Title]',
            'phone': '[Your Phone Number]',
            'email': '[Your Email Address]',
            'location': '[City, State, ZIP Code]',
            'linkedin': '[LinkedIn Profile URL]',
            'portfolio': '[Portfolio/Website URL]'
        },
        'professional_summary': '''[Professional Summary]
Results-driven [Job Title] with [X] years of experience in [Industry/Field]. Proven track record of [Key Achievement 1] and [Key Achievement 2]. Seeking to leverage [Key Skills] and [Expertise Area] to drive [Specific Goal] at [Target Company].''',
        'work_experience': [
            {
                'job_title': '[Job Title]',
                'company': '[Company Name]',
                'location': '[City, State]',
                'dates': '[Start Date] – [End Date]',
                'responsibilities': [
                    '• Led and developed [specific area], resulting in [quantifiable outcome]',
                    '• Implemented [specific process/system] that improved [metric] by [percentage]',
                    '• Collaborated with [teams/departments] to [specific achievement]',
                    '• Managed [specific responsibility] with [quantifiable scope]'
                ]
            }
        ],
        'education': {
            'degree': '[Degree Type] in [Field of Study]',
            'school': '[University/College Name]',
            'location': '[City, State]',
            'graduation': '[Graduation Date]',
            'honors': '[Honors/GPA if applicable]',
            'relevant_coursework': '[Relevant Coursework if applicable]'
        },
        'skills': {
            'technical_skills': ['[Skill 1]', '[Skill 2]', '[Skill 3]', '[Skill 4]'],
            'software': ['[Software 1]', '[Software 2]', '[Software 3]'],
            'languages': ['[Language 1 (Proficiency)]', '[Language 2 (Proficiency)]'],
            'certifications': ['[Certification 1]', '[Certification 2]']
        },
        'additional_sections': {
            'projects': [
                {
                    'name': '[Project Name]',
                    'description': '[Brief description of project and your role]',
                    'technologies': '[Technologies/tools used]',
                    'outcome': '[Results or impact]'
                }
            ],
            'achievements': [
                '• [Award/Recognition 1] - [Year]',
                '• [Award/Recognition 2] - [Year]',
                '• [Professional milestone or achievement]'
            ],
            'volunteer_work': [
                {
                    'role': '[Volunteer Role]',
                    'organization': '[Organization Name]',
                    'dates': '[Start] - [End]',
                    'description': '[Brief description of contributions]'
                }
            ]
        }
    }

# Function to simulate company web scraping (placeholder)
def simulate_company_research(company_name):
    """Simulate AI-powered company research with web scraping"""
    # This would integrate with real web scraping in production
    company_data = {
        'name': company_name,
        'logo_url': f'https://logo.clearbit.com/{company_name.lower().replace(" ", "")}.com',
        'industry': 'Technology',  # Would be determined by AI
        'size': '1000-5000 employees',  # Would be scraped
        'description': f'{company_name} is a leading company in their industry, known for innovation and growth. They focus on delivering exceptional products and services to their customers while maintaining a strong commitment to employee development and workplace culture.',
        'headquarters': 'Silicon Valley, CA',  # Would be scraped
        'founded': '2010',  # Would be scraped
        'website': f'https://www.{company_name.lower().replace(" ", "")}.com',
        'key_values': ['Innovation', 'Customer Focus', 'Team Collaboration', 'Growth Mindset'],
        'recent_news': f'Recent developments at {company_name} include expansion into new markets and significant investment in AI technologies.',
        'culture_highlights': 'Known for flexible work environment, strong learning opportunities, and commitment to diversity and inclusion.'
    }
    return company_data

# Function to get job description from global glossary (placeholder)
def get_job_description_from_glossary(job_title):
    """Get standardized job description from global job title glossary"""
    # This would connect to a comprehensive job title database
    glossary_entries = {
        'software engineer': {
            'description': 'Design, develop, and maintain software applications. Collaborate with cross-functional teams to deliver high-quality code. Participate in code reviews, testing, and debugging processes.',
            'key_responsibilities': [
                'Write clean, efficient, and maintainable code',
                'Participate in software design and architecture decisions',
                'Collaborate with product managers and designers',
                'Conduct code reviews and provide constructive feedback',
                'Debug and troubleshoot software issues',
                'Stay updated with latest technology trends'
            ],
            'required_skills': ['Programming languages', 'Problem-solving', 'Version control', 'Testing frameworks'],
            'common_tools': ['Git', 'IDE/Code editors', 'Debugging tools', 'CI/CD pipelines']
        },
        'project manager': {
            'description': 'Lead and coordinate projects from initiation to completion. Manage resources, timelines, and stakeholder communication to ensure successful project delivery.',
            'key_responsibilities': [
                'Develop project plans and timelines',
                'Coordinate resources and team members',
                'Monitor project progress and budget',
                'Communicate with stakeholders and clients',
                'Identify and mitigate project risks',
                'Ensure quality deliverables'
            ],
            'required_skills': ['Leadership', 'Communication', 'Risk management', 'Budget management'],
            'common_tools': ['Project management software', 'Gantt charts', 'Communication platforms', 'Reporting tools']
        },
        'marketing specialist': {
            'description': 'Develop and execute marketing strategies to promote products and services. Analyze market trends and customer behavior to optimize marketing campaigns.',
            'key_responsibilities': [
                'Create and implement marketing campaigns',
                'Analyze market research and customer data',
                'Manage social media and digital marketing',
                'Coordinate with sales and product teams',
                'Track and report on marketing metrics',
                'Develop marketing materials and content'
            ],
            'required_skills': ['Digital marketing', 'Analytics', 'Content creation', 'Communication'],
            'common_tools': ['Analytics platforms', 'Social media tools', 'Email marketing software', 'Design tools']
        }
    }
    
    return glossary_entries.get(job_title.lower(), {
        'description': f'Professional role in {job_title} requiring relevant skills and experience.',
        'key_responsibilities': ['Execute core job functions', 'Collaborate with team members', 'Meet performance objectives'],
        'required_skills': ['Industry-specific skills', 'Communication', 'Problem-solving'],
        'common_tools': ['Industry-standard tools and software']
    })

# Resume Status Section
st.markdown("## 📊 Current Resume Status")

freshness_check = check_resume_freshness()

if freshness_check['status'] == 'missing':
    st.markdown(f'''
    <div class="resume-status-card resume-missing">
        <h3>❌ No Resume Found</h3>
        <p>{freshness_check['message']}</p>
        <p><strong>Action Required:</strong> Upload your first resume or use our resume builder to create one.</p>
    </div>
    ''', unsafe_allow_html=True)
elif freshness_check['status'] == 'fresh':
    st.markdown(f'''
    <div class="up-to-date-check">
        <h3>✅ Resume is Current</h3>
        <p>{freshness_check['message']}</p>
        <p><strong>Status:</strong> Your resume is fresh and ready for applications!</p>
    </div>
    ''', unsafe_allow_html=True)
elif freshness_check['status'] == 'aging':
    st.markdown(f'''
    <div class="warning-check">
        <h3>⚠️ Resume Needs Attention</h3>
        <p>{freshness_check['message']}</p>
        <p><strong>Recommendation:</strong> Consider updating with recent achievements and skills.</p>
    </div>
    ''', unsafe_allow_html=True)
else:
    st.markdown(f'''
    <div class="critical-check">
        <h3>🚨 Resume Requires Update</h3>
        <p>{freshness_check['message']}</p>
        <p><strong>Critical:</strong> Your resume is outdated and may hurt your job prospects.</p>
    </div>
    ''', unsafe_allow_html=True)

# Quick actions for existing resume
if has_current_resume:
    st.markdown("### 🚀 Quick Actions")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("🔍 Analyze Resume", use_container_width=True, type="primary"):
            st.switch_page("pages/09_Resume_Upload_Enhanced_Career_Intelligence.py")
    
    with col2:
        if st.button("✏️ Edit Resume", use_container_width=True):
            st.session_state.edit_mode = True
            st.rerun()
    
    with col3:
        if st.button("📊 Job Matches", use_container_width=True):
            st.switch_page("pages/16_Job_Match.py")
    
    with col4:
        if st.button("📤 Share Resume", use_container_width=True):
            st.session_state.share_mode = True
            st.rerun()

# Main content sections in tabs
tab1, tab2, tab3, tab4 = st.tabs(["📄 Current Resume", "📚 Resume History", "🔧 Resume Builder", "📤 Upload New"])

# Tab 1: Current Resume Display
with tab1:
    if has_current_resume:
        st.markdown("### 📄 Your Current Resume")
        
        # Resume metadata
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown(f"**📁 File:** {current_resume.get('filename', 'Unknown')}")
            st.markdown(f"**📅 Last Updated:** {current_resume.get('upload_date', 'Unknown')}")
            st.markdown(f"**📊 File Type:** {current_resume.get('file_type', 'Unknown')}")
            
            if current_resume.get('file_size'):
                size_kb = current_resume['file_size'] / 1024
                st.markdown(f"**💾 Size:** {size_kb:.1f} KB")
        
        with col2:
            # Resume health indicators
            health_score = 85 if freshness_check['status'] == 'fresh' else (70 if freshness_check['status'] == 'aging' else 45)
            st.metric("Resume Health Score", f"{health_score}%", delta=f"{'🟢' if health_score > 80 else '🟡' if health_score > 60 else '🔴'}")
        
        # Resume content preview
        st.markdown("### 👀 Resume Preview")
        resume_content = current_resume.get('content', 'No content available')
        
        # Show first 1000 characters as preview
        preview_content = resume_content[:1000] + "..." if len(resume_content) > 1000 else resume_content
        st.text_area("📝 Content Preview", preview_content, height=300, disabled=True)
        
        # AI-generated insights if available
        if current_resume.get('enhanced_data'):
            st.markdown("### 🧠 AI Insights")
            enhanced_data = current_resume['enhanced_data']
            
            insight_col1, insight_col2 = st.columns(2)
            
            with insight_col1:
                if enhanced_data.get('skill_mapping'):
                    st.markdown("**🔧 Detected Skills:**")
                    skills = enhanced_data['skill_mapping'].get('technical_skills', [])
                    for skill in skills[:5]:
                        st.markdown(f"• {skill}")
            
            with insight_col2:
                if enhanced_data.get('industry_match'):
                    st.markdown("**🏢 Industry Alignment:**")
                    industries = enhanced_data['industry_match'][:3]
                    for industry in industries:
                        st.markdown(f"• {industry}")
        
        # Up-to-date verification section
        st.markdown("### ✅ Is Your Resume Up-to-Date?")
        
        verification_questions = [
            "Have you added any new jobs or promotions in the last 6 months?",
            "Are your current skills and technologies listed?",
            "Does your contact information match your current details?",
            "Have you included recent achievements or projects?",
            "Is your professional summary current and compelling?"
        ]
        
        st.markdown("**Quick Verification Checklist:**")
        verification_score = 0
        for i, question in enumerate(verification_questions):
            is_current = st.checkbox(question, key=f"verify_{i}")
            if is_current:
                verification_score += 1
        
        if verification_score == len(verification_questions):
            st.success("🎉 Excellent! Your resume appears to be current and comprehensive.")
        elif verification_score >= 3:
            st.warning("⚠️ Your resume is mostly current but could use some updates.")
        else:
            st.error("🚨 Your resume needs significant updates to be competitive.")
    
    else:
        st.markdown('''
        <div class="resume-status-card resume-missing">
            <h3>🆕 Welcome to IntelliCV-AI!</h3>
            <p>You don't have a resume uploaded yet. Let's get you started!</p>
            <p><strong>Choose an option below:</strong></p>
            <ul>
                <li>📤 Upload an existing resume</li>
                <li>🔧 Use our AI-powered resume builder</li>
                <li>📝 Start with a professional template</li>
            </ul>
        </div>
        ''', unsafe_allow_html=True)

# Tab 2: Resume History with Job Application Tracking
with tab2:
    st.markdown("### 📚 Resume History & Job Applications")
    
    # Add sample history if none exists
    if not st.session_state.resume_history:
        st.session_state.resume_history = [
            {
                'version': 'v1.0',
                'filename': 'Resume_Software_Engineer_2024.pdf',
                'upload_date': '2024-09-15',
                'used_for_applications': ['TechCorp Software Engineer', 'StartupX Developer'],
                'touchpoints': {
                    'TechCorp Software Engineer': ['Python', 'React', 'AWS', 'Team Leadership'],
                    'StartupX Developer': ['JavaScript', 'Node.js', 'MongoDB', 'Agile']
                },
                'success_rate': '2/5 applications → interviews'
            },
            {
                'version': 'v1.1',
                'filename': 'Resume_Senior_Developer_2024.pdf',
                'upload_date': '2024-10-01',
                'used_for_applications': ['BigTech Senior Engineer', 'FinanceApp Lead Developer'],
                'touchpoints': {
                    'BigTech Senior Engineer': ['System Design', 'Microservices', 'Kubernetes', 'Team Management'],
                    'FinanceApp Lead Developer': ['Financial Systems', 'Security', 'Compliance', 'Architecture']
                },
                'success_rate': '3/4 applications → interviews'
            }
        ]
    
    for i, resume_version in enumerate(st.session_state.resume_history):
        st.markdown(f'''
        <div class="history-item">
            <h4>📄 {resume_version['version']} - {resume_version['filename']}</h4>
            <p><strong>📅 Created:</strong> {resume_version['upload_date']}</p>
            <p><strong>📈 Success Rate:</strong> {resume_version['success_rate']}</p>
        </div>
        ''', unsafe_allow_html=True)
        
        # Job Applications for this resume version
        st.markdown("**🎯 Job Applications:**")
        for job_title in resume_version['used_for_applications']:
            with st.expander(f"📋 {job_title}"):
                touchpoints = resume_version['touchpoints'].get(job_title, [])
                st.markdown("**🔍 Resume Touchpoints Highlighted:**")
                
                for touchpoint in touchpoints:
                    st.markdown(f'''
                    <div class="job-touchpoint">
                        <strong>🎯 {touchpoint}</strong> - Key skill/experience highlighted for this role
                    </div>
                    ''', unsafe_allow_html=True)
                
                # Action buttons for this application
                app_col1, app_col2, app_col3 = st.columns(3)
                with app_col1:
                    if st.button(f"📊 View Analysis", key=f"analysis_{i}_{job_title}"):
                        show_success(f"Analysis for {job_title} application")
                
                with app_col2:
                    if st.button(f"🔄 Reuse Resume", key=f"reuse_{i}_{job_title}"):
                        show_success(f"Resume version loaded for similar applications")
                
                with app_col3:
                    if st.button(f"🎯 Optimize Copy", key=f"optimize_{i}_{job_title}"):
                        show_success(f"Creating optimized version for similar roles")

# Tab 3: Resume Builder with AI Chatbot
with tab3:
    st.markdown("### 🔧 AI-Powered Resume Builder")
    
    # Resume builder options
    builder_option = st.radio(
        "Choose your starting point:",
        options=["🆕 Build from scratch", "📝 Use professional template", "✏️ Edit existing resume"],
        index=0 if not has_current_resume else 2
    )
    
    if builder_option == "📝 Use professional template":
        st.markdown('''
        <div class="builder-section">
            <h4>📋 Professional Resume Template</h4>
            <p>Start with our researched professional template used by successful candidates</p>
        </div>
        ''', unsafe_allow_html=True)
        
        template = get_professional_resume_template()
        
        # Display the template
        st.markdown('''
        <div class="resume-template">
            <div class="template-header">
                <h2>[Your Full Name]</h2>
                <p>[Your Professional Title]</p>
                <p>[Phone] | [Email] | [City, State] | [LinkedIn] | [Portfolio]</p>
            </div>
            
            <div class="template-section">
                <h3>PROFESSIONAL SUMMARY</h3>
                <p>Results-driven [Job Title] with [X] years of experience in [Industry/Field]. Proven track record of [Key Achievement 1] and [Key Achievement 2]. Seeking to leverage [Key Skills] and [Expertise Area] to drive [Specific Goal] at [Target Company].</p>
            </div>
            
            <div class="template-section">
                <h3>WORK EXPERIENCE</h3>
                <p><strong>[Job Title] | [Company Name] | [City, State] | [Start Date] – [End Date]</strong></p>
                <ul>
                    <li>Led and developed [specific area], resulting in [quantifiable outcome]</li>
                    <li>Implemented [specific process/system] that improved [metric] by [percentage]</li>
                    <li>Collaborated with [teams/departments] to [specific achievement]</li>
                    <li>Managed [specific responsibility] with [quantifiable scope]</li>
                </ul>
            </div>
            
            <div class="template-section">
                <h3>EDUCATION</h3>
                <p><strong>[Degree Type] in [Field of Study]</strong><br>
                [University/College Name] | [City, State] | [Graduation Date]</p>
            </div>
            
            <div class="template-section">
                <h3>CORE COMPETENCIES</h3>
                <p><strong>Technical Skills:</strong> [Skill 1] • [Skill 2] • [Skill 3] • [Skill 4]<br>
                <strong>Software:</strong> [Software 1] • [Software 2] • [Software 3]<br>
                <strong>Languages:</strong> [Language 1 (Proficiency)] • [Language 2 (Proficiency)]</p>
            </div>
            
            <div class="template-section">
                <h3>KEY ACHIEVEMENTS</h3>
                <ul>
                    <li>[Award/Recognition 1] - [Year]</li>
                    <li>[Award/Recognition 2] - [Year]</li>
                    <li>[Professional milestone or achievement]</li>
                </ul>
            </div>
        </div>
        ''', unsafe_allow_html=True)
        
        if st.button("🚀 Start Building with This Template", type="primary"):
            st.session_state.builder_session = {
                'template': template,
                'current_section': 'header',
                'started': True
            }
            st.rerun()
    
    elif builder_option == "🆕 Build from scratch":
        st.markdown("### 🤖 AI Resume Builder Assistant")
        
        # Chatbot interface for resume building
        chatbot_step = st.session_state.chatbot_state['step']
        chatbot_data = st.session_state.chatbot_state['data']
        
        st.markdown('''
        <div class="chatbot-interface">
            <h4>🤖 Hi! I'm your AI Resume Assistant</h4>
            <p>I'll guide you through building your resume step by step. Let's start with the basics!</p>
        </div>
        ''', unsafe_allow_html=True)
        
        if chatbot_step == 'welcome':
            st.markdown("**Let's get started! What's your name?**")
            user_name = st.text_input("Full Name", placeholder="e.g., John Smith")
            
            if user_name and st.button("Continue"):
                st.session_state.chatbot_state['data']['name'] = user_name
                st.session_state.chatbot_state['step'] = 'job_title'
                st.rerun()
        
        elif chatbot_step == 'job_title':
            st.markdown(f"**Great, {chatbot_data.get('name', '')}! What's your target job title?**")
            job_title = st.text_input("Job Title", placeholder="e.g., Software Engineer, Marketing Manager")
            
            if job_title and st.button("Continue"):
                st.session_state.chatbot_state['data']['job_title'] = job_title
                st.session_state.chatbot_state['step'] = 'experience'
                st.rerun()
        
        elif chatbot_step == 'experience':
            st.markdown("**Now let's add your work experience. Tell me about your most recent job:**")
            
            exp_col1, exp_col2 = st.columns(2)
            
            with exp_col1:
                company = st.text_input("Company Name", placeholder="e.g., Google, Microsoft")
                position = st.text_input("Your Position", placeholder="e.g., Senior Developer")
                start_date = st.date_input("Start Date", value=date(2022, 1, 1))
            
            with exp_col2:
                location = st.text_input("Location", placeholder="e.g., San Francisco, CA")
                current_job = st.checkbox("I currently work here")
                if not current_job:
                    end_date = st.date_input("End Date", value=date.today())
                else:
                    end_date = None
            
            # Company research feature
            if company and st.button("🔍 Research Company"):
                with st.spinner("🌐 Researching company information..."):
                    time.sleep(2)  # Simulate research time
                    company_data = simulate_company_research(company)
                    
                    st.markdown(f'''
                    <div class="company-precis">
                        <h5>🏢 {company_data['name']} - Company Précis</h5>
                        <p><strong>Industry:</strong> {company_data['industry']}</p>
                        <p><strong>Size:</strong> {company_data['size']}</p>
                        <p><strong>Description:</strong> {company_data['description']}</p>
                        <p><strong>Culture:</strong> {company_data['culture_highlights']}</p>
                        <p><em>💡 This information can help you tailor your experience description!</em></p>
                    </div>
                    ''', unsafe_allow_html=True)
            
            # Job description options
            st.markdown("**How would you like to describe your job responsibilities?**")
            desc_option = st.radio(
                "Choose option:",
                ["✍️ Write my own description", "📚 Use from job title glossary", "🤖 AI-assisted writing"]
            )
            
            if desc_option == "📚 Use from job title glossary" and position:
                glossary_data = get_job_description_from_glossary(position)
                
                st.markdown(f'''
                <div class="job-glossary-option">
                    <h5>📋 Standard {position} Description</h5>
                    <p><strong>Description:</strong> {glossary_data['description']}</p>
                    <p><strong>Key Responsibilities:</strong></p>
                    <ul>
                        {''.join([f"<li>{resp}</li>" for resp in glossary_data['key_responsibilities']])}
                    </ul>
                    <p><em>You can customize this description to match your specific experience.</em></p>
                </div>
                ''', unsafe_allow_html=True)
                
                job_description = st.text_area(
                    "Customize your job description:",
                    value=glossary_data['description'],
                    height=150
                )
            else:
                job_description = st.text_area(
                    "Job Description",
                    placeholder="Describe your key responsibilities and achievements...",
                    height=150
                )
            
            # Salary information (optional)
            st.markdown("**💰 Salary Information (Optional)**")
            include_salary = st.checkbox("Include salary information")
            if include_salary:
                sal_col1, sal_col2 = st.columns(2)
                with sal_col1:
                    salary = st.number_input("Annual Salary ($)", min_value=0, value=50000)
                with sal_col2:
                    salary_visible = st.checkbox("Make salary visible to employers")
            
            if all([company, position, job_description]) and st.button("Add Experience & Continue"):
                experience_data = {
                    'company': company,
                    'position': position,
                    'location': location,
                    'start_date': start_date.strftime("%Y-%m"),
                    'end_date': end_date.strftime("%Y-%m") if end_date else "Present",
                    'description': job_description,
                    'current': current_job
                }
                
                if include_salary:
                    experience_data['salary'] = salary
                    experience_data['salary_visible'] = salary_visible
                
                if 'experiences' not in st.session_state.chatbot_state['data']:
                    st.session_state.chatbot_state['data']['experiences'] = []
                
                st.session_state.chatbot_state['data']['experiences'].append(experience_data)
                st.session_state.chatbot_state['step'] = 'more_experience'
                st.rerun()
        
        elif chatbot_step == 'more_experience':
            current_experiences = len(st.session_state.chatbot_state['data'].get('experiences', []))
            st.markdown(f"**Great! You've added {current_experiences} job experience(s).**")
            
            if st.button("➕ Add Another Job"):
                st.session_state.chatbot_state['step'] = 'experience'
                st.rerun()
            
            if st.button("✅ Continue to Education"):
                st.session_state.chatbot_state['step'] = 'education'
                st.rerun()
        
        elif chatbot_step == 'education':
            st.markdown("**Let's add your education:**")
            
            edu_col1, edu_col2 = st.columns(2)
            
            with edu_col1:
                degree = st.text_input("Degree", placeholder="e.g., Bachelor of Science")
                field = st.text_input("Field of Study", placeholder="e.g., Computer Science")
                school = st.text_input("School Name", placeholder="e.g., University of California")
            
            with edu_col2:
                school_location = st.text_input("School Location", placeholder="e.g., Los Angeles, CA")
                graduation_year = st.number_input("Graduation Year", min_value=1980, max_value=2030, value=2020)
                gpa = st.number_input("GPA (optional)", min_value=0.0, max_value=4.0, value=0.0, step=0.1)
            
            if all([degree, field, school]) and st.button("Continue to Skills"):
                education_data = {
                    'degree': degree,
                    'field': field,
                    'school': school,
                    'location': school_location,
                    'graduation_year': graduation_year,
                    'gpa': gpa if gpa > 0 else None
                }
                
                st.session_state.chatbot_state['data']['education'] = education_data
                st.session_state.chatbot_state['step'] = 'skills'
                st.rerun()
        
        elif chatbot_step == 'skills':
            st.markdown("**What are your key skills?**")
            
            skill_categories = st.tabs(["💻 Technical", "🤝 Soft Skills", "🏆 Certifications"])
            
            with skill_categories[0]:
                technical_skills = st.text_area(
                    "Technical Skills",
                    placeholder="e.g., Python, JavaScript, React, AWS, SQL",
                    help="Separate skills with commas"
                )
            
            with skill_categories[1]:
                soft_skills = st.text_area(
                    "Soft Skills",
                    placeholder="e.g., Leadership, Communication, Problem-solving, Team collaboration",
                    help="Separate skills with commas"
                )
            
            with skill_categories[2]:
                certifications = st.text_area(
                    "Certifications",
                    placeholder="e.g., AWS Certified Developer, PMP, Google Analytics Certified",
                    help="Separate certifications with commas"
                )
            
            if st.button("🎉 Generate Resume"):
                skills_data = {
                    'technical': [skill.strip() for skill in technical_skills.split(',') if skill.strip()],
                    'soft': [skill.strip() for skill in soft_skills.split(',') if skill.strip()],
                    'certifications': [cert.strip() for cert in certifications.split(',') if cert.strip()]
                }
                
                st.session_state.chatbot_state['data']['skills'] = skills_data
                st.session_state.chatbot_state['step'] = 'complete'
                st.rerun()
        
        elif chatbot_step == 'complete':
            st.markdown("### 🎉 Resume Generated Successfully!")
            
            resume_data = st.session_state.chatbot_state['data']
            
            # Generate resume content
            generated_resume = f"""
{resume_data.get('name', 'Your Name')}
{resume_data.get('job_title', 'Your Professional Title')}

PROFESSIONAL SUMMARY
Dedicated {resume_data.get('job_title', 'professional')} with proven experience in delivering results and driving growth.

WORK EXPERIENCE
"""
            
            for exp in resume_data.get('experiences', []):
                generated_resume += f"""
{exp['position']} | {exp['company']} | {exp['location']} | {exp['start_date']} - {exp['end_date']}
{exp['description']}
"""
            
            education = resume_data.get('education', {})
            if education:
                generated_resume += f"""
EDUCATION
{education.get('degree', '')} in {education.get('field', '')}
{education.get('school', '')} | {education.get('location', '')} | {education.get('graduation_year', '')}
"""
            
            skills = resume_data.get('skills', {})
            if skills:
                generated_resume += f"""
SKILLS
Technical Skills: {', '.join(skills.get('technical', []))}
Soft Skills: {', '.join(skills.get('soft', []))}
Certifications: {', '.join(skills.get('certifications', []))}
"""
            
            st.text_area("📄 Your Generated Resume", generated_resume, height=400)
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button("💾 Save Resume", type="primary"):
                    # Save to session state
                    st.session_state.resume_data = {
                        'filename': f"Resume_{resume_data.get('name', 'User').replace(' ', '_')}.txt",
                        'content': generated_resume,
                        'file_type': 'text/plain',
                        'file_size': len(generated_resume.encode('utf-8')),
                        'upload_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        'processed': True,
                        'analysis_ready': True,
                        'source': 'ai_builder',
                        'builder_data': resume_data
                    }
                    
                    show_success("Resume saved successfully!")
                    st.session_state.chatbot_state = {'step': 'welcome', 'data': {}}
                    time.sleep(2)
                    st.rerun()
            
            with col2:
                if st.button("📥 Download Resume"):
                    st.download_button(
                        "📄 Download as Text",
                        generated_resume,
                        file_name=f"resume_{resume_data.get('name', 'user').lower().replace(' ', '_')}.txt",
                        mime="text/plain"
                    )
            
            with col3:
                if st.button("🔄 Start Over"):
                    st.session_state.chatbot_state = {'step': 'welcome', 'data': {}}
                    st.rerun()

# Tab 4: Upload New Resume
with tab4:
    st.markdown("### 📤 Upload New Resume Version")
    
    st.markdown('''
    <div class="builder-section">
        <h4>📁 Upload a New Resume</h4>
        <p>Upload a new version of your resume to replace the current one or add to your history.</p>
    </div>
    ''', unsafe_allow_html=True)
    
    uploaded_file = st.file_uploader(
        "Choose your resume file",
        type=['pdf', 'docx', 'txt'],
        help="Upload your resume in PDF, DOCX, or TXT format (max 10MB)"
    )
    
    if uploaded_file:
        st.markdown("### 📋 File Information")
        
        file_details = {
            "Filename": uploaded_file.name,
            "File Type": uploaded_file.type,
            "File Size": f"{uploaded_file.size / 1024:.1f} KB"
        }
        
        for key, value in file_details.items():
            st.write(f"**{key}:** {value}")
        
        replace_or_add = st.radio(
            "What would you like to do?",
            ["🔄 Replace current resume", "➕ Add as new version to history"]
        )
        
        if st.button("🚀 Process Resume", type="primary"):
            with st.spinner("Processing your resume..."):
                try:
                    # Read file content
                    if uploaded_file.type == "text/plain":
                        content = str(uploaded_file.read(), "utf-8")
                    else:
                        content = f"File uploaded: {uploaded_file.name}"
                    
                    new_resume_data = {
                        'filename': uploaded_file.name,
                        'content': content,
                        'file_type': uploaded_file.type,
                        'file_size': uploaded_file.size,
                        'upload_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        'processed': True,
                        'analysis_ready': True,
                        'source': 'file_upload'
                    }
                    
                    if replace_or_add == "🔄 Replace current resume":
                        # Add current resume to history if it exists
                        if has_current_resume:
                            st.session_state.resume_history.append(st.session_state.resume_data.copy())
                        
                        # Replace current resume
                        st.session_state.resume_data = new_resume_data
                        show_success("Resume replaced successfully!")
                    
                    else:
                        # Add to history
                        st.session_state.resume_history.append(new_resume_data)
                        show_success("Resume added to history!")
                    
                    if ERROR_HANDLER_AVAILABLE:
                        log_user_action("resume_uploaded", {
                            "filename": uploaded_file.name,
                            "action": replace_or_add,
                            "file_type": uploaded_file.type
                        })
                    
                    time.sleep(2)
                    st.rerun()
                    
                except Exception as e:
                    show_error(f"Error processing resume: {str(e)}")

# Advanced Features Section
st.markdown("---")
st.markdown("## 🚀 Advanced Features")

feature_col1, feature_col2, feature_col3 = st.columns(3)

with feature_col1:
    st.markdown('''
    <div class="resume-status-card">
        <h4>🎯 Job Cloud Overlays</h4>
        <p>See how your resume aligns with specific job requirements</p>
    </div>
    ''', unsafe_allow_html=True)
    
    if st.button("🔍 View Job Clouds", use_container_width=True):
        st.switch_page("pages/12_Job_Title_Word_Cloud.py")

with feature_col2:
    st.markdown('''
    <div class="resume-status-card">
        <h4>📊 Resume Analytics</h4>
        <p>Get detailed insights and optimization recommendations</p>
    </div>
    ''', unsafe_allow_html=True)
    
    if st.button("📈 View Analytics", use_container_width=True):
        st.switch_page("pages/19_Resume_Feedback.py")

with feature_col3:
    st.markdown('''
    <div class="resume-status-card">
        <h4>🎨 Resume Tuner</h4>
        <p>Fine-tune your resume for specific opportunities</p>
    </div>
    ''', unsafe_allow_html=True)
    
    if st.button("🔧 Open Tuner", use_container_width=True):
        st.switch_page("pages/17_Resume_Tuner.py")

# Footer
st.markdown("---")
st.markdown(f"""
<div style="text-align: center; color: #666; padding: 1.5rem; background: #f8f9fa; border-radius: 10px;">
    <p><strong>IntelliCV-AI Current Resume Management</strong> | Complete Resume Hub</p>
    <p>🔒 Secure Processing • 📊 AI-Powered Insights • 🚀 Career Optimization</p>
    <p>💡 <strong>Pro Tip:</strong> Keep your resume updated monthly for the best opportunities</p>
</div>
""", unsafe_allow_html=True)