"""
IntelliCV Geographic Career Intelligence Platform
Advanced location-based career insights and geographic market analysis
Token Cost: 8 tokens (Advanced Tier)
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import json

# Page configuration
st.set_page_config(
    page_title="Geographic Career Intelligence - IntelliCV",
    page_icon="🌐",
    layout="wide"
)

def main():
    st.title("🌐 Geographic Career Intelligence")
    st.markdown("### Advanced location-based career insights and geographic market analysis")
    
    # Token cost display
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.info("💎 **Token Cost: 8 tokens** | Advanced Tier Feature")
    
    # Main tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "🗺️ Global Market Intelligence", 
        "🎯 Location Intelligence", 
        "📊 Migration Analytics", 
        "🔮 Predictive Insights"
    ])
    
    with tab1:
        st.header("🗺️ Global Career Market Intelligence")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.subheader("🎯 Intelligence Parameters")
            
            job_function = st.selectbox("Job function", 
                                      ["Data Science", "Software Engineering", "Product Management", 
                                       "Marketing", "Sales", "Finance", "Operations"])
            
            seniority_level = st.selectbox("Seniority level",
                                         ["Entry Level", "Mid Level", "Senior Level", "Executive"])
            
            regions = st.multiselect("Focus regions",
                                   ["North America", "Europe", "Asia Pacific", "Latin America", "Middle East & Africa"],
                                   default=["North America", "Europe"])
            
            analysis_type = st.selectbox("Analysis type",
                                       ["Market Overview", "Compensation Analysis", "Skills Demand", "Growth Trends"])
            
            if st.button("🔍 Generate Intelligence Report"):
                st.success("✅ Global intelligence report generated!")
        
        with col2:
            st.subheader("🌍 Global Opportunity Heatmap")
            
            # Global market data
            global_data = {
                'Country': ['United States', 'Germany', 'United Kingdom', 'Canada', 'Australia',
                           'Netherlands', 'Singapore', 'Switzerland', 'Sweden', 'Ireland'],
                'Job_Opportunities': [45000, 12000, 18000, 8500, 6200, 4800, 3200, 2800, 3100, 2400],
                'Avg_Salary_USD': [125000, 85000, 95000, 80000, 85000, 90000, 95000, 110000, 88000, 85000],
                'Market_Growth': [12, 8, 6, 10, 7, 9, 15, 4, 11, 13],
                'Talent_Competition': [85, 70, 75, 65, 60, 72, 88, 68, 58, 71]
            }
            
            global_df = pd.DataFrame(global_data)
            
            fig = px.scatter(global_df, x='Avg_Salary_USD', y='Job_Opportunities',
                           size='Market_Growth', color='Talent_Competition',
                           hover_name='Country',
                           title="Global Career Opportunities Overview",
                           labels={'Avg_Salary_USD': 'Average Salary (USD)', 
                                  'Job_Opportunities': 'Job Opportunities'})
            st.plotly_chart(fig, use_container_width=True)
            
            st.subheader("📊 Market Intelligence Metrics")
            
            col_a, col_b, col_c, col_d = st.columns(4)
            with col_a:
                st.metric("Total Global Opportunities", "156,100", "↗️ +8.5%")
            with col_b:
                st.metric("Average Global Salary", "$92,400", "↗️ +6.2%")
            with col_c:
                st.metric("Fastest Growing Market", "Singapore", "+15%")
            with col_d:
                st.metric("Lowest Competition", "Sweden", "58 pts")
    
    with tab2:
        st.header("🎯 Location-Specific Intelligence")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📍 Location Deep Dive")
            
            selected_location = st.selectbox("Select location for analysis",
                                           ["San Francisco Bay Area", "New York City", "London", "Berlin",
                                            "Toronto", "Sydney", "Amsterdam", "Stockholm"])
            
            st.subheader(f"📊 {selected_location} Market Profile")
            
            # Location-specific metrics
            col_x, col_y = st.columns(2)
            with col_x:
                st.metric("Active Jobs", "2,847", "↗️ +12%")
                st.metric("Median Salary", "$145,000", "↗️ +8%")
                st.metric("Market Saturation", "High", "⚠️")
            with col_y:
                st.metric("Cost of Living Index", "185", "↗️ +3%")
                st.metric("Quality of Life", "8.7/10", "→")
                st.metric("Career Growth Rate", "14%", "↗️ +2%")
            
            st.subheader("🏢 Major Employers")
            employers = {
                "San Francisco Bay Area": ["Google", "Meta", "Apple", "Salesforce", "Netflix"],
                "New York City": ["JPMorgan", "Goldman Sachs", "Bloomberg", "IBM", "Meta"],
                "London": ["Barclays", "HSBC", "Google", "Meta", "Amazon"]
            }
            
            location_employers = employers.get(selected_location, ["Company A", "Company B", "Company C"])
            for i, employer in enumerate(location_employers, 1):
                st.write(f"**{i}.** {employer}")
        
        with col2:
            st.subheader("📈 Location Trends & Projections")
            
            # Trend data for selected location
            months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            job_postings = [2400, 2550, 2700, 2650, 2800, 2900, 3100, 3050, 2950, 3200, 3100, 2847]
            salaries = [140, 141, 142, 143, 144, 145, 146, 145, 144, 146, 147, 145]
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=months, y=job_postings, name='Job Postings', yaxis='y'))
            fig.add_trace(go.Scatter(x=months, y=salaries, name='Avg Salary (K)', yaxis='y2'))
            
            fig.update_layout(
                title=f'{selected_location} - Job Market Trends',
                yaxis=dict(title='Job Postings', side='left'),
                yaxis2=dict(title='Average Salary ($K)', side='right', overlaying='y')
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            st.subheader("🎯 Skills in High Demand")
            
            skills_data = {
                'Skill': ['Python', 'SQL', 'Machine Learning', 'AWS', 'React', 'Docker', 'Kubernetes', 'Java'],
                'Demand Score': [95, 88, 85, 82, 78, 75, 72, 70],
                'Salary Premium': [15, 12, 20, 18, 10, 8, 15, 12]
            }
            
            skills_df = pd.DataFrame(skills_data)
            fig = px.bar(skills_df, x='Demand Score', y='Skill', orientation='h',
                        color='Salary Premium', title="High-Demand Skills")
            st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        st.header("📊 Career Migration Analytics")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🔄 Migration Flow Analysis")
            
            migration_source = st.selectbox("Source location", 
                                          ["Current Location", "Chicago", "Boston", "Austin", "Denver"])
            
            migration_targets = st.multiselect("Target locations",
                                             ["San Francisco", "New York", "Seattle", "London", "Toronto"],
                                             default=["San Francisco", "New York"])
            
            st.subheader("📈 Migration Success Probability")
            
            # Migration success data
            migration_data = {
                'Target City': ['San Francisco', 'New York', 'Seattle', 'London', 'Toronto'],
                'Success Rate': [78, 82, 85, 65, 88],
                'Avg Time to Hire': [3.2, 2.8, 3.5, 4.8, 3.1],
                'Salary Increase': [35, 28, 30, 15, 20],
                'Cost of Moving': [15000, 12000, 10000, 18000, 8000]
            }
            
            migration_df = pd.DataFrame(migration_data)
            st.dataframe(migration_df, use_container_width=True)
            
            st.subheader("💡 Migration Recommendations")
            st.success("🎯 **Top Recommendation:** Toronto - High success rate, moderate costs")
            st.info("⚡ **Quick Win:** New York - Fast hiring, good salary increase")
            st.warning("⚠️ **Consider Carefully:** London - Longer process, visa requirements")
        
        with col2:
            st.subheader("💰 Migration ROI Calculator")
            
            # ROI calculation interface
            current_salary = st.number_input("Current annual salary", value=75000, step=5000)
            target_salary_increase = st.slider("Expected salary increase (%)", 10, 50, 25)
            
            moving_costs = st.number_input("Estimated moving costs", value=12000, step=1000)
            time_to_break_even = st.slider("Months to calculate ROI", 12, 60, 24)
            
            # Calculate ROI
            new_salary = current_salary * (1 + target_salary_increase/100)
            annual_increase = new_salary - current_salary
            roi_period = annual_increase * (time_to_break_even/12) - moving_costs
            
            st.metric("New Expected Salary", f"${new_salary:,.0f}")
            st.metric("Annual Salary Increase", f"${annual_increase:,.0f}")
            st.metric(f"ROI after {time_to_break_even} months", f"${roi_period:,.0f}")
            
            if roi_period > 0:
                st.success(f"✅ Positive ROI after {time_to_break_even} months!")
            else:
                st.warning(f"⚠️ Break-even will take longer than {time_to_break_even} months")
            
            st.subheader("📊 Migration Timeline")
            timeline_data = {
                'Phase': ['Planning', 'Job Search', 'Interviews', 'Offer & Negotiation', 'Relocation'],
                'Duration (weeks)': [4, 8, 6, 2, 4],
                'Success Factors': ['Research, networking', 'Applications, referrals', 
                                  'Preparation, practice', 'Negotiation skills', 'Logistics planning']
            }
            
            timeline_df = pd.DataFrame(timeline_data)
            fig = px.bar(timeline_df, x='Phase', y='Duration (weeks)',
                        title="Typical Migration Timeline")
            st.plotly_chart(fig, use_container_width=True)
    
    with tab4:
        st.header("🔮 Predictive Career Intelligence")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📈 Future Market Predictions")
            
            prediction_timeframe = st.selectbox("Prediction timeframe",
                                              ["6 months", "1 year", "2 years", "5 years"])
            
            prediction_focus = st.selectbox("Prediction focus",
                                          ["Job Market Growth", "Salary Trends", "Skills Demand", "Location Emergence"])
            
            st.subheader("🎯 AI-Powered Predictions")
            
            predictions = {
                "Job Market Growth": {
                    "6 months": "Data Science jobs will grow 8% globally, with strongest growth in Asia-Pacific",
                    "1 year": "Remote work adoption will increase opportunities by 15% in smaller cities",
                    "2 years": "AI/ML roles will represent 25% of all tech positions",
                    "5 years": "New emerging roles in AI ethics and quantum computing will appear"
                },
                "Salary Trends": {
                    "6 months": "Tech salaries will stabilize with 3-5% increases",
                    "1 year": "Data Science salaries will increase 8-12% due to demand",
                    "2 years": "Geographic salary gaps will narrow due to remote work",
                    "5 years": "Skills-based pay will become more important than location"
                }
            }
            
            prediction_text = predictions.get(prediction_focus, {}).get(prediction_timeframe, 
                                            "Prediction model is analyzing market data...")
            
            st.info(f"🔮 **{prediction_timeframe} Prediction:** {prediction_text}")
            
            st.subheader("📊 Confidence Metrics")
            col_a, col_b = st.columns(2)
            with col_a:
                st.metric("Prediction Confidence", "87%", "↗️ +5%")
            with col_b:
                st.metric("Data Quality Score", "94%", "→")
        
        with col2:
            st.subheader("🌟 Emerging Opportunities")
            
            # Emerging markets data
            emerging_data = {
                'Location': ['Austin, TX', 'Dublin, Ireland', 'Bangalore, India', 'Tel Aviv, Israel', 'Vancouver, Canada'],
                'Growth Prediction': [85, 78, 92, 88, 82],
                'Current Opportunity': [45, 62, 88, 58, 48],
                'Future Potential': [92, 85, 95, 90, 88]
            }
            
            emerging_df = pd.DataFrame(emerging_data)
            
            fig = px.scatter(emerging_df, x='Current Opportunity', y='Future Potential',
                           size='Growth Prediction', hover_name='Location',
                           title="Emerging Career Markets - Opportunity vs Potential")
            st.plotly_chart(fig, use_container_width=True)
            
            st.subheader("🚀 Strategic Recommendations")
            
            recommendations = [
                "🎯 **Austin, TX** - Rapid tech growth, lower competition",
                "🌍 **Dublin** - European tech hub, English-speaking",
                "📈 **Bangalore** - Massive growth potential, cost advantages",
                "💡 **Tel Aviv** - Innovation ecosystem, high-quality opportunities",
                "🍁 **Vancouver** - Quality of life, growing tech scene"
            ]
            
            for rec in recommendations:
                st.write(rec)
            
            st.subheader("⏰ Optimal Timing")
            st.success("🎯 **Best Time to Move:** Q1 2025 - High hiring activity predicted")
            st.info("📅 **Secondary Window:** Q3 2025 - Budget cycles favor new hiring")

if __name__ == "__main__":
    main()