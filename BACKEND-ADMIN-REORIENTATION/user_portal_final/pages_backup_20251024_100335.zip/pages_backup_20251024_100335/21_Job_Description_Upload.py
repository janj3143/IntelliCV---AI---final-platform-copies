import streamlit as st
import tempfile
from utils.session_manager import session_manager
from utils.resume_nlp import extract_text_from_file, extract_keywords_from_resume

st.set_page_config(page_title="Upload Job Description", page_icon="📄")
st.title("📄 Step 1: Upload Target Job Description")

session_id = st.session_state.get("session_id", "default")
session = session_manager.get_or_create(session_id)

st.markdown("Upload a job description to analyze and match your resume against it.")

uploaded_jd = st.file_uploader("Choose a Job Description file (PDF, DOCX, or TXT)", type=["pdf", "docx", "txt"])

if uploaded_jd:
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(uploaded_jd.read())
        tmp_path = tmp.name

    jd_text = extract_text_from_file(tmp_path)
    jd_keywords = extract_keywords_from_resume(tmp_path)

    session.context["uploaded_jd_text"] = jd_text
    session.context["jd_keywords"] = jd_keywords
    session.context["uploaded_jd_path"] = tmp_path

    st.success("✅ Job description uploaded and parsed successfully.")
    st.text_area("📄 Parsed JD Preview", jd_text, height=200)
    st.markdown("### 🧠 Extracted Keywords from JD")
    st.write(jd_keywords)

    st.markdown("---")
    st.info("This JD will now be used in the Job Match and Resume Feedback modules.")
else:
    st.info("Please upload a job description to continue.")
