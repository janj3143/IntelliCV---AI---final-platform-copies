﻿import streamlit as st
import pandas as pd
import plotly.express as px
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import numpy as np

st.set_page_config(page_title="Job Title Word Cloud - IntelliCV", page_icon="", layout="wide")

# Header
st.title(" Job Title Word Cloud Generator")
st.markdown("### Visualize trending job titles and career opportunities")

# Token cost display
st.info(" **Cost: 5 tokens** | Generate visual insights from job market data")

if st.button("Generate Job Title Cloud"):
    # Sample job titles for demo
    job_titles = [
        "Data Scientist", "Software Engineer", "Product Manager", "UX Designer",
        "Marketing Manager", "Business Analyst", "DevOps Engineer", "AI Engineer",
        "Full Stack Developer", "Digital Marketing Specialist", "Project Manager",
        "Quality Assurance Engineer", "Sales Manager", "HR Business Partner",
        "Content Creator", "Cybersecurity Analyst", "Cloud Architect"
    ] * 3  # Repeat for frequency
    
    # Create word cloud
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(' '.join(job_titles))
    
    # Display
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.imshow(wordcloud, interpolation='bilinear')
    ax.axis('off')
    st.pyplot(fig)
    
    st.success("✅ Job title cloud generated successfully!")
    st.markdown("**Insights:** Most trending positions in your field")

st.markdown("---")
st.markdown("🔄 **Coming Soon:** Real-time job market analysis and trending titles")
