import streamlit as st
import difflib
from datetime import datetime
from utils.resume_utils import load_resume_versions, save_new_version, promote_to_master, generate_ai_rewrite

st.set_page_config(page_title="Resume Tuner", layout="wide")

st.title("🛠️ Resume Tuner")

# Section Selector
section = st.selectbox("Choose section to tune:", ["Summary", "Experience", "Skills"])

# Load latest and tuned versions
original_text = load_resume_versions().get("latest", {}).get(section.lower(), "")
tuned_text = generate_ai_rewrite(original_text, section=section)

col1, col2 = st.columns(2)
with col1:
    st.subheader("Original")
    st.text_area("Original Section", value=original_text, height=300, disabled=True)
with col2:
    st.subheader("AI-Tuned (Editable)")
    edited = st.text_area("Tuned Section", value=tuned_text, height=300, key="tuned_editable")

# Diff Viewer
if st.button("🔍 Show Diff"):
    diff = difflib.unified_diff(original_text.splitlines(), edited.splitlines(), lineterm="")
    st.code("\n".join(diff), language="diff")

# Actions
st.markdown("### 💾 Actions")
col3, col4, col5 = st.columns(3)
with col3:
    if st.button("💾 Save as New Version"):
        save_new_version(section.lower(), edited, tag=datetime.now().isoformat())
        st.success("Version saved!")

with col4:
    if st.button("⭐ Promote to Master"):
        promote_to_master(section.lower(), edited)
        st.success("Promoted to master resume!")

with col5:
    st.download_button("⬇️ Export", data=edited, file_name=f"tuned_{section}.txt")

# Tone / Style options
st.markdown("### ✨ Tune Style")
tone = st.radio("Select tone:", ["Professional", "Concise", "Impactful"])
role = st.text_input("Target role or expertise (optional)")

# Feedback
st.markdown("### 🗣️ Feedback")
st.radio("Was this suggestion helpful?", ["👍 Yes", "👎 No"], horizontal=True)
