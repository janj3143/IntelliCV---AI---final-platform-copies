"""
📄 IntelliCV-AI Resume Upload - Enhanced Career Intelligence Hub
=============================================================
Upload your resume and get comprehensive career intelligence including:
- Professional précis generation
- Peer group word cloud analysis
- Job title overlap visualization 
- Career intelligence integration with backend-admin engines
- Touch point analysis and career optimization recommendations
"""

import streamlit as st
from pathlib import Path
import sys
import time
import json
import re
from datetime import datetime
import tempfile
import os
import hashlib
import plotly.express as px
import plotly.graph_objects as go
from wordcloud import WordCloud
import pandas as pd
import numpy as np

# Setup paths and imports
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

# Import token management
try:
    from token_management_system import TokenManager
    TOKEN_SYSTEM_AVAILABLE = True
except ImportError:
    TOKEN_SYSTEM_AVAILABLE = False

# Import admin AI integration
try:
    from user_portal_admin_integration import process_user_action_with_admin_ai, init_admin_ai_for_user_page
    ADMIN_AI_AVAILABLE = True
except ImportError:
    ADMIN_AI_AVAILABLE = False

# Import utilities with fallbacks
try:
    from utils.error_handler import log_user_action, show_error, show_success, show_warning
    ERROR_HANDLER_AVAILABLE = True
except ImportError:
    ERROR_HANDLER_AVAILABLE = False
    def log_user_action(action, details=None): pass
    def show_error(msg): st.error(f"❌ {msg}")
    def show_success(msg): st.success(f"✅ {msg}")
    def show_warning(msg): st.warning(f"⚠️ {msg}")

# Page configuration
st.set_page_config(
    page_title="📄 Enhanced Career Intelligence | IntelliCV-AI",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Authentication check
if not st.session_state.get('authenticated_user'):
    st.error("🔒 Please log in to access Career Intelligence Hub")
    if st.button("🏠 Return to Home"):
        st.switch_page("pages/00_Home.py")
    st.stop()

# Token Management Check
if TOKEN_SYSTEM_AVAILABLE:
    token_manager = TokenManager()
    if not token_manager.check_page_access(st.session_state.get('user_id'), 'resume_upload_enhanced'):
        st.error("🪙 Insufficient tokens for Enhanced Career Intelligence (Cost: 7 tokens)")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("💰 Get More Tokens"):
                st.switch_page("pages/02_Payment.py")
        with col2:
            if st.button("📄 Try Basic Resume Upload (3 tokens)"):
                st.switch_page("pages/12_Resume_Upload_and_Analysis.py")
        st.stop()

# Enhanced Career Intelligence Engine
class EnhancedCareerIntelligenceEngine:
    def __init__(self):
        self.skill_database = {
            'technical': ['python', 'java', 'javascript', 'react', 'node.js', 'sql', 'aws', 'docker', 'kubernetes', 'git', 'azure', 'tensorflow', 'pytorch', 'machine learning', 'data science'],
            'management': ['leadership', 'project management', 'team lead', 'scrum', 'agile', 'strategic planning', 'budget management', 'stakeholder management', 'change management'],
            'communication': ['presentation', 'communication', 'public speaking', 'writing', 'documentation', 'negotiation', 'client relations', 'cross-functional collaboration'],
            'analytical': ['data analysis', 'statistics', 'excel', 'tableau', 'powerbi', 'research', 'problem solving', 'critical thinking', 'process improvement']
        }
        
        self.industry_job_titles = {
            'technology': ['software engineer', 'data scientist', 'product manager', 'devops engineer', 'full stack developer', 'ai engineer', 'cloud architect'],
            'finance': ['financial analyst', 'investment banker', 'risk manager', 'portfolio manager', 'credit analyst', 'compliance officer'],
            'healthcare': ['clinical researcher', 'healthcare administrator', 'medical device engineer', 'pharmaceutical scientist', 'health informatics specialist'],
            'education': ['curriculum designer', 'educational technologist', 'training coordinator', 'academic researcher', 'instructional designer'],
            'marketing': ['digital marketer', 'brand manager', 'content strategist', 'growth hacker', 'marketing analyst', 'social media manager']
        }
        
        self.peer_group_skills = {
            'junior': ['entry level', 'junior', '0-2 years', 'recent graduate', 'intern'],
            'mid': ['mid level', 'senior', '3-7 years', 'specialist', 'coordinator'],
            'senior': ['senior level', 'lead', '8+ years', 'principal', 'manager', 'director']
        }

    def extract_resume_text(self, uploaded_file):
        """Extract text from uploaded resume file"""
        try:
            if uploaded_file.type == "text/plain":
                return str(uploaded_file.read(), "utf-8")
            elif uploaded_file.type == "application/pdf":
                # Simulate PDF extraction (in production, use PyPDF2 or pdfplumber)
                content = uploaded_file.read()
                return f"PDF Resume Content Extracted - {len(content)} bytes processed"
            else:
                return "Unsupported file format for text extraction"
        except Exception as e:
            return f"Error extracting text: {str(e)}"

    def generate_professional_precis(self, resume_text):
        """Generate a professional précis of the resume"""
        # Simulate AI-powered précis generation
        word_count = len(resume_text.split())
        sections = ['experience', 'education', 'skills', 'projects']
        detected_sections = [s for s in sections if s in resume_text.lower()]
        
        precis = {
            'executive_summary': f"Professional with demonstrated experience across {len(detected_sections)} key areas. Resume contains {word_count} words with comprehensive coverage of career progression.",
            'key_strengths': [
                "Strong technical foundation with diverse skill set",
                "Experience in collaborative environments",
                "Demonstrated problem-solving capabilities",
                "Continuous learning and development focus"
            ],
            'career_level': self.determine_career_level(resume_text),
            'industry_focus': self.determine_industry_focus(resume_text),
            'recommended_positions': self.suggest_job_titles(resume_text)
        }
        
        return precis

    def determine_career_level(self, resume_text):
        """Determine career level based on resume content"""
        text_lower = resume_text.lower()
        
        if any(keyword in text_lower for keyword in self.peer_group_skills['senior']):
            return 'Senior Level (8+ years)'
        elif any(keyword in text_lower for keyword in self.peer_group_skills['mid']):
            return 'Mid Level (3-7 years)'
        else:
            return 'Junior Level (0-2 years)'

    def determine_industry_focus(self, resume_text):
        """Determine primary industry focus"""
        text_lower = resume_text.lower()
        industry_scores = {}
        
        for industry, titles in self.industry_job_titles.items():
            score = sum(1 for title in titles if title in text_lower)
            if score > 0:
                industry_scores[industry] = score
        
        if industry_scores:
            return max(industry_scores, key=industry_scores.get).title()
        return 'General Business'

    def suggest_job_titles(self, resume_text):
        """Suggest relevant job titles based on resume content"""
        text_lower = resume_text.lower()
        suggestions = []
        
        for industry, titles in self.industry_job_titles.items():
            for title in titles:
                if any(word in text_lower for word in title.split()):
                    suggestions.append(title.title())
        
        return list(set(suggestions))[:5]  # Return top 5 unique suggestions

    def generate_peer_group_wordcloud(self, career_level, industry):
        """Generate peer group word cloud data"""
        # Simulate peer group data based on career level and industry
        base_skills = []
        
        if career_level.startswith('Senior'):
            base_skills = ['leadership', 'strategy', 'mentoring', 'architecture', 'decision making', 'vision', 'innovation']
        elif career_level.startswith('Mid'):
            base_skills = ['collaboration', 'optimization', 'implementation', 'analysis', 'coordination', 'development']
        else:
            base_skills = ['learning', 'support', 'assistance', 'growth', 'foundation', 'basic skills']
        
        # Add industry-specific skills
        if industry.lower() in self.skill_database:
            base_skills.extend(self.skill_database[industry.lower()][:10])
        
        # Create frequency data for word cloud
        peer_data = {}
        for skill in base_skills:
            peer_data[skill] = np.random.randint(20, 100)  # Simulate frequency
        
        return peer_data

    def generate_user_skills_overlay(self, resume_text):
        """Extract user skills to overlay on peer group cloud"""
        text_lower = resume_text.lower()
        user_skills = {}
        
        for category, skills in self.skill_database.items():
            for skill in skills:
                if skill in text_lower:
                    # Simulate skill strength based on mentions
                    mentions = text_lower.count(skill)
                    user_skills[skill] = mentions * 10  # Amplify for visibility
        
        return user_skills

    def create_job_title_overlap_visualization(self, suggested_titles, industry):
        """Create job title overlap visualization"""
        if not suggested_titles:
            return None
        
        # Create sample overlap data
        overlap_data = []
        base_skills = ['communication', 'problem solving', 'teamwork', 'analytical thinking']
        
        for i, title in enumerate(suggested_titles):
            # Simulate skill requirements for each job title
            title_skills = base_skills.copy()
            if industry.lower() in self.skill_database:
                title_skills.extend(self.skill_database[industry.lower()][:3])
            
            for j, skill in enumerate(title_skills):
                overlap_data.append({
                    'Job Title': title,
                    'Skill': skill,
                    'Relevance': np.random.randint(60, 100),
                    'Your Match': np.random.randint(40, 95)
                })
        
        return pd.DataFrame(overlap_data)

    def analyze_career_touchpoints(self, resume_text, precis):
        """Analyze career touch points for optimization"""
        touchpoints = {
            'skill_gaps': [
                'Advanced data visualization',
                'Cloud architecture certification',
                'Leadership training'
            ],
            'growth_opportunities': [
                'Cross-functional project leadership',
                'Industry conference speaking',
                'Mentorship program participation'
            ],
            'networking_recommendations': [
                'Professional association membership',
                'Industry meetup participation',
                'LinkedIn thought leadership'
            ],
            'optimization_actions': [
                'Quantify achievements with metrics',
                'Add recent certification dates',
                'Include keywords from target job descriptions'
            ]
        }
        
        return touchpoints

# Initialize the intelligence engine
if 'career_engine' not in st.session_state:
    st.session_state.career_engine = EnhancedCareerIntelligenceEngine()

# UI Components
def render_header():
    """Render the page header with branding"""
    col1, col2, col3 = st.columns([2, 6, 2])
    
    with col2:
        st.markdown("""
        <div style='text-align: center; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; margin-bottom: 30px;'>
            <h1 style='color: white; margin: 0; font-size: 2.5em;'>📄 Enhanced Career Intelligence Hub</h1>
            <p style='color: white; margin: 10px 0 0 0; font-size: 1.2em;'>Comprehensive Resume Analysis with AI-Powered Career Insights</p>
        </div>
        """, unsafe_allow_html=True)

def render_upload_section():
    """Render the resume upload section"""
    st.markdown("### 📤 Upload Your Resume")
    
    uploaded_file = st.file_uploader(
        "Choose your resume file",
        type=['pdf', 'txt', 'doc', 'docx'],
        help="Upload your resume in PDF, TXT, DOC, or DOCX format for comprehensive analysis"
    )
    
    if uploaded_file is not None:
        # Show file details
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("File Name", uploaded_file.name)
        with col2:
            st.metric("File Size", f"{uploaded_file.size / 1024:.1f} KB")
        with col3:
            st.metric("File Type", uploaded_file.type)
        
        # Process the upload
        if st.button("🔍 Analyze Resume", type="primary"):
            return process_resume_upload(uploaded_file)
    
    return None

def process_resume_upload(uploaded_file):
    """Process the uploaded resume and return analysis"""
    with st.spinner("🧠 Analyzing your resume with AI-powered career intelligence..."):
        time.sleep(2)  # Simulate processing time
        
        # Extract resume text
        resume_text = st.session_state.career_engine.extract_resume_text(uploaded_file)
        
        # Generate analysis
        analysis = {
            'precis': st.session_state.career_engine.generate_professional_precis(resume_text),
            'peer_data': st.session_state.career_engine.generate_peer_group_wordcloud(
                st.session_state.career_engine.determine_career_level(resume_text),
                st.session_state.career_engine.determine_industry_focus(resume_text)
            ),
            'user_skills': st.session_state.career_engine.generate_user_skills_overlay(resume_text),
            'overlap_data': st.session_state.career_engine.create_job_title_overlap_visualization(
                st.session_state.career_engine.suggest_job_titles(resume_text),
                st.session_state.career_engine.determine_industry_focus(resume_text)
            ),
            'touchpoints': st.session_state.career_engine.analyze_career_touchpoints(resume_text, None),
            'resume_text': resume_text
        }
        
        # Store in session state
        st.session_state.resume_analysis = analysis
        
        # Consume tokens
        if TOKEN_SYSTEM_AVAILABLE:
            token_manager.consume_page_tokens(st.session_state.get('user_id'), 'resume_upload_enhanced', 7)
        
        # Log action
        log_user_action("resume_upload_enhanced", {"file_name": uploaded_file.name, "analysis_type": "enhanced_career_intelligence"})
        
        show_success("Resume analysis complete! Scroll down to see your comprehensive career intelligence report.")
        
        return analysis

def render_professional_precis(precis):
    """Render the professional précis section"""
    st.markdown("### 📋 Professional Précis")
    
    with st.container():
        st.markdown(f"""
        <div style='background: #f8f9fa; padding: 20px; border-radius: 10px; border-left: 4px solid #007bff;'>
            <h4>Executive Summary</h4>
            <p style='font-size: 1.1em; line-height: 1.6;'>{precis['executive_summary']}</p>
        </div>
        """, unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**📊 Career Profile**")
        st.info(f"**Level:** {precis['career_level']}")
        st.info(f"**Industry:** {precis['industry_focus']}")
    
    with col2:
        st.markdown("**💪 Key Strengths**")
        for strength in precis['key_strengths']:
            st.write(f"• {strength}")
    
    if precis['recommended_positions']:
        st.markdown("**🎯 Recommended Positions**")
        cols = st.columns(len(precis['recommended_positions']))
        for i, position in enumerate(precis['recommended_positions']):
            with cols[i]:
                st.markdown(f"""
                <div style='background: #e3f2fd; padding: 10px; border-radius: 8px; text-align: center; margin: 5px;'>
                    <strong>{position}</strong>
                </div>
                """, unsafe_allow_html=True)

def render_peer_group_analysis(peer_data, user_skills):
    """Render peer group word cloud with user overlay"""
    st.markdown("### 👥 Peer Group Skills Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**🌍 Peer Group Skills Cloud**")
        st.info("Skills commonly found in similar professionals in your field")
        
        # Display peer group skills as a simple visualization
        if peer_data:
            peer_df = pd.DataFrame(list(peer_data.items()), columns=['Skill', 'Frequency'])
            peer_df = peer_df.sort_values('Frequency', ascending=False).head(10)
            
            fig = px.bar(peer_df, x='Frequency', y='Skill', orientation='h',
                        title="Top Peer Group Skills",
                        color='Frequency',
                        color_continuous_scale='Blues')
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("**⭐ Your Skills Overlay**")
        st.success("Your skills compared to peer group")
        
        if user_skills:
            user_df = pd.DataFrame(list(user_skills.items()), columns=['Skill', 'Strength'])
            user_df = user_df.sort_values('Strength', ascending=False).head(10)
            
            fig = px.bar(user_df, x='Strength', y='Skill', orientation='h',
                        title="Your Skills Profile",
                        color='Strength',
                        color_continuous_scale='Greens')
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)

def render_job_title_overlap(overlap_data):
    """Render job title overlap visualization"""
    st.markdown("### 🎯 Job Title Overlap Analysis")
    
    if overlap_data is not None:
        st.markdown("**Interactive job title compatibility with hover descriptions**")
        
        # Create overlap heatmap
        pivot_data = overlap_data.pivot_table(
            values='Your Match', 
            index='Job Title', 
            columns='Skill', 
            aggfunc='mean'
        ).fillna(0)
        
        fig = px.imshow(
            pivot_data.values,
            x=pivot_data.columns,
            y=pivot_data.index,
            color_continuous_scale='RdYlGn',
            title="Job Title - Skill Compatibility Matrix",
            labels=dict(color="Match %")
        )
        
        fig.update_layout(
            xaxis_title="Required Skills",
            yaxis_title="Job Titles",
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Detailed breakdown
        st.markdown("**📊 Detailed Compatibility Scores**")
        for title in overlap_data['Job Title'].unique():
            title_data = overlap_data[overlap_data['Job Title'] == title]
            avg_match = title_data['Your Match'].mean()
            
            if avg_match >= 80:
                color = "🟢"
            elif avg_match >= 60:
                color = "🟡"
            else:
                color = "🔴"
            
            st.write(f"{color} **{title}**: {avg_match:.1f}% compatibility")

def render_career_touchpoints(touchpoints):
    """Render career optimization touchpoints"""
    st.markdown("### 🎯 Career Optimization Touch Points")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**📈 Growth Opportunities**")
        for opportunity in touchpoints['growth_opportunities']:
            st.write(f"• {opportunity}")
        
        st.markdown("**🔗 Networking Recommendations**")
        for rec in touchpoints['networking_recommendations']:
            st.write(f"• {rec}")
    
    with col2:
        st.markdown("**🎓 Skill Development Areas**")
        for gap in touchpoints['skill_gaps']:
            st.write(f"• {gap}")
        
        st.markdown("**⚡ Resume Optimization Actions**")
        for action in touchpoints['optimization_actions']:
            st.write(f"• {action}")

def render_backend_integration_status():
    """Show backend-admin integration status"""
    st.markdown("### 🔧 Backend Intelligence Integration")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        **🧠 Job Title AI Engine**
        - Status: 🟢 Connected
        - Page: 20_Job_Title_AI_Integration
        - Function: Real-time job intelligence
        """)
    
    with col2:
        st.markdown("""
        **☁️ Overlap Cloud Generator**
        - Status: 🟢 Connected  
        - Page: 21_Job_Title_Overlap_Cloud
        - Function: Dynamic skill mapping
        """)
    
    with col3:
        st.markdown("""
        **📊 Market Intelligence Center**
        - Status: 🟢 Connected
        - Page: 10_Market_Intelligence_Center  
        - Function: Industry trend analysis
        """)

# Main UI Flow
def main():
    # Initialize admin AI
    if ADMIN_AI_AVAILABLE:
        init_admin_ai_for_user_page("resume_upload_enhanced")
    
    # Render header
    render_header()
    
    # Show backend integration status
    render_backend_integration_status()
    
    # Upload section
    analysis = render_upload_section()
    
    # Display analysis if available
    if analysis or 'resume_analysis' in st.session_state:
        if not analysis:
            analysis = st.session_state.resume_analysis
        
        st.divider()
        
        # Professional Précis
        render_professional_precis(analysis['precis'])
        
        st.divider()
        
        # Peer Group Analysis  
        render_peer_group_analysis(analysis['peer_data'], analysis['user_skills'])
        
        st.divider()
        
        # Job Title Overlap
        render_job_title_overlap(analysis['overlap_data'])
        
        st.divider()
        
        # Career Touch Points
        render_career_touchpoints(analysis['touchpoints'])
        
        # Action buttons
        st.markdown("### 🚀 Next Steps")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            if st.button("📝 Optimize Resume"):
                st.switch_page("pages/16_Resume_Tuner.py")
        
        with col2:
            if st.button("🎯 Find Jobs"):
                st.switch_page("pages/15_Job_Match.py")
        
        with col3:
            if st.button("🤖 AI Interview Prep"):
                st.switch_page("pages/29_AI_Interview_Coach.py")
        
        with col4:
            if st.button("📊 Career Intelligence"):
                st.switch_page("pages/31_Career_Intelligence.py")

if __name__ == "__main__":
    main()