"""
IntelliCV Geographic Career Finder
Location-based career opportunities and geographic intelligence
Token Cost: 7 tokens (Advanced Tier)
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import json

# Page configuration
st.set_page_config(
    page_title="Geo Career Finder - IntelliCV",
    page_icon="🌍",
    layout="wide"
)

def main():
    st.title("🌍 Geographic Career Finder")
    st.markdown("### Location-based career opportunities and geographic intelligence")
    
    # Token cost display
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.info("💎 **Token Cost: 7 tokens** | Advanced Tier Feature")
    
    # Main tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "🗺️ Location Explorer", 
        "💼 Job Market Analysis", 
        "🏠 Lifestyle Matcher", 
        "📊 Career Migration"
    ])
    
    with tab1:
        st.header("🗺️ Career Location Explorer")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.subheader("🎯 Search Preferences")
            
            job_title = st.text_input("Target job title", value="Data Scientist")
            experience_level = st.selectbox("Experience level", 
                                          ["Entry Level", "Mid Level", "Senior Level", "Executive"])
            
            preferred_countries = st.multiselect(
                "Preferred countries",
                ["United States", "Canada", "United Kingdom", "Germany", "Australia", 
                 "Netherlands", "Singapore", "Switzerland", "Sweden", "Ireland"],
                default=["United States", "Canada"]
            )
            
            salary_min = st.number_input("Minimum salary (USD)", value=50000, step=5000)
            remote_work = st.checkbox("Include remote opportunities", value=True)
            visa_sponsorship = st.checkbox("Requires visa sponsorship", value=False)
            
            if st.button("🔍 Search Opportunities"):
                st.success("✅ Found 847 opportunities across 23 cities!")
        
        with col2:
            st.subheader("🌐 Global Opportunity Map")
            
            # Sample geographic data
            geo_data = {
                'City': ['San Francisco', 'New York', 'London', 'Toronto', 'Berlin', 
                        'Amsterdam', 'Singapore', 'Sydney', 'Stockholm', 'Dublin'],
                'Country': ['USA', 'USA', 'UK', 'Canada', 'Germany', 
                           'Netherlands', 'Singapore', 'Australia', 'Sweden', 'Ireland'],
                'Opportunities': [1250, 980, 750, 420, 380, 220, 340, 190, 160, 140],
                'Avg_Salary': [145000, 130000, 85000, 75000, 70000, 80000, 90000, 85000, 75000, 80000],
                'lat': [37.7749, 40.7128, 51.5074, 43.6532, 52.5200, 52.3676, 1.3521, -33.8688, 59.3293, 53.3498],
                'lon': [-122.4194, -74.0060, -0.1278, -79.3832, 13.4050, 4.9041, 103.8198, 151.2093, 18.0686, -6.2603]
            }
            
            df = pd.DataFrame(geo_data)
            
            fig = px.scatter_mapbox(df, lat="lat", lon="lon", 
                                   hover_name="City",
                                   hover_data=["Country", "Opportunities", "Avg_Salary"],
                                   color="Opportunities",
                                   size="Avg_Salary",
                                   color_continuous_scale=px.colors.cyclical.IceFire,
                                   size_max=20,
                                   zoom=1,
                                   mapbox_style="open-street-map")
            
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        st.header("💼 Regional Job Market Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📊 Market Dynamics")
            
            selected_city = st.selectbox("Select city for analysis", 
                                       ["San Francisco", "New York", "London", "Toronto", "Berlin"])
            
            # Market metrics
            st.metric("Active Job Postings", "1,247", "↗️ +18%")
            st.metric("Average Salary", "$145,000", "↗️ +8%")
            st.metric("Competition Index", "High", "⚠️")
            st.metric("Growth Rate", "12%", "↗️ +3%")
            
            st.subheader("🏢 Top Employers")
            employers = [
                "Google", "Meta", "Apple", "Microsoft", "Netflix",
                "Salesforce", "Uber", "Airbnb", "Twitter", "LinkedIn"
            ]
            
            for i, employer in enumerate(employers[:5], 1):
                st.write(f"**{i}.** {employer}")
        
        with col2:
            st.subheader("📈 Salary Trends")
            
            # Salary trend data
            months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                     'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            salaries = [140000, 142000, 141000, 143000, 145000, 147000,
                       148000, 150000, 149000, 151000, 152000, 154000]
            
            fig = px.line(x=months, y=salaries, 
                         title=f"Average Salary Trends - {selected_city}",
                         labels={'x': 'Month', 'y': 'Average Salary (USD)'})
            st.plotly_chart(fig, use_container_width=True)
            
            st.subheader("🎯 Skills in Demand")
            skills_demand = {
                'Skill': ['Python', 'Machine Learning', 'SQL', 'AWS', 'Docker', 
                         'Kubernetes', 'React', 'Java', 'TensorFlow', 'Git'],
                'Demand': [95, 88, 85, 82, 78, 75, 73, 70, 68, 65]
            }
            
            skills_df = pd.DataFrame(skills_demand)
            fig = px.bar(skills_df, x='Demand', y='Skill', orientation='h',
                        title="Top Skills in Demand")
            st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        st.header("🏠 Lifestyle & Location Matcher")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🎯 Lifestyle Preferences")
            
            climate_pref = st.selectbox("Climate preference", 
                                       ["Mild/Temperate", "Warm/Tropical", "Cold/Continental", "No preference"])
            
            cost_of_living = st.selectbox("Cost of living preference",
                                        ["Low", "Moderate", "High", "No preference"])
            
            city_size = st.selectbox("City size preference",
                                   ["Small town", "Mid-size city", "Large city", "Megacity"])
            
            commute_time = st.slider("Max commute time (minutes)", 15, 120, 30)
            
            lifestyle_factors = st.multiselect(
                "Important lifestyle factors",
                ["Cultural diversity", "Nightlife", "Outdoor activities", "Public transport",
                 "Education quality", "Healthcare", "Safety", "Arts scene"],
                default=["Cultural diversity", "Public transport", "Safety"]
            )
        
        with col2:
            st.subheader("🎯 Recommended Locations")
            
            # Lifestyle matching results
            locations = [
                {"city": "Amsterdam", "match": 94, "highlights": "Great culture, excellent public transport"},
                {"city": "Toronto", "match": 91, "highlights": "Diverse, safe, good healthcare"},
                {"city": "Melbourne", "match": 88, "highlights": "Arts scene, outdoor activities"},
                {"city": "Copenhagen", "match": 85, "highlights": "High quality of life, bike-friendly"},
                {"city": "Singapore", "match": 82, "highlights": "Safe, efficient, diverse food scene"}
            ]
            
            for loc in locations:
                with st.expander(f"🏙️ {loc['city']} - {loc['match']}% match"):
                    st.write(f"**Match Score:** {loc['match']}%")
                    st.write(f"**Highlights:** {loc['highlights']}")
                    
                    col_a, col_b, col_c = st.columns(3)
                    with col_a:
                        st.metric("Job Opportunities", "245")
                    with col_b:
                        st.metric("Avg Salary", "$85k")
                    with col_c:
                        st.metric("Living Cost", "High")
    
    with tab4:
        st.header("📊 Career Migration Planning")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🎯 Migration Planner")
            
            current_location = st.text_input("Current location", value="Chicago, IL")
            target_location = st.selectbox("Target location", 
                                         ["San Francisco, CA", "New York, NY", "London, UK", 
                                          "Toronto, ON", "Berlin, Germany"])
            
            timeline = st.selectbox("Migration timeline", 
                                   ["3 months", "6 months", "1 year", "2+ years"])
            
            st.subheader("📋 Migration Checklist")
            
            checklist_items = [
                "Research visa requirements",
                "Calculate cost of living differences",
                "Build network in target location",
                "Update resume for local market",
                "Research housing options",
                "Plan interview trips",
                "Arrange document transfers",
                "Setup banking/financial accounts"
            ]
            
            for item in checklist_items:
                st.checkbox(item, key=f"checklist_{item}")
        
        with col2:
            st.subheader("💰 Migration Cost Calculator")
            
            # Cost breakdown
            costs = {
                'Category': ['Visa/Legal', 'Moving', 'Housing Deposit', 'Travel', 
                           'Temporary Accommodation', 'Job Search', 'Total'],
                'Estimated Cost': [5000, 8000, 12000, 2500, 6000, 3000, 36500]
            }
            
            cost_df = pd.DataFrame(costs)
            
            # Exclude total for the chart
            chart_df = cost_df[cost_df['Category'] != 'Total']
            
            fig = px.pie(chart_df, values='Estimated Cost', names='Category',
                        title="Migration Cost Breakdown")
            st.plotly_chart(fig, use_container_width=True)
            
            st.subheader("⏱️ Timeline Planner")
            
            timeline_items = [
                ("Research & Planning", "Month 1-2"),
                ("Visa Application", "Month 2-4"),
                ("Job Applications", "Month 3-5"),
                ("Interviews", "Month 4-6"),
                ("Job Offer & Acceptance", "Month 5-6"),
                ("Relocation", "Month 6-7")
            ]
            
            for item, timeframe in timeline_items:
                st.write(f"**{item}:** {timeframe}")

if __name__ == "__main__":
    main()