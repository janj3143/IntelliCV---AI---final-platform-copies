import streamlit as st
import tempfile
from utils.session_manager import session_manager
from utils.resume_nlp import extract_keywords_from_resume
from io import BytesIO
from docx import Document
from fpdf import FPDF

st.set_page_config(page_title="Resume Feedback", page_icon="📝")
st.title("📝 Resume Feedback")

session_id = st.session_state.get('session_id', 'default')
session = session_manager.get_or_create(session_id)

user_name = session.context.get("user_profile", {}).get("name", "Anonymous User")
resume_name = st.session_state.get("last_resume_name", "Unknown File")
resume_path = st.session_state.get("uploaded_resume_path")

st.caption(f"👤 Logged in as: **{user_name}**")
st.caption(f"📄 Resume: **{resume_name}**")

score_tab, coverage_tab, star_tab, improve_tab, holly_tab = st.tabs([
    "📊 Overview & Score",
    "🔑 Keyword Coverage",
    "🌟 STAR Suggestions",
    "🛠️ Improvement Plan",
    "🤖 Holly's Suggestions"
])

with score_tab:
    st.header("📊 Resume Overview & Score")
    resume_keywords = extract_keywords_from_resume(resume_path)
    with open(resume_path, "rb") as f:
        resume_text = f.read().decode("utf-8", errors="ignore")
    word_count = len(resume_text.split())
    ats_score = max(0, min(100, 100 - abs(word_count - 500) // 5))

    st.metric("Word Count", word_count)
    st.metric("Keyword Count", len(resume_keywords))
    st.progress(ats_score)
    st.success(f"Estimated ATS Score: {ats_score}%")

with coverage_tab:
    st.header("🔑 Keyword Match Against Target JD")
    if "jd_keywords" in session.context:
        jd_keywords = session.context["jd_keywords"]
        overlap = set(resume_keywords) & set(jd_keywords)
        missing = set(jd_keywords) - set(resume_keywords)
        st.metric("Match Score", f"{int(100 * len(overlap) / max(len(jd_keywords), 1))}%")
        st.write("✅ Overlapping Keywords:", list(overlap))
        st.write("❌ Missing from Resume:", list(missing))
    else:
        st.info("Upload a Job Description in the JD Upload page to see keyword match.")

with star_tab:
    st.header("🌟 STAR Bullet Point Suggestions")
    role = st.text_input("Enter your role or target job title (e.g., Data Analyst):")
    if st.button("Generate STAR Bullets"):
        st.success("✨ Here are some STAR-based bullet points:")
        bullets = [
            "⭐ Resolved system latency issues, reducing API response time by 60%.",
            "⭐ Coordinated deployment across 3 regions with zero downtime.",
            "⭐ Led a team of 5 engineers to deliver features 2 weeks ahead of schedule."
        ]
        for b in bullets:
            st.markdown(f"- {b}")

with improve_tab:
    st.header("🛠️ Improvement Plan")
    st.markdown("### 📝 Suggestions to Strengthen Your Resume")
    st.markdown("""
    - Add quantifiable metrics (percentages, numbers, impact)
    - Use stronger action verbs
    - Tailor keywords to match job descriptions
    - Keep formatting consistent
    - Limit to 1-2 pages for most roles
    """)

with holly_tab:
    st.header("🤖 Holly's AI-Powered Suggestions")
    st.info("Holly is analyzing your resume...")
    st.markdown("### 🧠 AI Insights")
    st.markdown("""
    - Consider adding more technical skills relevant to your target role
    - Your experience section could benefit from more specific achievements
    - Great use of action verbs! Keep it up.
    """)
