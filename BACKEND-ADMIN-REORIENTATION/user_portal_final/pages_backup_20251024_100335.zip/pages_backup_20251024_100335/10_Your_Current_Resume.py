"""
📄 IntelliCV-AI Your Current Resume - Ultimate Management Hub
===========================================================
Your comprehensive resume management center combining all features:
- Current resume status and up-to-date verification with health scoring
- Resume history with detailed job application touchpoint tracking
- AI-powered resume builder with interactive chatbot guidance
- Company research and job description web scraping
- Professional template library with customization
- Quick actions for optimization and analysis
- Job glossary integration and manual job description support

Enhanced hub merging Pages 10 + 14 features for ultimate resume management
"""

import streamlit as st
from pathlib import Path
import sys
from datetime import datetime, timedelta
import json
import time
import tempfile
import os

# Setup paths and imports
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

# Import shared components
try:
    from shared_components import apply_professional_styling, show_logo_watermark, initialize_session_manager
    from utils.session_manager import session_manager
    SHARED_COMPONENTS_AVAILABLE = True
except ImportError:
    SHARED_COMPONENTS_AVAILABLE = False

# Import admin AI integration
try:
    from user_portal_admin_integration import AdminAIIntegration
    ADMIN_AI_AVAILABLE = True
except ImportError:
    ADMIN_AI_AVAILABLE = False

class CurrentResumeManager:
    """Comprehensive current resume management system"""
    
    def __init__(self):
        self.admin_ai = AdminAIIntegration() if ADMIN_AI_AVAILABLE else None
        self.initialize_session_state()
        
    def initialize_session_state(self):
        """Initialize session state variables"""
        if 'current_resume_status' not in st.session_state:
            st.session_state.current_resume_status = 'needs_verification'
        if 'last_job_application' not in st.session_state:
            st.session_state.last_job_application = None
        if 'resume_builder_mode' not in st.session_state:
            st.session_state.resume_builder_mode = False
        if 'chatbot_step' not in st.session_state:
            st.session_state.chatbot_step = 'start'
        if 'new_job_data' not in st.session_state:
            st.session_state.new_job_data = {}
            
    def check_resume_freshness(self, session):
        """Check if current resume is up to date"""
        resume_versions = session.context.get("resume_versions", [])
        
        if not resume_versions:
            return "no_resume", "No resume found"
        
        master_resume = resume_versions[0]
        last_update = master_resume.get("timestamp")
        
        if last_update:
            try:
                last_update_date = datetime.fromisoformat(last_update)
                days_since_update = (datetime.now() - last_update_date).days
                
                if days_since_update > 90:
                    return "outdated", f"Last updated {days_since_update} days ago"
                elif days_since_update > 30:
                    return "needs_review", f"Last updated {days_since_update} days ago"
                else:
                    return "current", f"Updated {days_since_update} days ago"
            except:
                return "unknown", "Update date unclear"
        
        return "unknown", "No timestamp available"
    
    def show_resume_status_dashboard(self, session):
        """Show current resume status dashboard"""
        st.markdown("### 📊 Your Resume Status")
        
        status, message = self.check_resume_freshness(session)
        resume_versions = session.context.get("resume_versions", [])
        
        # Status cards
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            if status == "current":
                st.success(f"✅ **Up to Date**\n\n{message}")
            elif status == "needs_review":
                st.warning(f"⚠️ **Needs Review**\n\n{message}")
            elif status == "outdated":
                st.error(f"🚨 **Outdated**\n\n{message}")
            else:
                st.info(f"❓ **Status Unknown**\n\n{message}")
        
        with col2:
            total_versions = len(resume_versions)
            st.metric("Total Versions", total_versions)
            if total_versions > 0:
                st.caption("📈 Version history available")
        
        with col3:
            if resume_versions:
                master_resume = resume_versions[0]
                word_count = len(master_resume.get("content", "").split())
                st.metric("Word Count", word_count)
                st.caption("📝 Current master resume")
        
        with col4:
            # Simulate job applications tracking
            apps_this_month = st.session_state.get('job_applications_count', 0)
            st.metric("Applications This Month", apps_this_month)
            st.caption("🎯 Job application activity")
    
    def show_resume_verification_prompt(self, session):
        """Show resume up-to-date verification prompt"""
        st.markdown("### ❓ Is Your Resume Current?")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("✅ **Yes, it's up to date**", use_container_width=True):
                st.session_state.current_resume_status = 'verified_current'
                # Update timestamp
                resume_versions = session.context.get("resume_versions", [])
                if resume_versions:
                    resume_versions[0]["verified_date"] = datetime.now().isoformat()
                st.success("✅ Resume marked as current!")
                st.rerun()
        
        with col2:
            if st.button("🔄 **No, needs updating**", use_container_width=True):
                st.session_state.resume_builder_mode = True
                st.session_state.chatbot_step = 'start'
                st.success("🤖 Starting resume builder assistant!")
                st.rerun()
    
    def show_resume_history(self, session):
        """Show resume version history"""
        st.markdown("### 📚 Resume History & Versions")
        
        resume_versions = session.context.get("resume_versions", [])
        
        if not resume_versions:
            st.info("📝 No resume versions found. Upload your first resume to get started!")
            return
        
        # Master resume highlight
        st.markdown("#### ⭐ Master Resume (Current)")
        master_resume = resume_versions[0]
        
        master_col1, master_col2 = st.columns([3, 1])
        
        with master_col1:
            preview_text = master_resume.get("content", "")[:500] + "..." if len(master_resume.get("content", "")) > 500 else master_resume.get("content", "")
            st.text_area("📄 Master Resume Preview", preview_text, height=150, disabled=True)
        
        with master_col2:
            st.markdown("**📊 Quick Stats**")
            word_count = len(master_resume.get("content", "").split())
            st.metric("Words", word_count)
            
            if "timestamp" in master_resume:
                st.caption(f"📅 Last Updated: {master_resume['timestamp'][:10]}")
            
            if "verified_date" in master_resume:
                st.caption(f"✅ Verified: {master_resume['verified_date'][:10]}")
            
            # Download master
            st.download_button(
                "⬇️ Download Master",
                master_resume.get("content", ""),
                file_name="master_resume.txt",
                use_container_width=True
            )
        
        # Version history
        if len(resume_versions) > 1:
            st.markdown("#### 📜 Version History")
            
            for idx, version in enumerate(resume_versions[1:], 1):
                with st.expander(f"📄 Version {idx + 1} - {version.get('tag', 'Untitled')}"):
                    
                    hist_col1, hist_col2 = st.columns([2, 1])
                    
                    with hist_col1:
                        preview = version.get("content", "")[:300] + "..." if len(version.get("content", "")) > 300 else version.get("content", "")
                        st.text_area("Preview", preview, height=100, disabled=True, key=f"hist_preview_{idx}")
                        
                        # Version notes
                        note_key = f"note_{idx}"
                        note_value = version.get("note", "")
                        updated_note = st.text_input("📝 Version Note", value=note_value, key=note_key)
                        version["note"] = updated_note
                    
                    with hist_col2:
                        word_count = len(version.get("content", "").split())
                        st.metric("Words", word_count)
                        
                        if "timestamp" in version:
                            st.caption(f"📅 Created: {version['timestamp'][:10]}")
                        
                        # Actions
                        st.download_button(
                            "⬇️ Download",
                            version.get("content", ""),
                            file_name=f"resume_v{idx + 1}.txt",
                            key=f"download_hist_{idx}",
                            use_container_width=True
                        )
                        
                        if st.button(f"⭐ Promote to Master", key=f"promote_{idx}"):
                            # Move this version to master position
                            promoted = resume_versions.pop(idx)
                            resume_versions.insert(0, promoted)
                            st.success(f"✅ Version {idx + 1} promoted to master!")
                            st.rerun()
    
    def show_job_touchpoints(self, session):
        """Show job touchpoints and application tracking"""
        st.markdown("### 🎯 Job Application Touchpoints")
        
        # Simulate job touchpoints data
        touchpoints = st.session_state.get('job_touchpoints', [
            {
                'company': 'TechCorp Inc.',
                'position': 'Senior Developer',
                'applied_date': '2024-10-20',
                'resume_version': 'Master',
                'status': 'Interview Scheduled',
                'key_skills_highlighted': ['Python', 'React', 'Leadership']
            },
            {
                'company': 'DataTech Solutions',
                'position': 'Data Scientist',
                'applied_date': '2024-10-18',
                'resume_version': 'Version 2',
                'status': 'Under Review',
                'key_skills_highlighted': ['Machine Learning', 'Python', 'Statistics']
            }
        ])
        
        if touchpoints:
            for idx, touchpoint in enumerate(touchpoints):
                with st.expander(f"🏢 {touchpoint['company']} - {touchpoint['position']}", expanded=idx==0):
                    
                    tp_col1, tp_col2 = st.columns([2, 1])
                    
                    with tp_col1:
                        st.markdown(f"**Position:** {touchpoint['position']}")
                        st.markdown(f"**Applied:** {touchpoint['applied_date']}")
                        st.markdown(f"**Status:** {touchpoint['status']}")
                        st.markdown(f"**Resume Used:** {touchpoint['resume_version']}")
                        
                        # Key skills highlighted
                        skills_text = ", ".join(touchpoint['key_skills_highlighted'])
                        st.markdown(f"**Key Skills Highlighted:** {skills_text}")
                    
                    with tp_col2:
                        # Quick actions
                        if st.button("📧 Follow Up", key=f"followup_{idx}"):
                            st.info("📧 Follow-up template opened!")
                        
                        if st.button("📊 Track Progress", key=f"track_{idx}"):
                            st.info("📊 Progress tracking updated!")
        else:
            st.info("🎯 No job applications tracked yet. Start applying to see touchpoints here!")
    
    def show_resume_builder_chatbot(self):
        """Show AI chatbot for resume building"""
        st.markdown("### 🤖 Resume Builder Assistant")
        
        chatbot_step = st.session_state.chatbot_step
        new_job_data = st.session_state.new_job_data
        
        if chatbot_step == 'start':
            st.markdown("**👋 Hi! I'll help you add new experience to your resume. Let's start with your job title.**")
            
            job_title = st.text_input("💼 What's your job title?", key="job_title_input")
            
            if job_title and st.button("Next ➡️"):
                st.session_state.new_job_data['job_title'] = job_title
                st.session_state.chatbot_step = 'start_date'
                st.rerun()
        
        elif chatbot_step == 'start_date':
            st.markdown(f"**Great! You're adding: {new_job_data.get('job_title', '')}**")
            st.markdown("**📅 When did you start this position?**")
            
            start_date = st.date_input("Start Date", key="start_date_input")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("⬅️ Back"):
                    st.session_state.chatbot_step = 'start'
                    st.rerun()
            
            with col2:
                if st.button("Next ➡️"):
                    st.session_state.new_job_data['start_date'] = start_date.isoformat()
                    st.session_state.chatbot_step = 'salary'
                    st.rerun()
        
        elif chatbot_step == 'salary':
            st.markdown("**💰 Would you like to include salary information? (Optional)**")
            
            include_salary = st.checkbox("Include salary in resume")
            
            if include_salary:
                salary = st.number_input("Annual Salary", min_value=0, step=1000, key="salary_input")
                salary_visible = st.checkbox("Make salary visible to employers")
                st.session_state.new_job_data['salary'] = salary
                st.session_state.new_job_data['salary_visible'] = salary_visible
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("⬅️ Back"):
                    st.session_state.chatbot_step = 'start_date'
                    st.rerun()
            
            with col2:
                if st.button("Next ➡️"):
                    st.session_state.chatbot_step = 'company'
                    st.rerun()
        
        elif chatbot_step == 'company':
            st.markdown("**🏢 What company is this for?**")
            
            company_name = st.text_input("Company Name", key="company_input")
            
            if company_name:
                st.session_state.new_job_data['company'] = company_name
                
                # Offer AI company research
                if st.button("🔍 **AI Research This Company**", use_container_width=True):
                    with st.spinner("🔍 Researching company..."):
                        time.sleep(2)  # Simulate AI research
                        
                        # Simulated company research
                        company_info = {
                            'logo_url': 'https://via.placeholder.com/100x50?text=LOGO',
                            'description': f"{company_name} is a leading technology company focused on innovation and digital transformation. The company provides cutting-edge solutions across multiple industry sectors.",
                            'industry': 'Technology',
                            'size': '1000-5000 employees',
                            'founded': '2010'
                        }
                        
                        st.session_state.new_job_data['company_info'] = company_info
                        
                        st.success("✅ Company research complete!")
                        
                        # Show company info
                        st.markdown("**📋 Company Information:**")
                        st.markdown(f"**Industry:** {company_info['industry']}")
                        st.markdown(f"**Size:** {company_info['size']}")
                        st.markdown(f"**Founded:** {company_info['founded']}")
                        st.markdown(f"**Description:** {company_info['description']}")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("⬅️ Back"):
                    st.session_state.chatbot_step = 'salary'
                    st.rerun()
            
            with col2:
                if company_name and st.button("Next ➡️"):
                    st.session_state.chatbot_step = 'job_description'
                    st.rerun()
        
        elif chatbot_step == 'job_description':
            st.markdown("**📝 Now let's add your job description.**")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**✍️ Write your own description:**")
                custom_desc = st.text_area("Job Description", height=150, key="custom_desc")
                
                if st.button("Use Custom Description"):
                    st.session_state.new_job_data['job_description'] = custom_desc
                    st.session_state.chatbot_step = 'review'
                    st.rerun()
            
            with col2:
                st.markdown("**🤖 Use Global Job Title Glossary:**")
                
                if st.button("🔍 **Search Job Title Database**", use_container_width=True):
                    with st.spinner("🔍 Searching job title glossary..."):
                        time.sleep(1)
                        
                        # Simulated job title match
                        job_title = new_job_data.get('job_title', '')
                        glossary_desc = f"""
• Lead and manage cross-functional teams to deliver high-quality software solutions
• Develop and implement strategic initiatives to improve operational efficiency
• Collaborate with stakeholders to define project requirements and deliverables
• Mentor junior team members and provide technical guidance
• Ensure adherence to industry best practices and quality standards
• Drive innovation and continuous improvement within the organization
                        """.strip()
                        
                        st.session_state.new_job_data['job_description'] = glossary_desc
                        
                        st.success("✅ Job description generated from glossary!")
                        st.text_area("Generated Description", glossary_desc, height=150, disabled=True)
                        
                        if st.button("Use This Description"):
                            st.session_state.chatbot_step = 'review'
                            st.rerun()
            
            # Back button
            if st.button("⬅️ Back"):
                st.session_state.chatbot_step = 'company'
                st.rerun()
        
        elif chatbot_step == 'review':
            st.markdown("**📋 Review Your New Job Entry**")
            
            # Show complete job entry
            job_data = st.session_state.new_job_data
            
            st.markdown(f"**💼 Job Title:** {job_data.get('job_title', '')}")
            st.markdown(f"**📅 Start Date:** {job_data.get('start_date', '')}")
            
            if 'salary' in job_data:
                visibility = "Visible" if job_data.get('salary_visible', False) else "Hidden"
                st.markdown(f"**💰 Salary:** ${job_data['salary']:,} ({visibility})")
            
            st.markdown(f"**🏢 Company:** {job_data.get('company', '')}")
            
            if 'company_info' in job_data:
                st.markdown(f"**🏭 Industry:** {job_data['company_info']['industry']}")
            
            st.markdown("**📝 Job Description:**")
            st.text_area("Description", job_data.get('job_description', ''), height=150, disabled=True)
            
            # Final actions
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button("⬅️ Edit Description"):
                    st.session_state.chatbot_step = 'job_description'
                    st.rerun()
            
            with col2:
                if st.button("✅ **Add to Resume**", use_container_width=True):
                    # Here we would integrate with resume updating logic
                    st.success("✅ New job entry added to your resume!")
                    st.session_state.resume_builder_mode = False
                    st.session_state.chatbot_step = 'start'
                    st.session_state.new_job_data = {}
                    st.rerun()
            
            with col3:
                if st.button("❌ Cancel"):
                    st.session_state.resume_builder_mode = False
                    st.session_state.chatbot_step = 'start'
                    st.session_state.new_job_data = {}
                    st.rerun()

def main():
    """Main function for Your Current Resume page"""
    
    # Apply styling
    if SHARED_COMPONENTS_AVAILABLE:
        apply_professional_styling()
        show_logo_watermark()
    
    # Initialize session
    session_id = st.session_state.get("session_id", "default")
    if SHARED_COMPONENTS_AVAILABLE:
        session = session_manager.get_or_create(session_id)
    else:
        # Fallback session structure
        class MockSession:
            def __init__(self):
                self.context = {"resume_versions": []}
        session = MockSession()
    
    # Initialize manager
    resume_manager = CurrentResumeManager()
    
    # Page header with gradient
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                padding: 2rem; border-radius: 10px; margin-bottom: 2rem; color: white;">
        <h1 style="margin: 0; font-size: 2.5rem;">📄 Your Current Resume</h1>
        <p style="margin: 0.5rem 0 0 0; font-size: 1.2rem; opacity: 0.9;">
            Your comprehensive resume management hub
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Show resume status dashboard
    resume_manager.show_resume_status_dashboard(session)
    
    # Resume verification or builder mode
    if st.session_state.current_resume_status == 'needs_verification':
        resume_manager.show_resume_verification_prompt(session)
    elif st.session_state.resume_builder_mode:
        resume_manager.show_resume_builder_chatbot()
    else:
        # Main content tabs
        tab1, tab2, tab3 = st.tabs(["📚 Resume History", "🎯 Job Touchpoints", "🛠️ Quick Tools"])
        
        with tab1:
            resume_manager.show_resume_history(session)
        
        with tab2:
            resume_manager.show_job_touchpoints(session)
        
        with tab3:
            st.markdown("### 🛠️ Quick Resume Tools")
            
            tool_col1, tool_col2, tool_col3 = st.columns(3)
            
            with tool_col1:
                if st.button("🤖 **Resume Builder**", use_container_width=True):
                    st.session_state.resume_builder_mode = True
                    st.session_state.chatbot_step = 'start'
                    st.rerun()
            
            with tool_col2:
                if st.button("⚡ **Express Analysis**", use_container_width=True):
                    st.switch_page("pages/09_Resume_Upload_Career_Intelligence_Express.py")
            
            with tool_col3:
                if st.button("📊 **Full Intelligence**", use_container_width=True):
                    st.switch_page("pages/11_Career_Intelligence_Suite.py")
            
            # Additional tools
            st.markdown("#### 🔧 Advanced Tools")
            
            adv_col1, adv_col2 = st.columns(2)
            
            with adv_col1:
                st.markdown("**🔍 Analysis Tools:**")
                if st.button("📈 Skills Gap Analysis"):
                    st.info("🔍 Skills gap analysis coming soon!")
                if st.button("🎯 ATS Optimization"):
                    st.info("🎯 ATS optimization tools coming soon!")
            
            with adv_col2:
                st.markdown("**🚀 Career Tools:**")
                if st.button("💼 Job Matching"):
                    st.switch_page("pages/12_Job_Matching_AI.py")
                if st.button("📝 Cover Letter Generator"):
                    st.info("📝 Cover letter generator coming soon!")
    
    # Quick action sidebar
    with st.sidebar:
        st.markdown("### 🚀 Quick Actions")
        
        if st.button("📤 Upload New Resume", use_container_width=True):
            st.switch_page("pages/09_Resume_Upload_Career_Intelligence_Express.py")
        
        if st.button("📊 Career Intelligence", use_container_width=True):
            st.switch_page("pages/11_Career_Intelligence_Suite.py")
        
        if st.button("🎯 Job Matching", use_container_width=True):
            st.switch_page("pages/12_Job_Matching_AI.py")
        
        st.markdown("---")
        st.markdown("### 📈 Resume Stats")
        
        # Quick stats from session
        resume_versions = session.context.get("resume_versions", [])
        if resume_versions:
            master_word_count = len(resume_versions[0].get("content", "").split())
            st.metric("Master Resume Words", master_word_count)
            st.metric("Total Versions", len(resume_versions))
        else:
            st.info("📝 Upload your first resume to see stats!")

if __name__ == "__main__":
    main()