import streamlit as st
import difflib
from utils.resume_utils import get_latest_resume_versions

st.set_page_config(page_title="Resume Diff Viewer", layout="wide")

st.title("🆚 Resume Version Diff")

resume_versions = get_latest_resume_versions()
if not resume_versions:
    st.warning("No resume versions found.")
    st.stop()

version_names = list(resume_versions.keys())
version1 = st.selectbox("Compare Version A", version_names, index=0)
version2 = st.selectbox("Compare Version B", version_names, index=1 if len(version_names) > 1 else 0)

text1 = resume_versions.get(version1, "")
text2 = resume_versions.get(version2, "")

diff = difflib.ndiff(text1.splitlines(), text2.splitlines())
st.code("\n".join(diff), language="diff")
