import streamlit as st
from utils.session_manager import session_manager
from datetime import datetime

st.set_page_config(page_title="Resume History", page_icon="📂")
st.title("📂 Resume History & Versions")

with st.expander("ℹ️ What is Resume History?"):
    st.markdown("""
Resume History tracks your resume uploads and edits.
Each version is saved and tagged, so you can view, revert, or export any time.
    """)

session_id = st.session_state.get("session_id", "default")
session = session_manager.get_or_create(session_id)

resume_versions = session.context.get("resume_versions", [])

if not resume_versions:
    st.info("No resumes uploaded yet.")
else:
    for idx, res in enumerate(resume_versions):
        st.markdown("---")
        st.subheader(f"Resume {idx+1} {'⭐ (MASTER)' if idx == 0 else ''}")
        st.write("📌 Tag:", res.get("tag", "untagged"))

        if "timestamp" in res:
            st.caption(f"📅 Uploaded: {res['timestamp']}")
        else:
            res["timestamp"] = datetime.now().isoformat(timespec="minutes")

        st.text_area("📝 Content Preview", res.get("content", "")[:1000], height=200, key=f"preview_{idx}")

        # Notes
        note_key = f"note_{idx}"
        note_value = res.get("note", "")
        updated_note = st.text_input("📝 Version Note", value=note_value, key=note_key)
        res["note"] = updated_note

        # Stats
        word_count = len(res.get("content", "").split())
        st.write("📊 Word Count:", word_count)

        # Download
        st.download_button("⬇️ Download This Resume", res["content"], file_name=f"resume_v{idx+1}.txt", key=f"download_{idx}")

        # Promote
        if idx != 0 and st.button(f"⭐ Promote Resume {idx+1} to MASTER", key=f"promote_{idx}"):
            promoted = resume_versions.pop(idx)
            resume_versions.insert(0, promoted)
            st.rerun()

        # Revert
        if idx != 0 and st.button(f"🔄 Revert Resume {idx+1} to Editor", key=f"revert_{idx}"):
            st.session_state["editor_resume"] = res["content"]
            st.success(f"Resume {idx+1} loaded into editor!")
