"""
IntelliCV Job Title Intelligence Engine
Advanced job title analysis and career pathway intelligence
Token Cost: 7 tokens (Advanced Tier)
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import networkx as nx
from datetime import datetime
import json

# Page configuration
st.set_page_config(
    page_title="Job Title Intelligence - IntelliCV",
    page_icon="🎯",
    layout="wide"
)

def main():
    st.title("🎯 Job Title Intelligence Engine")
    st.markdown("### Advanced job title analysis and career pathway intelligence")
    
    # Token cost display
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.info("💎 **Token Cost: 7 tokens** | Advanced Tier Feature")
    
    # Main tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "🔍 Title Analyzer", 
        "🗺️ Career Pathways", 
        "📊 Market Intelligence", 
        "🔗 Title Relationships"
    ])
    
    with tab1:
        st.header("🔍 Job Title Intelligence Analyzer")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.subheader("🎯 Title Analysis Input")
            
            current_title = st.text_input("Current job title", value="Data Analyst")
            target_titles = st.text_area(
                "Target job titles (one per line)",
                value="Senior Data Analyst\nData Scientist\nBusiness Intelligence Analyst\nProduct Analyst"
            )
            
            industry = st.selectbox("Industry focus", 
                                  ["Technology", "Finance", "Healthcare", "Retail", "Manufacturing", "All Industries"])
            
            experience_years = st.slider("Years of experience", 0, 20, 3)
            
            if st.button("🔬 Analyze Job Titles"):
                st.success("✅ Analysis complete! Results displayed on the right.")
        
        with col2:
            st.subheader("📊 Title Intelligence Results")
            
            # Sample analysis results
            analysis_results = {
                'Target Title': ['Senior Data Analyst', 'Data Scientist', 'Business Intelligence Analyst', 'Product Analyst'],
                'Similarity Score': [95, 78, 85, 72],
                'Skill Overlap': [92, 68, 88, 65],
                'Salary Range': ['$75k-$95k', '$95k-$130k', '$70k-$90k', '$80k-$110k'],
                'Career Fit': ['Excellent', 'Good', 'Very Good', 'Good']
            }
            
            df = pd.DataFrame(analysis_results)
            
            # Display as interactive table with color coding
            st.dataframe(
                df.style.applymap(
                    lambda x: 'background-color: #d4edda' if isinstance(x, str) and 'Excellent' in x
                    else 'background-color: #d1ecf1' if isinstance(x, str) and 'Very Good' in x
                    else 'background-color: #f8f9fa' if isinstance(x, str) and 'Good' in x
                    else '', subset=['Career Fit']
                ),
                use_container_width=True
            )
            
            st.subheader("🎯 Skill Gap Analysis")
            
            # Skill gap visualization
            skills_data = {
                'Skill Category': ['Technical Skills', 'Analytics', 'Communication', 'Leadership', 'Domain Knowledge'],
                'Current Level': [75, 85, 70, 45, 80],
                'Required Level': [85, 90, 80, 70, 85],
                'Gap': [10, 5, 10, 25, 5]
            }
            
            skills_df = pd.DataFrame(skills_data)
            
            fig = px.bar(skills_df, x='Skill Category', y=['Current Level', 'Required Level'],
                        title="Skills: Current vs Required for Target Roles",
                        barmode='group')
            st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        st.header("🗺️ Career Pathway Intelligence")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🛤️ Career Progression Paths")
            
            # Career pathway visualization
            pathway_data = {
                'Stage': ['Current', '1-2 Years', '3-5 Years', '5-8 Years', '8+ Years'],
                'Primary Path': ['Data Analyst', 'Senior Data Analyst', 'Lead Data Analyst', 'Data Science Manager', 'Director of Analytics'],
                'Alternative Path 1': ['Data Analyst', 'Business Analyst', 'Senior Business Analyst', 'Product Manager', 'VP Product'],
                'Alternative Path 2': ['Data Analyst', 'Data Scientist', 'Senior Data Scientist', 'Principal Data Scientist', 'Chief Data Officer']
            }
            
            pathway_df = pd.DataFrame(pathway_data)
            
            st.subheader("📈 Primary Career Path")
            for i, stage in enumerate(pathway_df['Stage']):
                title = pathway_df['Primary Path'][i]
                if i == 0:
                    st.success(f"**{stage}:** {title} ← You are here")
                else:
                    st.info(f"**{stage}:** {title}")
            
            st.subheader("🔀 Alternative Paths")
            st.write("**Business Track:** Data Analyst → Business Analyst → Product Manager")
            st.write("**Technical Track:** Data Analyst → Data Scientist → Principal Scientist")
        
        with col2:
            st.subheader("📊 Pathway Success Metrics")
            
            # Success probability chart
            pathways = ['Primary Path', 'Business Track', 'Technical Track']
            success_rates = [85, 72, 68]
            avg_salaries = [95000, 120000, 140000]
            time_to_promotion = [2.3, 3.1, 3.8]
            
            metrics_df = pd.DataFrame({
                'Pathway': pathways,
                'Success Rate (%)': success_rates,
                'Avg Salary': avg_salaries,
                'Years to Next Level': time_to_promotion
            })
            
            fig = px.scatter(metrics_df, x='Years to Next Level', y='Success Rate (%)',
                           size='Avg Salary', hover_name='Pathway',
                           title="Career Path Comparison")
            st.plotly_chart(fig, use_container_width=True)
            
            st.subheader("🎯 Next Steps Recommendations")
            
            recommendations = [
                "Focus on SQL and Python proficiency",
                "Gain experience with data visualization tools",
                "Develop presentation and communication skills",
                "Work on cross-functional projects",
                "Consider pursuing relevant certifications"
            ]
            
            for i, rec in enumerate(recommendations, 1):
                st.write(f"**{i}.** {rec}")
    
    with tab3:
        st.header("📊 Job Title Market Intelligence")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📈 Market Trends")
            
            # Market trend data
            quarters = ['Q1 2023', 'Q2 2023', 'Q3 2023', 'Q4 2023', 'Q1 2024', 'Q2 2024']
            job_postings = [1250, 1380, 1520, 1420, 1680, 1890]
            avg_salaries = [78000, 79500, 81000, 82500, 84000, 86000]
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=quarters, y=job_postings, name='Job Postings', yaxis='y'))
            fig.add_trace(go.Scatter(x=quarters, y=avg_salaries, name='Avg Salary', yaxis='y2'))
            
            fig.update_layout(
                title='Job Market Trends for Data Analyst',
                yaxis=dict(title='Job Postings', side='left'),
                yaxis2=dict(title='Average Salary ($)', side='right', overlaying='y')
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            st.subheader("🏢 Top Hiring Companies")
            companies = [
                "Microsoft", "Amazon", "Google", "Meta", "Netflix",
                "Apple", "Salesforce", "IBM", "Oracle", "Adobe"
            ]
            
            for i, company in enumerate(companies, 1):
                st.write(f"**{i}.** {company}")
        
        with col2:
            st.subheader("🌍 Geographic Distribution")
            
            # Geographic data
            locations = ['San Francisco', 'New York', 'Seattle', 'Austin', 'Chicago', 'Boston']
            job_counts = [2400, 2100, 1800, 1200, 1100, 900]
            
            fig = px.bar(x=locations, y=job_counts,
                        title="Data Analyst Jobs by Location")
            st.plotly_chart(fig, use_container_width=True)
            
            st.subheader("💰 Salary Insights")
            
            # Salary by experience
            exp_levels = ['Entry (0-2 yrs)', 'Mid (3-5 yrs)', 'Senior (6-10 yrs)', 'Lead (10+ yrs)']
            min_salaries = [55000, 70000, 90000, 120000]
            max_salaries = [70000, 90000, 120000, 150000]
            
            fig = go.Figure()
            fig.add_trace(go.Bar(name='Min Salary', x=exp_levels, y=min_salaries))
            fig.add_trace(go.Bar(name='Max Salary', x=exp_levels, y=max_salaries))
            
            fig.update_layout(title='Salary Range by Experience Level', barmode='group')
            st.plotly_chart(fig, use_container_width=True)
    
    with tab4:
        st.header("🔗 Job Title Relationship Network")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.subheader("🎯 Network Controls")
            
            center_title = st.text_input("Center job title", value="Data Analyst")
            relationship_depth = st.slider("Relationship depth", 1, 3, 2)
            min_similarity = st.slider("Minimum similarity (%)", 30, 90, 50)
            
            show_salaries = st.checkbox("Show salary information", value=True)
            show_skills = st.checkbox("Show required skills", value=True)
            
            if st.button("🔄 Generate Network"):
                st.success("✅ Network updated!")
        
        with col2:
            st.subheader("🕸️ Title Relationship Network")
            
            # Create sample network visualization
            st.write("**Network Visualization**")
            st.info("🔗 Interactive network showing relationships between job titles based on:")
            st.write("• Skill overlap similarity")
            st.write("• Career progression pathways")
            st.write("• Industry clustering")
            st.write("• Salary ranges and requirements")
            
            # Sample relationship data
            relationships = {
                'Source Title': ['Data Analyst', 'Data Analyst', 'Data Analyst', 'Senior Data Analyst'],
                'Target Title': ['Senior Data Analyst', 'Business Analyst', 'Data Scientist', 'Data Science Manager'],
                'Relationship Type': ['Promotion', 'Lateral Move', 'Career Pivot', 'Promotion'],
                'Similarity Score': [95, 78, 72, 88],
                'Transition Rate': ['85%', '45%', '32%', '78%']
            }
            
            rel_df = pd.DataFrame(relationships)
            st.dataframe(rel_df, use_container_width=True)
            
            st.subheader("📊 Title Clusters")
            
            # Title clustering visualization
            cluster_data = {
                'Title': ['Data Analyst', 'Business Analyst', 'Financial Analyst', 'Marketing Analyst',
                         'Data Scientist', 'Research Scientist', 'ML Engineer', 'AI Researcher'],
                'Cluster': ['Analytics', 'Analytics', 'Analytics', 'Analytics',
                           'Data Science', 'Data Science', 'Data Science', 'Data Science'],
                'X': [1, 1.2, 0.8, 1.1, 3, 3.2, 2.8, 3.1],
                'Y': [1, 1.1, 0.9, 1.2, 2, 2.1, 1.9, 2.2]
            }
            
            cluster_df = pd.DataFrame(cluster_data)
            
            fig = px.scatter(cluster_df, x='X', y='Y', color='Cluster', 
                           hover_name='Title', title="Job Title Clusters")
            fig.update_traces(marker=dict(size=12))
            fig.update_layout(showlegend=True)
            st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main()